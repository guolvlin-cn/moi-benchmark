# MinerU Parser Debug Output

**生成时间**: 2026-07-29T15:35:13.735407

**Block 总数**: 10


---

## 类型统计

| 类型 | 数量 |
|------|------|
| text | 10 |

---

## Block 详情

### Block 0: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 0.0
- **bbox**: `BBox(x0=45, y0=116, x1=119, y1=129)`

**Content**:

```
阿斯蒂芬阿萨德

```

**Image**: *(has image_base64)*


---

### Block 1: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 1.0
- **bbox**: `BBox(x0=47, y0=132, x1=119, y1=144)`

**Content**:

```
阿第三方阿萨德

```

**Image**: *(has image_base64)*


---

### Block 2: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 2.0
- **bbox**: `BBox(x0=47, y0=147, x1=212, y1=160)`

**Content**:

```
奥德赛发斯蒂芬阿斯蒂芬阿斯顿发 sd

```

**Image**: *(has image_base64)*


---

### Block 3: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 3.0
- **bbox**: `BBox(x0=47, y0=163, x1=82, y1=175)`

**Content**:

```
表格一：

```

**Image**: *(has image_base64)*


---

### Block 4: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 1
- **索引**: 4.0
- **bbox**: `BBox(x0=157, y0=201, x1=346, y1=218)`

**Content**:

```
TABLE_placeHOLDER_001
```

**Image**: *(no image)*


---

### Block 5: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 5.0
- **bbox**: `BBox(x0=45, y0=585, x1=174, y1=598)`

**Content**:

```
阿第三方阿斯蒂芬阿斯蒂芬

```

**Image**: *(has image_base64)*


---

### Block 6: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 6.0
- **bbox**: `BBox(x0=47, y0=601, x1=111, y1=613)`

**Content**:

```
阿第三方 asdf

```

**Image**: *(has image_base64)*


---

### Block 7: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 7.0
- **bbox**: `BBox(x0=47, y0=616, x1=389, y1=629)`

**Content**:

```
多发点发生的 阿斯顿发生的发阿斯蒂芬阿斯蒂芬水电费阿第三方阿是放大

```

**Image**: *(has image_base64)*


---

### Block 8: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 0.0
- **bbox**: `BBox(x0=46, y0=132, x1=77, y1=144)`

**Content**:

```
表格3

```

**Image**: *(has image_base64)*


---

### Block 9: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 2
- **索引**: 1.0
- **bbox**: `BBox(x0=201, y0=184, x1=391, y1=200)`

**Content**:

```
TABLE_placeHOLDER_002
```

**Image**: *(no image)*


---
