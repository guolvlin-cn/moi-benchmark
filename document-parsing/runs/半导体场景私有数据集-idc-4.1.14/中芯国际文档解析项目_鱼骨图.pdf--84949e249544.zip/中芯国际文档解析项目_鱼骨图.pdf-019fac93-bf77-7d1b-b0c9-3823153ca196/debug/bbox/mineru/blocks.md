# MinerU Parser Debug Output

**生成时间**: 2026-07-29T14:33:27.105521

**Block 总数**: 30


---

## 类型统计

| 类型 | 数量 |
|------|------|
| footer | 1 |
| header | 12 |
| image | 4 |
| list | 5 |
| text | 4 |
| title | 4 |

---

## Block 详情

### Block 0: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 1.0
- **bbox**: `BBox(x0=181, y0=165, x1=773, y1=306)`
- **标题级别**: 1

**Content**:

```
中芯国际文档解析项目 开工会

```

**Image**: *(has image_base64)*


---

### Block 1: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 2.0
- **bbox**: `BBox(x0=658, y0=421, x1=821, y1=442)`

**Content**:

```
2025年12月26日

```

**Image**: *(has image_base64)*


---

### Block 2: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 1
- **索引**: -999.9978
- **bbox**: `BBox(x0=770, y0=22, x1=924, y1=70)`

**Content**:

```
MO 矩阵起原

```

**Image**: *(has image_base64)*


---

### Block 3: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 2
- **索引**: 0.0
- **bbox**: `BBox(x0=35, y0=236, x1=231, y1=287)`
- **标题级别**: 1

**Content**:

```
会议议程

```

**Image**: *(has image_base64)*


---

### Block 4: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 6.0
- **bbox**: `BBox(x0=508, y0=129, x1=695, y1=166)`

**Content**:

```
01 项目背景
```

**Image**: *(has image_base64)*


---

### Block 5: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 6.001
- **bbox**: `BBox(x0=510, y0=185, x1=694, y1=222)`

**Content**:

```
02 需求分析
```

**Image**: *(has image_base64)*


---

### Block 6: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 6.002
- **bbox**: `BBox(x0=510, y0=243, x1=694, y1=279)`

**Content**:

```
03 项目计划
```

**Image**: *(has image_base64)*


---

### Block 7: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 6.003
- **bbox**: `BBox(x0=510, y0=300, x1=695, y1=336)`

**Content**:

```
04 项目协作
```

**Image**: *(has image_base64)*


---

### Block 8: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 6.004
- **bbox**: `BBox(x0=510, y0=356, x1=695, y1=393)`

**Content**:

```
05 风险应对
```

**Image**: *(has image_base64)*


---

### Block 9: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 3
- **索引**: 0.0
- **bbox**: `BBox(x0=70, y0=51, x1=241, y1=82)`
- **标题级别**: 1

**Content**:

```
项目背景介绍

```

**Image**: *(has image_base64)*


---

### Block 10: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 3
- **索引**: 1.0
- **bbox**: `BBox(x0=42, y0=120, x1=256, y1=138)`
- **标题级别**: 1

**Content**:

```
中芯国际SMIC文档解析开发项目

```

**Image**: *(has image_base64)*


---

### Block 11: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 2.0
- **bbox**: `BBox(x0=41, y0=144, x1=294, y1=227)`

**Content**:

```
主要是为了对PDF、PPT、Word、Excel等多种格式文件以及图片、表格、流程图等内容进行解析，将非结构化数据转化为结构化数据并利用。

```

**Image**: *(has image_base64)*


---

### Block 12: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 3.0
- **bbox**: `BBox(x0=40, y0=253, x1=295, y1=403)`

**Content**:

```
基于大模型算法构建文档要素抽取引擎，实现对PDF、PPT、Word、Excel等文档以及文档内图片、表格、流程图等复杂数据的解析分析，最终形成可支持智能问答系统、AI数字员工、光刻机异常分析助手、PDE培训数字员工、QE/CE稽核数字员工等应用的功能模块。

```

**Image**: *(has image_base64)*


---

### Block 13: image

- **类型**: `image`
- **源类型**: `image`
- **页码**: 3
- **索引**: 4.0
- **bbox**: `BBox(x0=307, y0=115, x1=947, y1=459)`

**Content**:

*(empty)*

**Image**: *(has image_base64)*


---

### Block 14: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 3
- **索引**: 9999.0516
- **bbox**: `BBox(x0=97, y0=516, x1=742, y1=537)`

**Content**:

```
底部贴边文本样例，button text sample，button text sample，button text sample

```

**Image**: *(has image_base64)*


---

### Block 15: image

- **类型**: `image`
- **源类型**: `image`
- **页码**: 4
- **索引**: 4.0
- **bbox**: `BBox(x0=76, y0=138, x1=409, y1=385)`
- **Captions**: ['需求示例1如下图\n']

**Content**:

*(empty)*

**Image**: *(has image_base64)*


---

### Block 16: image

- **类型**: `image`
- **源类型**: `image`
- **页码**: 4
- **索引**: 6.0
- **bbox**: `BBox(x0=541, y0=150, x1=779, y1=385)`
- **Captions**: ['需求示例1如下图：\n']

**Content**:

*(empty)*

**Image**: *(has image_base64)*


---

### Block 17: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 4
- **索引**: -999.9982
- **bbox**: `BBox(x0=39, y0=18, x1=131, y1=64)`

**Content**:

```
MO

```

**Image**: *(has image_base64)*


---

### Block 18: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 4
- **索引**: -999.9982
- **bbox**: `BBox(x0=137, y0=18, x1=194, y1=65)`

**Content**:

```
矩阵起源

```

**Image**: *(has image_base64)*


---

### Block 19: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 4
- **索引**: -999.9972
- **bbox**: `BBox(x0=217, y0=28, x1=389, y1=59)`

**Content**:

```
产品需求分析

```

**Image**: *(has image_base64)*


---

### Block 20: image

- **类型**: `image`
- **源类型**: `image`
- **页码**: 5
- **索引**: 4.0
- **bbox**: `BBox(x0=55, y0=109, x1=874, y1=482)`

**Content**:

*(empty)*

**Image**: *(has image_base64)*


---

### Block 21: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 5
- **索引**: -999.9982
- **bbox**: `BBox(x0=39, y0=18, x1=131, y1=63)`

**Content**:

```
MO

```

**Image**: *(has image_base64)*


---

### Block 22: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 5
- **索引**: -999.9982
- **bbox**: `BBox(x0=138, y0=18, x1=183, y1=63)`

**Content**:

```
矩阵起源

```

**Image**: *(has image_base64)*


---

### Block 23: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 5
- **索引**: -999.9981
- **bbox**: `BBox(x0=184, y0=19, x1=195, y1=64)`

**Content**:

```
Marrrn

```

**Image**: *(has image_base64)*


---

### Block 24: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 5
- **索引**: -999.9987
- **bbox**: `BBox(x0=217, y0=13, x1=472, y1=45)`

**Content**:

```
产品需求分析鱼骨图

```

**Image**: *(has image_base64)*


---

### Block 25: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 6
- **索引**: 4.0
- **bbox**: `BBox(x0=381, y0=98, x1=573, y1=115)`

**Content**:

```
TABLE_placeHOLDER_001
```

**Image**: *(no image)*


---

### Block 26: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 6
- **索引**: -999.9983
- **bbox**: `BBox(x0=39, y0=17, x1=132, y1=64)`

**Content**:

```
MO

```

**Image**: *(has image_base64)*


---

### Block 27: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 6
- **索引**: -999.9982
- **bbox**: `BBox(x0=137, y0=18, x1=196, y1=65)`

**Content**:

```
矩阵起源

```

**Image**: *(has image_base64)*


---

### Block 28: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 6
- **索引**: -999.9988
- **bbox**: `BBox(x0=217, y0=12, x1=445, y1=45)`

**Content**:

```
产品需求分析计划

```

**Image**: *(has image_base64)*


---

### Block 29: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 6
- **索引**: -999.9936
- **bbox**: `BBox(x0=606, y0=64, x1=928, y1=84)`

**Content**:

```
最终交付目标为 100\% ，时间2025/1/19

```

**Image**: *(has image_base64)*


---
