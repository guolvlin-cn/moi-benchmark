# MinerU Parser Debug Output

**生成时间**: 2026-07-29T14:17:16.752693

**Block 总数**: 6


---

## 类型统计

| 类型 | 数量 |
|------|------|
| text | 2 |
| title | 4 |

---

## Block 详情

### Block 0: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 0.0
- **bbox**: `BBox(x0=88, y0=171, x1=290, y1=196)`
- **标题级别**: 1

**Content**:

```
1. 测试表格标题丢失

```

**Image**: *(has image_base64)*


---

### Block 1: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 1.0
- **bbox**: `BBox(x0=88, y0=225, x1=280, y1=244)`
- **标题级别**: 2

**Content**:

```
1.1.测试表格标题是否丢失

```

**Image**: *(has image_base64)*


---

### Block 2: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 2.0
- **bbox**: `BBox(x0=88, y0=269, x1=245, y1=288)`
- **标题级别**: 3

**Content**:

```
1.1.1. 普通表一的标题

```

**Image**: *(has image_base64)*


---

### Block 3: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 1
- **索引**: 3.0
- **bbox**: `BBox(x0=201, y0=316, x1=390, y1=333)`

**Content**:

```
TABLE_placeHOLDER_001
```

**Image**: *(no image)*


---

### Block 4: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 4.0
- **bbox**: `BBox(x0=87, y0=469, x1=246, y1=487)`
- **标题级别**: 3

**Content**:

```
1.1.2. 表同表二的标题

```

**Image**: *(has image_base64)*


---

### Block 5: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 1
- **索引**: 5.0
- **bbox**: `BBox(x0=201, y0=515, x1=392, y1=533)`

**Content**:

```
TABLE_placeHOLDER_002
```

**Image**: *(no image)*


---
