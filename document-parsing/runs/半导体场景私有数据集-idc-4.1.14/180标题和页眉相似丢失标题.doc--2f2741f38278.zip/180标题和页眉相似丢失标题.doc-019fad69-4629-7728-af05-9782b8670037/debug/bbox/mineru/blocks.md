# MinerU Parser Debug Output

**生成时间**: 2026-07-29T18:26:38.922510

**Block 总数**: 32


---

## 类型统计

| 类型 | 数量 |
|------|------|
| list | 24 |
| text | 4 |
| title | 4 |

---

## Block 详情

### Block 0: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 0.0
- **bbox**: `BBox(x0=42, y0=172, x1=477, y1=192)`
- **标题级别**: 1

**Content**:

```
1. Semiconfuctor Manufacturing International Corporation

```

**Image**: *(has image_base64)*


---

### Block 1: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 1.0
- **bbox**: `BBox(x0=42, y0=205, x1=105, y1=219)`

**Content**:

```
2. Purpose:

```

**Image**: *(has image_base64)*


---

### Block 2: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 4.0
- **bbox**: `BBox(x0=62, y0=220, x1=547, y1=247)`

**Content**:

```
2.1. To establish SMIC internal procedure for periodic performance evaluation and communication on with Class-I
```

**Image**: *(has image_base64)*


---

### Block 3: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 4.001
- **bbox**: `BBox(x0=62, y0=248, x1=546, y1=288)`

**Content**:

```
2.2. This document defines QCDESE evaluation procedures including scoring rules, internal review process, approval of final report, publication, and communication post-publication for SMIC Class-I
```

**Image**: *(has image_base64)*


---

### Block 4: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 5.0
- **bbox**: `BBox(x0=41, y0=297, x1=502, y1=312)`

**Content**:

```
3. Scope: Applies to all SMIC group company and all SMIC Class-I Suppliers(Raw Material).

```

**Image**: *(has image_base64)*


---

### Block 5: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 1
- **索引**: 6.0
- **bbox**: `BBox(x0=107, y0=321, x1=296, y1=338)`

**Content**:

```
TABLE_placeHOLDER_001
```

**Image**: *(no image)*


---

### Block 6: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 7.0
- **bbox**: `BBox(x0=42, y0=595, x1=134, y1=608)`

**Content**:

```
4. Nomenclature:

```

**Image**: *(has image_base64)*


---

### Block 7: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 19.0
- **bbox**: `BBox(x0=63, y0=610, x1=226, y1=624)`

**Content**:

```
4.1. CSL: Chemical Safety Label.
```

**Image**: *(has image_base64)*


---

### Block 8: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 19.001
- **bbox**: `BBox(x0=64, y0=624, x1=258, y1=637)`

**Content**:

```
4.2. MSDS: Meterial Safety Data Sheet.
```

**Image**: *(has image_base64)*


---

### Block 9: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 19.002
- **bbox**: `BBox(x0=64, y0=638, x1=225, y1=651)`

**Content**:

```
4.3. CSL: Chemical Safety Label.
```

**Image**: *(has image_base64)*


---

### Block 10: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 19.003
- **bbox**: `BBox(x0=64, y0=652, x1=258, y1=665)`

**Content**:

```
4.4. MSDS: Meterial Safety Data Sheet.
```

**Image**: *(has image_base64)*


---

### Block 11: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 19.004
- **bbox**: `BBox(x0=64, y0=666, x1=226, y1=678)`

**Content**:

```
4.5. CSL: Chimalc Safety Label.
```

**Image**: *(has image_base64)*


---

### Block 12: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 19.005
- **bbox**: `BBox(x0=64, y0=680, x1=258, y1=692)`

**Content**:

```
4.6. MSDS: Meterial Safety Data Sheet.
```

**Image**: *(has image_base64)*


---

### Block 13: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 19.006
- **bbox**: `BBox(x0=64, y0=693, x1=226, y1=706)`

**Content**:

```
4.7. CSL: Chimalc Safety Label.
```

**Image**: *(has image_base64)*


---

### Block 14: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 19.007
- **bbox**: `BBox(x0=64, y0=707, x1=258, y1=719)`

**Content**:

```
4.8. MSDS: Meterial Safety Data Sheet.
```

**Image**: *(has image_base64)*


---

### Block 15: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 19.008
- **bbox**: `BBox(x0=64, y0=721, x1=225, y1=734)`

**Content**:

```
4.9. CSL: Chemical Safety Label.
```

**Image**: *(has image_base64)*


---

### Block 16: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 19.009
- **bbox**: `BBox(x0=64, y0=735, x1=279, y1=747)`

**Content**:

```
4.10. MSDS: Meterial Safety Data Sheet.
```

**Image**: *(has image_base64)*


---

### Block 17: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 19.01
- **bbox**: `BBox(x0=64, y0=748, x1=246, y1=761)`

**Content**:

```
4.11. CSL: Chemical Safety Label.
```

**Image**: *(has image_base64)*


---

### Block 18: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 2.0
- **bbox**: `BBox(x0=62, y0=114, x1=279, y1=127)`

**Content**:

```
4.12. MSDS: Meterial Safety Data Sheet.
```

**Image**: *(has image_base64)*


---

### Block 19: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 2.001
- **bbox**: `BBox(x0=63, y0=128, x1=247, y1=142)`

**Content**:

```
4.13. CSL: Chemical Safety Label.
```

**Image**: *(has image_base64)*


---

### Block 20: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 2
- **索引**: 3.0
- **bbox**: `BBox(x0=42, y0=151, x1=120, y1=163)`
- **标题级别**: 1

**Content**:

```
5. Reference:

```

**Image**: *(has image_base64)*


---

### Block 21: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 6.0
- **bbox**: `BBox(x0=63, y0=166, x1=401, y1=180)`

**Content**:

```
5.1. QR-IQCs-01-2005 SMIC Incoming Quality Assurance Procedure
```

**Image**: *(has image_base64)*


---

### Block 22: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 6.001
- **bbox**: `BBox(x0=63, y0=182, x1=406, y1=196)`

**Content**:

```
5.2. QR-IQCs-01-2005 SMIC OutcomingQuality Assurance Procedure
```

**Image**: *(has image_base64)*


---

### Block 23: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 2
- **索引**: 7.0
- **bbox**: `BBox(x0=42, y0=205, x1=139, y1=220)`
- **标题级别**: 1

**Content**:

```
6. Responsibility:

```

**Image**: *(has image_base64)*


---

### Block 24: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 2
- **索引**: 8.0
- **bbox**: `BBox(x0=63, y0=222, x1=110, y1=234)`
- **标题级别**: 2

**Content**:

```
6.1. SQE

```

**Image**: *(has image_base64)*


---

### Block 25: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 14.0
- **bbox**: `BBox(x0=85, y0=237, x1=243, y1=248)`

**Content**:

```
6.1.1. Maintain this document
```

**Image**: *(has image_base64)*


---

### Block 26: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 14.001
- **bbox**: `BBox(x0=85, y0=253, x1=254, y1=265)`

**Content**:

```
6.1.2. Initial QCDSE vendor list
```

**Image**: *(has image_base64)*


---

### Block 27: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 14.002
- **bbox**: `BBox(x0=85, y0=268, x1=282, y1=282)`

**Content**:

```
6.1.3. Responsible for Quality scoring
```

**Image**: *(has image_base64)*


---

### Block 28: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 14.003
- **bbox**: `BBox(x0=84, y0=283, x1=478, y1=297)`

**Content**:

```
6.1.4. Generate QCDSE report, obtain internal approval and publish to vendors
```

**Image**: *(has image_base64)*


---

### Block 29: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 14.004
- **bbox**: `BBox(x0=85, y0=299, x1=255, y1=312)`

**Content**:

```
6.1.5. Initial QCDSE vendor list
```

**Image**: *(has image_base64)*


---

### Block 30: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 17.0
- **bbox**: `BBox(x0=63, y0=314, x1=431, y1=329)`

**Content**:

```
6.2. DCN: Document Change Notice(for Company Rules and Regulations)
```

**Image**: *(has image_base64)*


---

### Block 31: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 17.001
- **bbox**: `BBox(x0=63, y0=330, x1=279, y1=344)`

**Content**:

```
6.3. DMS: Document Management System
```

**Image**: *(has image_base64)*


---
