# MinerU Parser Debug Output

**生成时间**: 2026-07-29T14:05:51.950328

**Block 总数**: 3


---

## 类型统计

| 类型 | 数量 |
|------|------|
| text | 3 |

---

## Block 详情

### Block 0: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 0.0
- **bbox**: `BBox(x0=60, y0=126, x1=271, y1=141)`

**Content**:

```
1. 仓管系统功能之维护 SAP System

```

**Image**: *(has image_base64)*


---

### Block 1: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 1.0
- **bbox**: `BBox(x0=101, y0=157, x1=235, y1=172)`

**Content**:

```
1.1. 仓管作业流程图：

```

**Image**: *(has image_base64)*


---

### Block 2: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 1
- **索引**: 2.0
- **bbox**: `BBox(x0=201, y0=195, x1=390, y1=212)`

**Content**:

```
TABLE_placeHOLDER_001
```

**Image**: *(no image)*


---
