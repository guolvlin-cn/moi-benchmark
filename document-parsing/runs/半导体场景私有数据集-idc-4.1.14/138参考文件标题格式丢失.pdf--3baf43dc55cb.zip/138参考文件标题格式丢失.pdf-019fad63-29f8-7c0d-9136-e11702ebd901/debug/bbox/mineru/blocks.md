# MinerU Parser Debug Output

**生成时间**: 2026-07-29T18:20:34.863169

**Block 总数**: 68


---

## 类型统计

| 类型 | 数量 |
|------|------|
| header | 6 |
| image | 1 |
| list | 39 |
| text | 12 |
| title | 10 |

---

## Block 详情

### Block 0: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 17.0
- **bbox**: `BBox(x0=97, y0=121, x1=296, y1=132)`

**Content**:

```
1. Title: SMIC IT Request Management Procedure
```

**Image**: *(has image_base64)*


---

### Block 1: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 17.001
- **bbox**: `BBox(x0=97, y0=138, x1=486, y1=160)`

**Content**:

```
2. Purpose: Objective of this procedure is to ensure Completeness & Rationality of IT requests, so as to optimize SMIC management efficiency fastest.
```

**Image**: *(has image_base64)*


---

### Block 2: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 17.002
- **bbox**: `BBox(x0=97, y0=166, x1=235, y1=178)`

**Content**:

```
3. Scope: IT Application Systems
```

**Image**: *(has image_base64)*


---

### Block 3: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 17.003
- **bbox**: `BBox(x0=96, y0=184, x1=177, y1=195)`

**Content**:

```
4. Nomenclature:
```

**Image**: *(has image_base64)*


---

### Block 4: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 17.004
- **bbox**: `BBox(x0=96, y0=195, x1=240, y1=206)`

**Content**:

```
4.1. Fab Related: IT/MIT related
```

**Image**: *(has image_base64)*


---

### Block 5: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 17.005
- **bbox**: `BBox(x0=97, y0=207, x1=255, y1=217)`

**Content**:

```
4.2. Non-Fab Related:IT/CIT related
```

**Image**: *(has image_base64)*


---

### Block 6: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 17.006
- **bbox**: `BBox(x0=96, y0=223, x1=163, y1=234)`

**Content**:

```
5. Reference:
```

**Image**: *(has image_base64)*


---

### Block 7: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 17.007
- **bbox**: `BBox(x0=97, y0=236, x1=407, y1=246)`

**Content**:

```
5.1. IT-CIMS-01-2006: SMIC(SH/TJ/SZ)1 T/CIM Software Control Procedure
```

**Image**: *(has image_base64)*


---

### Block 8: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 17.008
- **bbox**: `BBox(x0=97, y0=247, x1=401, y1=257)`

**Content**:

```
5.2. IT-CIMS-01-2008: SMJC(BJ/SH/SZ)1T/CIM Software Control Procedure
```

**Image**: *(has image_base64)*


---

### Block 9: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 17.009
- **bbox**: `BBox(x0=96, y0=264, x1=178, y1=275)`

**Content**:

```
6. Responsibility:
```

**Image**: *(has image_base64)*


---

### Block 10: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 17.01
- **bbox**: `BBox(x0=96, y0=275, x1=243, y1=285)`

**Content**:

```
6.1. SMIT IT Development Team
```

**Image**: *(has image_base64)*


---

### Block 11: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 17.011
- **bbox**: `BBox(x0=97, y0=286, x1=379, y1=296)`

**Content**:

```
6.1.1. Take the responsibility for IT technical solution evaluation;
```

**Image**: *(has image_base64)*


---

### Block 12: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 17.012
- **bbox**: `BBox(x0=97, y0=298, x1=423, y1=309)`

**Content**:

```
6.1.2. Take the responsibility for IT technical solution resource cost evaluation;
```

**Image**: *(has image_base64)*


---

### Block 13: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 17.013
- **bbox**: `BBox(x0=97, y0=311, x1=384, y1=322)`

**Content**:

```
6.1.3. Take the responsibility for IT development resource planning;
```

**Image**: *(has image_base64)*


---

### Block 14: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 17.014
- **bbox**: `BBox(x0=97, y0=323, x1=397, y1=334)`

**Content**:

```
6.1.4. Take the responsibility for IT service request system maintenance
```

**Image**: *(has image_base64)*


---

### Block 15: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 22.0
- **bbox**: `BBox(x0=97, y0=349, x1=157, y1=358)`

**Content**:

```
6.2. User
```

**Image**: *(has image_base64)*


---

### Block 16: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 22.001
- **bbox**: `BBox(x0=97, y0=359, x1=398, y1=370)`

**Content**:

```
6.2.1. Take the responsibility for user request document implementation
```

**Image**: *(has image_base64)*


---

### Block 17: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 22.002
- **bbox**: `BBox(x0=97, y0=371, x1=410, y1=382)`

**Content**:

```
6.2.2. Take the responsibility for user request measurable benefit valuation;
```

**Image**: *(has image_base64)*


---

### Block 18: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 22.003
- **bbox**: `BBox(x0=97, y0=384, x1=386, y1=395)`

**Content**:

```
6.2.3. Take the responsibility for related org. user request alignment;
```

**Image**: *(has image_base64)*


---

### Block 19: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 27.0
- **bbox**: `BBox(x0=97, y0=409, x1=282, y1=419)`

**Content**:

```
6.3. TBC (Technical Board Coordination)
```

**Image**: *(has image_base64)*


---

### Block 20: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 27.001
- **bbox**: `BBox(x0=97, y0=421, x1=486, y1=441)`

**Content**:

```
6.3.1. Take the responsibility for fab user request prioritization if the priority are conflict across function
```

**Image**: *(has image_base64)*


---

### Block 21: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 27.002
- **bbox**: `BBox(x0=97, y0=444, x1=157, y1=454)`

**Content**:

```
6.4.QRE
```

**Image**: *(has image_base64)*


---

### Block 22: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 27.003
- **bbox**: `BBox(x0=97, y0=454, x1=486, y1=475)`

**Content**:

```
6.4.1. Take the responsibility for non-fab user request prioritization if the priority are conflict across function
```

**Image**: *(has image_base64)*


---

### Block 23: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 1
- **索引**: -999.9982
- **bbox**: `BBox(x0=16, y0=18, x1=176, y1=32)`

**Content**:

```
SMI Restricted / e024120

```

**Image**: *(has image_base64)*


---

### Block 24: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 1
- **索引**: -999.9981
- **bbox**: `BBox(x0=392, y0=19, x1=572, y1=32)`

**Content**:

```
Time Now /2026-3-13 10:30

```

**Image**: *(has image_base64)*


---

### Block 25: image

- **类型**: `image`
- **源类型**: `image`
- **页码**: 2
- **索引**: 2.0
- **bbox**: `BBox(x0=226, y0=104, x1=362, y1=604)`

**Content**:

*(empty)*

**Image**: *(has image_base64)*


---

### Block 26: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 2
- **索引**: -999.9982
- **bbox**: `BBox(x0=16, y0=18, x1=176, y1=32)`

**Content**:

```
SMI Restricted / e024120

```

**Image**: *(has image_base64)*


---

### Block 27: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 2
- **索引**: -999.9982
- **bbox**: `BBox(x0=392, y0=18, x1=572, y1=31)`

**Content**:

```
Time Now /2026-3-13 10:30

```

**Image**: *(has image_base64)*


---

### Block 28: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 3
- **索引**: 2.0
- **bbox**: `BBox(x0=98, y0=73, x1=214, y1=82)`
- **标题级别**: 2

**Content**:

```
7.2. Request Preparation

```

**Image**: *(has image_base64)*


---

### Block 29: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 3.0
- **bbox**: `BBox(x0=136, y0=83, x1=489, y1=102)`

**Content**:

```
\diamond Users should provide below information for management change to issue change request and apply in IT service request system for signoff

```

**Image**: *(has image_base64)*


---

### Block 30: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 7.0
- **bbox**: `BBox(x0=150, y0=104, x1=329, y1=113)`

**Content**:

```
\checkmark Background(Current management, pain point)
```

**Image**: *(has image_base64)*


---

### Block 31: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 7.001
- **bbox**: `BBox(x0=150, y0=114, x1=312, y1=123)`

**Content**:

```
\checkmark Management Change(Improvement Idea)
```

**Image**: *(has image_base64)*


---

### Block 32: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 7.002
- **bbox**: `BBox(x0=150, y0=124, x1=191, y1=132)`

**Content**:

```
Benefit
```

**Image**: *(has image_base64)*


---

### Block 33: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 3
- **索引**: 8.0
- **bbox**: `BBox(x0=98, y0=135, x1=239, y1=145)`
- **标题级别**: 2

**Content**:

```
7.3. Request Valuation(Benefit)

```

**Image**: *(has image_base64)*


---

### Block 34: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 3
- **索引**: 9.0
- **bbox**: `BBox(x0=112, y0=146, x1=202, y1=154)`
- **标题级别**: 1

**Content**:

```
For Fab related:

```

**Image**: *(has image_base64)*


---

### Block 35: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 10.0
- **bbox**: `BBox(x0=136, y0=156, x1=409, y1=166)`

**Content**:

```
 Based on management change, user should provide request benefit in $←

```

**Image**: *(has image_base64)*


---

### Block 36: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 11.0
- **bbox**: `BBox(x0=151, y0=166, x1=264, y1=175)`

**Content**:

```
\checkmark Benefit Approval Procedure

```

**Image**: *(has image_base64)*


---

### Block 37: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 15.0
- **bbox**: `BBox(x0=160, y0=177, x1=462, y1=186)`

**Content**:

```
\(\checkmark\) Benefit' \(\leqslant\) \\(100,000(100K) \)\rightarrow\( Need direct manager approval
```

**Image**: *(has image_base64)*


---

### Block 38: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 15.001
- **bbox**: `BBox(x0=171, y0=187, x1=453, y1=196)`

**Content**:

```
$100,000(100K)<Benefit<$1,000,000(1M) → Need module head approval<
```

**Image**: *(has image_base64)*


---

### Block 39: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 15.002
- **bbox**: `BBox(x0=160, y0=198, x1=439, y1=207)`

**Content**:

```
\(\checkmark\) Benefit \(\rightharpoondown\) \\(1,000,000(1M) → Need fab head approval
```

**Image**: *(has image_base64)*


---

### Block 40: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 3
- **索引**: 16.0
- **bbox**: `BBox(x0=136, y0=208, x1=200, y1=217)`
- **标题级别**: 1

**Content**:

```
Benefit type

```

**Image**: *(has image_base64)*


---

### Block 41: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 22.0
- **bbox**: `BBox(x0=151, y0=218, x1=397, y1=227)`

**Content**:

```
\(\checkmark\) Cost saving \(\rightarrow\) Need measurable benefit in \\(←
```

**Image**: *(has image_base64)*


---

### Block 42: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 22.001
- **bbox**: `BBox(x0=151, y0=228, x1=397, y1=238)`

**Content**:

```
\(\checkmark\) Efficiency improvement \(\rightarrow\) Need measurable benefit in \\(<
```

**Image**: *(has image_base64)*


---

### Block 43: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 22.002
- **bbox**: `BBox(x0=151, y0=238, x1=397, y1=248)`

**Content**:

```
✔ Quality improvement → Need measurable benefit in $←
```

**Image**: *(has image_base64)*


---

### Block 44: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 22.003
- **bbox**: `BBox(x0=151, y0=248, x1=380, y1=258)`

**Content**:

```
\checkmark Customer satisfaction \rightarrow Need attach related email
```

**Image**: *(has image_base64)*


---

### Block 45: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 22.004
- **bbox**: `BBox(x0=151, y0=259, x1=380, y1=269)`

**Content**:

```
\checkmark Top management strategy \rightarrow Need attach related email
```

**Image**: *(has image_base64)*


---

### Block 46: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 3
- **索引**: 23.0
- **bbox**: `BBox(x0=112, y0=269, x1=212, y1=278)`
- **标题级别**: 1

**Content**:

```
For Non-Fab related

```

**Image**: *(has image_base64)*


---

### Block 47: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 24.0
- **bbox**: `BBox(x0=136, y0=280, x1=416, y1=289)`

**Content**:

```
User should provide the qualitative benefit of requests before submitted to IT<sup>←</sup>

```

**Image**: *(has image_base64)*


---

### Block 48: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 3
- **索引**: 25.0
- **bbox**: `BBox(x0=112, y0=301, x1=198, y1=310)`
- **标题级别**: 2

**Content**:

```
7.4. User Alignment

```

**Image**: *(has image_base64)*


---

### Block 49: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 28.0
- **bbox**: `BBox(x0=136, y0=312, x1=399, y1=321)`

**Content**:

```
User contact windows should get approval from his/her organization
```

**Image**: *(has image_base64)*


---

### Block 50: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 28.001
- **bbox**: `BBox(x0=136, y0=322, x1=369, y1=332)`

**Content**:

```
\diamond User should get approval from all relative user organization.
```

**Image**: *(has image_base64)*


---

### Block 51: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 29.0
- **bbox**: `BBox(x0=135, y0=333, x1=446, y1=343)`

**Content**:

```
For example, Fab1 DIFF operation request need be approved by Fab7 DIFF.Security

```

**Image**: *(has image_base64)*


---

### Block 52: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 30.0
- **bbox**: `BBox(x0=135, y0=344, x1=357, y1=354)`

**Content**:

```
Requirement need be approved by Legal or IT security team.

```

**Image**: *(has image_base64)*


---

### Block 53: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 31.0
- **bbox**: `BBox(x0=135, y0=355, x1=139, y1=363)`

**Content**:

```
←

```

**Image**: *(has image_base64)*


---

### Block 54: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 3
- **索引**: 32.0
- **bbox**: `BBox(x0=118, y0=368, x1=276, y1=376)`
- **标题级别**: 2

**Content**:

```
7.5. Solution & Resource Cost Evaluation

```

**Image**: *(has image_base64)*


---

### Block 55: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 33.0
- **bbox**: `BBox(x0=136, y0=378, x1=489, y1=398)`

**Content**:

```
\diamond After user request approved by all relative user contact windows, IT should provide technical solution with resource cost in $ for each request.

```

**Image**: *(has image_base64)*


---

### Block 56: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 3
- **索引**: 35.0
- **bbox**: `BBox(x0=118, y0=411, x1=226, y1=419)`
- **标题级别**: 2

**Content**:

```
7.6. Request Accept Criteria

```

**Image**: *(has image_base64)*


---

### Block 57: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 36.0
- **bbox**: `BBox(x0=136, y0=420, x1=371, y1=430)`

**Content**:

```
For Fab related(Accept request which meet below all items):

```

**Image**: *(has image_base64)*


---

### Block 58: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 40.0
- **bbox**: `BBox(x0=150, y0=431, x1=377, y1=441)`

**Content**:

```
\checkmark Benefit approved by all relative user and management team
```

**Image**: *(has image_base64)*


---

### Block 59: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 40.001
- **bbox**: `BBox(x0=150, y0=442, x1=243, y1=449)`

**Content**:

```
IT Solution is feasible
```

**Image**: *(has image_base64)*


---

### Block 60: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 40.002
- **bbox**: `BBox(x0=150, y0=451, x1=330, y1=461)`

**Content**:

```
\checkmark ROI(ROI = Benefit / IT development cost) > 1
```

**Image**: *(has image_base64)*


---

### Block 61: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 3
- **索引**: 41.0
- **bbox**: `BBox(x0=136, y0=462, x1=223, y1=470)`
- **标题级别**: 1

**Content**:

```
ForNon-Fab related

```

**Image**: *(has image_base64)*


---

### Block 62: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 42.0
- **bbox**: `BBox(x0=136, y0=472, x1=447, y1=481)`

**Content**:

```
IT will negotiate with user to make the decision by benefit, ROI and IT resource.

```

**Image**: *(has image_base64)*


---

### Block 63: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 3
- **索引**: 44.0
- **bbox**: `BBox(x0=118, y0=493, x1=219, y1=502)`
- **标题级别**: 2

**Content**:

```
7.7. Request Prioritization

```

**Image**: *(has image_base64)*


---

### Block 64: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 45.0
- **bbox**: `BBox(x0=136, y0=505, x1=207, y1=513)`

**Content**:

```
For Fab related

```

**Image**: *(has image_base64)*


---

### Block 65: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 46.0
- **bbox**: `BBox(x0=151, y0=514, x1=289, y1=524)`

**Content**:

```
\Leftrightarrow Priority = Contribution \* Urgent

```

**Image**: *(has image_base64)*


---

### Block 66: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 3
- **索引**: -999.9982
- **bbox**: `BBox(x0=16, y0=18, x1=176, y1=32)`

**Content**:

```
SMI Restricted / e024120

```

**Image**: *(has image_base64)*


---

### Block 67: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 3
- **索引**: -999.9981
- **bbox**: `BBox(x0=392, y0=19, x1=572, y1=32)`

**Content**:

```
Time Now /2026-3-13 10:30

```

**Image**: *(has image_base64)*


---
