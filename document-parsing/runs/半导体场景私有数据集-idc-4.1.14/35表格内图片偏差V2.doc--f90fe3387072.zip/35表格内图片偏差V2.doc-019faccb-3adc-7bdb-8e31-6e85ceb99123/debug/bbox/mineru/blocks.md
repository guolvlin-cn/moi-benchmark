# MinerU Parser Debug Output

**生成时间**: 2026-07-29T15:34:03.742189

**Block 总数**: 29


---

## 类型统计

| 类型 | 数量 |
|------|------|
| header | 1 |
| text | 20 |
| title | 8 |

---

## Block 详情

### Block 0: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 1.0
- **bbox**: `BBox(x0=67, y0=185, x1=178, y1=211)`
- **标题级别**: 1

**Content**:

```
1.测试方案

```

**Image**: *(has image_base64)*


---

### Block 1: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 2.0
- **bbox**: `BBox(x0=67, y0=227, x1=176, y1=247)`
- **标题级别**: 2

**Content**:

```
1.1．前置条件

```

**Image**: *(has image_base64)*


---

### Block 2: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 3.0
- **bbox**: `BBox(x0=67, y0=258, x1=229, y1=278)`
- **标题级别**: 3

**Content**:

```
1.1.1. 输入前置条件

```

**Image**: *(has image_base64)*


---

### Block 3: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 4.0
- **bbox**: `BBox(x0=107, y0=292, x1=246, y1=306)`

**Content**:

```
描述文字，参考附件xxxxxx

```

**Image**: *(has image_base64)*


---

### Block 4: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 5.0
- **bbox**: `BBox(x0=108, y0=323, x1=200, y1=336)`

**Content**:

```
A. 编号缩进项目 1

```

**Image**: *(has image_base64)*


---

### Block 5: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 6.0
- **bbox**: `BBox(x0=144, y0=354, x1=244, y1=367)`

**Content**:

```
编号缩进项目1行文

```

**Image**: *(has image_base64)*


---

### Block 6: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 7.0
- **bbox**: `BBox(x0=67, y0=383, x1=229, y1=402)`
- **标题级别**: 3

**Content**:

```
1.1.2. 系统状态描述

```

**Image**: *(has image_base64)*


---

### Block 7: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 8.0
- **bbox**: `BBox(x0=108, y0=417, x1=204, y1=430)`

**Content**:

```
三级章节文字内容2

```

**Image**: *(has image_base64)*


---

### Block 8: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 9.0
- **bbox**: `BBox(x0=67, y0=445, x1=208, y1=464)`
- **标题级别**: 2

**Content**:

```
1.2. 测试过程描述

```

**Image**: *(has image_base64)*


---

### Block 9: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 10.0
- **bbox**: `BBox(x0=67, y0=476, x1=260, y1=496)`
- **标题级别**: 3

**Content**:

```
1.2.1. 接口调用规范描述

```

**Image**: *(has image_base64)*


---

### Block 10: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 11.0
- **bbox**: `BBox(x0=108, y0=510, x1=178, y1=523)`

**Content**:

```
A. 调用参数 1

```

**Image**: *(has image_base64)*


---

### Block 11: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 12.0
- **bbox**: `BBox(x0=129, y0=541, x1=314, y1=555)`

**Content**:

```
参数1类型，参数1范围，参数1含义

```

**Image**: *(has image_base64)*


---

### Block 12: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 13.0
- **bbox**: `BBox(x0=108, y0=572, x1=177, y1=585)`

**Content**:

```
B. 调用参数 2

```

**Image**: *(has image_base64)*


---

### Block 13: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 14.0
- **bbox**: `BBox(x0=129, y0=603, x1=314, y1=617)`

**Content**:

```
参数2类型，参数2范围，参数2含义

```

**Image**: *(has image_base64)*


---

### Block 14: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 15.0
- **bbox**: `BBox(x0=108, y0=634, x1=177, y1=647)`

**Content**:

```
C. 调用参数 3

```

**Image**: *(has image_base64)*


---

### Block 15: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 16.0
- **bbox**: `BBox(x0=129, y0=666, x1=314, y1=679)`

**Content**:

```
参数3类型，参数3范围，参数3含义

```

**Image**: *(has image_base64)*


---

### Block 16: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 17.0
- **bbox**: `BBox(x0=67, y0=698, x1=104, y1=709)`

**Content**:

```
Table2:

```

**Image**: *(has image_base64)*


---

### Block 17: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 1
- **索引**: -999.9847
- **bbox**: `BBox(x0=66, y0=153, x1=186, y1=163)`

**Content**:

```
注意：xxxxxxxxxxxxxxxxxx

```

**Image**: *(has image_base64)*


---

### Block 18: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 2
- **索引**: 0.0
- **bbox**: `BBox(x0=211, y0=150, x1=401, y1=167)`

**Content**:

```
TABLE_placeHOLDER_001
```

**Image**: *(no image)*


---

### Block 19: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 2
- **索引**: 1.0
- **bbox**: `BBox(x0=66, y0=619, x1=209, y1=639)`
- **标题级别**: 2

**Content**:

```
1.3. 测试过程描述

```

**Image**: *(has image_base64)*


---

### Block 20: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 2
- **索引**: 2.0
- **bbox**: `BBox(x0=67, y0=650, x1=261, y1=670)`
- **标题级别**: 3

**Content**:

```
1.3.1. 接口调用规范描述

```

**Image**: *(has image_base64)*


---

### Block 21: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 3.0
- **bbox**: `BBox(x0=108, y0=685, x1=179, y1=698)`

**Content**:

```
D. 调用参数 1

```

**Image**: *(has image_base64)*


---

### Block 22: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 4.0
- **bbox**: `BBox(x0=128, y0=716, x1=315, y1=730)`

**Content**:

```
参数1类型，参数1范围，参数1含义

```

**Image**: *(has image_base64)*


---

### Block 23: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 0.0
- **bbox**: `BBox(x0=108, y0=152, x1=176, y1=164)`

**Content**:

```
E. 调用参数 2

```

**Image**: *(has image_base64)*


---

### Block 24: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 1.0
- **bbox**: `BBox(x0=129, y0=183, x1=314, y1=196)`

**Content**:

```
参数2类型，参数2范围，参数2含义

```

**Image**: *(has image_base64)*


---

### Block 25: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 2.0
- **bbox**: `BBox(x0=108, y0=214, x1=175, y1=227)`

**Content**:

```
F. 调用参数 3

```

**Image**: *(has image_base64)*


---

### Block 26: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 3.0
- **bbox**: `BBox(x0=129, y0=245, x1=314, y1=259)`

**Content**:

```
参数3类型，参数3范围，参数3含义

```

**Image**: *(has image_base64)*


---

### Block 27: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 4.0
- **bbox**: `BBox(x0=108, y0=276, x1=179, y1=290)`

**Content**:

```
G. 调用参数 4

```

**Image**: *(has image_base64)*


---

### Block 28: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 5.0
- **bbox**: `BBox(x0=129, y0=307, x1=314, y1=322)`

**Content**:

```
参数4类型，参数4范围，参数4含义

```

**Image**: *(has image_base64)*


---
