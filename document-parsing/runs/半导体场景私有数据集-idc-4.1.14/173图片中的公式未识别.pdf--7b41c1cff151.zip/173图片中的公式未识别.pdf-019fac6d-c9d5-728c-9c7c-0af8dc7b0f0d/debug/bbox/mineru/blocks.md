# MinerU Parser Debug Output

**生成时间**: 2026-07-29T13:51:52.975158

**Block 总数**: 7


---

## 类型统计

| 类型 | 数量 |
|------|------|
| header | 2 |
| image | 1 |
| text | 4 |

---

## Block 详情

### Block 0: image

- **类型**: `image`
- **源类型**: `image`
- **页码**: 1
- **索引**: 2.0
- **bbox**: `BBox(x0=0, y0=63, x1=689, y1=435)`

**Content**:

*(empty)*

**Image**: *(has image_base64)*


---

### Block 1: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 3.0
- **bbox**: `BBox(x0=24, y0=447, x1=486, y1=466)`

**Content**:

```
The average speed? (6 + 3) / 2 = 4.5 \mathrm{~m} / \mathrm{s} ? X (30 + 60) / (20 / 6 + 60 / 3) = 3.6 \mathrm{~m} / \mathrm{s} ?

```

**Image**: *(has image_base64)*


---

### Block 2: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 4.0
- **bbox**: `BBox(x0=25, y0=469, x1=267, y1=487)`

**Content**:

```
Recipe 1: PwPH 1 = 20 , move 1 = 1000

```

**Image**: *(has image_base64)*


---

### Block 3: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 5.0
- **bbox**: `BBox(x0=25, y0=488, x1=267, y1=503)`

**Content**:

```
Recipe 2: PwPH 2=25, move 2=1500

```

**Image**: *(has image_base64)*


---

### Block 4: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 6.0
- **bbox**: `BBox(x0=27, y0=504, x1=367, y1=521)`

**Content**:

```
Average PwPH: 1000+1500)/(1000/20+1500/25)=22.7

```

**Image**: *(has image_base64)*


---

### Block 5: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 1
- **索引**: -999.9977
- **bbox**: `BBox(x0=76, y0=23, x1=221, y1=42)`

**Content**:

```
WPH introduction

```

**Image**: *(has image_base64)*


---

### Block 6: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 1
- **索引**: -999.9989
- **bbox**: `BBox(x0=658, y0=11, x1=709, y1=46)`

**Content**:

```
SMIC

```

**Image**: *(has image_base64)*


---
