# MinerU Parser Debug Output

**生成时间**: 2026-07-29T13:54:47.569012

**Block 总数**: 4


---

## 类型统计

| 类型 | 数量 |
|------|------|
| list | 2 |
| text | 2 |

---

## Block 详情

### Block 0: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 2.0
- **bbox**: `BBox(x0=57, y0=73, x1=138, y1=89)`

**Content**:

```
1. 检测结果
```

**Image**: *(has image_base64)*


---

### Block 1: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 2.001
- **bbox**: `BBox(x0=57, y0=91, x1=200, y1=108)`

**Content**:

```
1.1. 化学因素检测结果
```

**Image**: *(has image_base64)*


---

### Block 2: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 3.0
- **bbox**: `BBox(x0=139, y0=109, x1=456, y1=126)`

**Content**:

```
工作场所空气中读物浓度检测结果 单位： \mathrm{mg / m^3}

```

**Image**: *(has image_base64)*


---

### Block 3: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 1
- **索引**: 4.0
- **bbox**: `BBox(x0=198, y0=134, x1=389, y1=152)`

**Content**:

```
TABLE_placeHOLDER_001
```

**Image**: *(no image)*


---
