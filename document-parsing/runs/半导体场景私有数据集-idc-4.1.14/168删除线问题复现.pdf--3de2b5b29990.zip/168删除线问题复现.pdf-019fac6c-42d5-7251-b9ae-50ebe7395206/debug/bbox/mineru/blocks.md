# MinerU Parser Debug Output

**生成时间**: 2026-07-29T13:50:21.187354

**Block 总数**: 65


---

## 类型统计

| 类型 | 数量 |
|------|------|
| footer | 6 |
| header | 6 |
| image | 3 |
| list | 32 |
| text | 10 |
| title | 8 |

---

## Block 详情

### Block 0: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 1
- **索引**: 2.0
- **bbox**: `BBox(x0=199, y0=83, x1=389, y1=99)`

**Content**:

```
TABLE_placeHOLDER_001
```

**Image**: *(no image)*


---

### Block 1: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 3.0
- **bbox**: `BBox(x0=36, y0=113, x1=226, y1=127)`

**Content**:

```
1. Project background and objectives

```

**Image**: *(has image_base64)*


---

### Block 2: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 8.0
- **bbox**: `BBox(x0=55, y0=128, x1=243, y1=140)`

**Content**:

```
1.1. DCC: Document Control Center
```

**Image**: *(has image_base64)*


---

### Block 3: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 8.001
- **bbox**: `BBox(x0=55, y0=143, x1=426, y1=158)`

**Content**:

```
1.2. DCN: Document Change Notice(for Company Rules and Regulations)
```

**Image**: *(has image_base64)*


---

### Block 4: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 8.002
- **bbox**: `BBox(x0=55, y0=158, x1=273, y1=173)`

**Content**:

```
1.3. DMS: Document Management System
```

**Image**: *(has image_base64)*


---

### Block 5: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 8.003
- **bbox**: `BBox(x0=55, y0=174, x1=196, y1=188)`

**Content**:

```
1.4. Background description
```

**Image**: *(has image_base64)*


---

### Block 6: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 9.0
- **bbox**: `BBox(x0=75, y0=188, x1=554, y1=271)`

**Content**:

```
With the continuous evolution of artificial intelligence technology, large language models (LLM) and multimodal models have demonstrated remarkable capabilities in comprehension, generation, and reasoning. An increasing number of enterprises are beginning to experiment with integrating AI technology into their actual business processes, aiming to enhance information processing efficiency, optimize decision-making quality, and reduce reliance on human experience. Against this backdrop.

```

**Image**: *(has image_base64)*


---

### Block 7: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 10.0
- **bbox**: `BBox(x0=76, y0=272, x1=202, y1=286)`

**Content**:

```
1.4.1. Industry prospects

```

**Image**: *(has image_base64)*


---

### Block 8: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 20.0
- **bbox**: `BBox(x0=98, y0=286, x1=457, y1=301)`

**Content**:

```
A. The current industry as a whole exhibits the following characteristics:
```

**Image**: *(has image_base64)*


---

### Block 9: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 20.001
- **bbox**: `BBox(x0=98, y0=301, x1=552, y1=328)`

**Content**:

```
B. The capabilities of pre-trained models have rapidly improved, but there are still differences in scenario generalization
```

**Image**: *(has image_base64)*


---

### Block 10: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 20.002
- **bbox**: `BBox(x0=97, y0=329, x1=553, y1=357)`

**Content**:

```
C. The scale of internal data within the enterprise continues to grow, leading to a strong demand for intelligent retrieval and analysis
```

**Image**: *(has image_base64)*


---

### Block 11: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 20.003
- **bbox**: `BBox(x0=98, y0=357, x1=553, y1=383)`

**Content**:

```
D. AI systems are gradually evolving from single-point applications towards platformization and servitization
```

**Image**: *(has image_base64)*


---

### Block 12: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 20.004
- **bbox**: `BBox(x0=98, y0=385, x1=204, y1=398)`

**Content**:

```
E. Main pain points
```

**Image**: *(has image_base64)*


---

### Block 13: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 20.005
- **bbox**: `BBox(x0=98, y0=398, x1=524, y1=412)`

**Content**:

```
F. In the actual implementation process, common issues include but are not limited to:
```

**Image**: *(has image_base64)*


---

### Block 14: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 20.006
- **bbox**: `BBox(x0=98, y0=413, x1=553, y1=439)`

**Content**:

```
G. The data sources are complex, with a coexistence of structured, semi-structured, and unstructured data
```

**Image**: *(has image_base64)*


---

### Block 15: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 20.007
- **bbox**: `BBox(x0=98, y0=441, x1=553, y1=469)`

**Content**:

```
H. The coupling between model services and business logic is too high, resulting in poor system maintainability
```

**Image**: *(has image_base64)*


---

### Block 16: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 20.008
- **bbox**: `BBox(x0=98, y0=469, x1=553, y1=495)`

**Content**:

```
I. Without a unified evaluation and monitoring mechanism, it is difficult to continuously ensure the effectiveness of the model
```

**Image**: *(has image_base64)*


---

### Block 17: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 21.0
- **bbox**: `BBox(x0=118, y0=496, x1=553, y1=556)`

**Content**:

```
a. 为了能使 Reticle Stocker 讷讷够正确快速的读取光照条码，光照 MA 必须使用 Barcode Reader 扫描自光照厂所送出的 Barcode (以有效防止人为之输入错误)，之后再利用光照室旁的 Barcode Printer 打印 Reticle ID，并贴雨 Reticle POD 之上。

```

**Image**: *(has image_base64)*


---

### Block 18: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 22.0
- **bbox**: `BBox(x0=118, y0=558, x1=456, y1=573)`

**Content**:

```
b. Barcode 使用 9\mathrm{cm} \times 3\mathrm{cm} 标签打印，它的形式如下（图四）：

```

**Image**: *(has image_base64)*


---

### Block 19: image

- **类型**: `image`
- **源类型**: `image`
- **页码**: 1
- **索引**: 23.0
- **bbox**: `BBox(x0=120, y0=580, x1=351, y1=677)`
- **Captions**: ['图四 Barcode打印实例\n']

**Content**:

*(empty)*

**Image**: *(has image_base64)*


---

### Block 20: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 1
- **索引**: -999.9955
- **bbox**: `BBox(x0=35, y0=45, x1=76, y1=69)`

**Content**:

```
SMIC

```

**Image**: *(has image_base64)*


---

### Block 21: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 1
- **索引**: -999.9939
- **bbox**: `BBox(x0=76, y0=61, x1=343, y1=74)`

**Content**:

```
Semiconductor Manufacturing International Corporation

```

**Image**: *(has image_base64)*


---

### Block 22: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 1
- **索引**: 9999.0747
- **bbox**: `BBox(x0=34, y0=747, x1=553, y1=770)`

**Content**:

```
The information contained herein is exclusive property of SIMC, and shall not be distributed, reproduced, or disclosed in whole or in part without priorwritten permission of SMIC

```

**Image**: *(has image_base64)*


---

### Block 23: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 1
- **索引**: 9999.078
- **bbox**: `BBox(x0=35, y0=780, x1=436, y1=792)`

**Content**:

```
According to :SMIC Document Control Procedure;Attachment No.: QR-QUSM-02-2001-002;Rev.:3

```

**Image**: *(has image_base64)*


---

### Block 24: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 2
- **索引**: 2.0
- **bbox**: `BBox(x0=199, y0=83, x1=390, y1=98)`

**Content**:

```
TABLE_placeHOLDER_002
```

**Image**: *(no image)*


---

### Block 25: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 3.0
- **bbox**: `BBox(x0=119, y0=113, x1=553, y1=158)`

**Content**:

```
c. Recicle POD Size: 227.33 \mathrm{~W} \times 230 \mathrm{~L} \times 92.2 \mathrm{H}(\mathrm{mm}) . Barcode 打印完毕后, 要贴在 Reticle POD 的适当位置上, 才能被 Reticle Stock 顺利地读出。Barcode 贴在 POD 上的位置如下 (图五) 所示:

```

**Image**: *(has image_base64)*


---

### Block 26: image

- **类型**: `image`
- **源类型**: `image`
- **页码**: 2
- **索引**: 4.0
- **bbox**: `BBox(x0=83, y0=160, x1=312, y1=285)`

**Content**:

*(empty)*

**Image**: *(has image_base64)*


---

### Block 27: image

- **类型**: `image`
- **源类型**: `image`
- **页码**: 2
- **索引**: 5.0
- **bbox**: `BBox(x0=346, y0=160, x1=534, y1=285)`
- **Captions**: ['图五 Barcode 位置及贴法\n']

**Content**:

*(empty)*

**Image**: *(has image_base64)*


---

### Block 28: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 2
- **索引**: 7.0
- **bbox**: `BBox(x0=55, y0=316, x1=153, y1=330)`
- **标题级别**: 2

**Content**:

```
1.5. 技术选型说明

```

**Image**: *(has image_base64)*


---

### Block 29: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 2
- **索引**: 8.0
- **bbox**: `BBox(x0=76, y0=332, x1=198, y1=345)`
- **标题级别**: 3

**Content**:

```
1.5.1. 后端与基础设施

```

**Image**: *(has image_base64)*


---

### Block 30: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 13.0
- **bbox**: `BBox(x0=116, y0=355, x1=232, y1=370)`

**Content**:

```
编程语言：Python
```

**Image**: *(has image_base64)*


---

### Block 31: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 13.001
- **bbox**: `BBox(x0=116, y0=386, x1=237, y1=400)`

**Content**:

```
- 服务框架：FastAPI
```

**Image**: *(has image_base64)*


---

### Block 32: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 13.002
- **bbox**: `BBox(x0=116, y0=417, x1=268, y1=431)`

**Content**:

```
- 模型部署：vLLM/Triton
```

**Image**: *(has image_base64)*


---

### Block 33: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 13.003
- **bbox**: `BBox(x0=116, y0=448, x1=312, y1=462)`

**Content**:

```
- 容器与编排：Docker + Kubernetes
```

**Image**: *(has image_base64)*


---

### Block 34: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 2
- **索引**: 14.0
- **bbox**: `BBox(x0=76, y0=471, x1=162, y1=486)`
- **标题级别**: 3

**Content**:

```
1.5.2. 模型相关

```

**Image**: *(has image_base64)*


---

### Block 35: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 18.0
- **bbox**: `BBox(x0=116, y0=495, x1=238, y1=509)`

**Content**:

```
- 大语言模型 (LLM)
```

**Image**: *(has image_base64)*


---

### Block 36: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 18.001
- **bbox**: `BBox(x0=116, y0=526, x1=256, y1=542)`

**Content**:

```
向量模型 (Embedding)
```

**Image**: *(has image_base64)*


---

### Block 37: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 18.002
- **bbox**: `BBox(x0=116, y0=558, x1=240, y1=572)`

**Content**:

```
- RAG 检索增强生成
```

**Image**: *(has image_base64)*


---

### Block 38: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 2
- **索引**: 19.0
- **bbox**: `BBox(x0=76, y0=581, x1=186, y1=595)`
- **标题级别**: 3

**Content**:

```
1.5.3. 其他模型相关

```

**Image**: *(has image_base64)*


---

### Block 39: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 23.0
- **bbox**: `BBox(x0=116, y0=604, x1=240, y1=618)`

**Content**:

```
- 视觉大模型 (VLM)
```

**Image**: *(has image_base64)*


---

### Block 40: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 23.001
- **bbox**: `BBox(x0=116, y0=635, x1=256, y1=650)`

**Content**:

```
向量模型 (Embedding)
```

**Image**: *(has image_base64)*


---

### Block 41: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 23.002
- **bbox**: `BBox(x0=116, y0=666, x1=240, y1=681)`

**Content**:

```
- RAG 检索增强生成
```

**Image**: *(has image_base64)*


---

### Block 42: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 2
- **索引**: 24.0
- **bbox**: `BBox(x0=55, y0=690, x1=230, y1=703)`
- **标题级别**: 2

**Content**:

```
1.6. Technical selection description

```

**Image**: *(has image_base64)*


---

### Block 43: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 2
- **索引**: 25.0
- **bbox**: `BBox(x0=76, y0=704, x1=244, y1=716)`
- **标题级别**: 3

**Content**:

```
1.6.1. Backend and Infrastructure

```

**Image**: *(has image_base64)*


---

### Block 44: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 28.0
- **bbox**: `BBox(x0=116, y0=719, x1=290, y1=733)`

**Content**:

```
- Programming language: Python
```

**Image**: *(has image_base64)*


---

### Block 45: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 28.001
- **bbox**: `BBox(x0=116, y0=735, x1=274, y1=746)`

**Content**:

```
Service framework: FastAPI
```

**Image**: *(has image_base64)*


---

### Block 46: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 29.0
- **bbox**: `BBox(x0=34, y0=748, x1=553, y1=770)`

**Content**:

```
The information contained herein is exclusive property of SIMC, and shall not be distributed, reproduced, or disclosed in whole or in part without prior written permission of SMIC

```

**Image**: *(has image_base64)*


---

### Block 47: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 2
- **索引**: -999.9954
- **bbox**: `BBox(x0=35, y0=46, x1=76, y1=69)`

**Content**:

```
SMIC

```

**Image**: *(has image_base64)*


---

### Block 48: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 2
- **索引**: -999.9939
- **bbox**: `BBox(x0=77, y0=61, x1=343, y1=74)`

**Content**:

```
Semiconfuctor Manufacturing International Corporation

```

**Image**: *(has image_base64)*


---

### Block 49: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 2
- **索引**: 9999.078
- **bbox**: `BBox(x0=35, y0=780, x1=436, y1=792)`

**Content**:

```
According to :SMIC Document Control Procedure;Attachment No.: QR-QUSM-02-2001-002;Rev.:3

```

**Image**: *(has image_base64)*


---

### Block 50: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 3
- **索引**: 2.0
- **bbox**: `BBox(x0=199, y0=83, x1=390, y1=99)`

**Content**:

```
TABLE_placeHOLDER_003
```

**Image**: *(no image)*


---

### Block 51: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 5.0
- **bbox**: `BBox(x0=116, y0=114, x1=305, y1=127)`

**Content**:

```
- Model deployment: vLLM / Triton
```

**Image**: *(has image_base64)*


---

### Block 52: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 5.001
- **bbox**: `BBox(x0=116, y0=130, x1=383, y1=142)`

**Content**:

```
- Containers and orchestration: Docker + Kubernetes
```

**Image**: *(has image_base64)*


---

### Block 53: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 3
- **索引**: 6.0
- **bbox**: `BBox(x0=76, y0=144, x1=182, y1=157)`
- **标题级别**: 3

**Content**:

```
1.6.2. Model-related

```

**Image**: *(has image_base64)*


---

### Block 54: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 10.0
- **bbox**: `BBox(x0=116, y0=159, x1=286, y1=173)`

**Content**:

```
Large Language Model (LLM)
```

**Image**: *(has image_base64)*


---

### Block 55: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 10.001
- **bbox**: `BBox(x0=116, y0=175, x1=269, y1=190)`

**Content**:

```
- Vector model (Embedding)
```

**Image**: *(has image_base64)*


---

### Block 56: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 10.002
- **bbox**: `BBox(x0=116, y0=191, x1=327, y1=204)`

**Content**:

```
RAG: Retrieval Augmented Generation
```

**Image**: *(has image_base64)*


---

### Block 57: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 3
- **索引**: 11.0
- **bbox**: `BBox(x0=76, y0=205, x1=211, y1=217)`
- **标题级别**: 3

**Content**:

```
1.6.3. Other model-related

```

**Image**: *(has image_base64)*


---

### Block 58: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 14.0
- **bbox**: `BBox(x0=116, y0=220, x1=271, y1=234)`

**Content**:

```
Visual Large Model (VLM)
```

**Image**: *(has image_base64)*


---

### Block 59: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 14.001
- **bbox**: `BBox(x0=116, y0=236, x1=269, y1=249)`

**Content**:

```
- Vector model (Embedding)
```

**Image**: *(has image_base64)*


---

### Block 60: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 3
- **索引**: -999.9955
- **bbox**: `BBox(x0=36, y0=45, x1=76, y1=69)`

**Content**:

```
SMIC

```

**Image**: *(has image_base64)*


---

### Block 61: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 3
- **索引**: -999.9939
- **bbox**: `BBox(x0=77, y0=61, x1=343, y1=74)`

**Content**:

```
Semiconfuctor Manufacturing International Corporation

```

**Image**: *(has image_base64)*


---

### Block 62: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 3
- **索引**: 9999.0747
- **bbox**: `BBox(x0=35, y0=747, x1=553, y1=770)`

**Content**:

```
The information contained herein is exclusive property of SIMC, and shall not be distributed, reproduced, or disclosed in whole or in part without priornwrittn permission of SMIC

```

**Image**: *(has image_base64)*


---

### Block 63: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 3
- **索引**: 9999.078
- **bbox**: `BBox(x0=35, y0=780, x1=436, y1=792)`

**Content**:

```
According to :SMIC Document Control Procedure;Attachment No.: QR-QUSM-02-2001-002;Rev.:3

```

**Image**: *(has image_base64)*


---

### Block 64: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 3
- **索引**: 9999.078
- **bbox**: `BBox(x0=474, y0=780, x1=518, y1=790)`

**Content**:

```
2026-1-30

```

**Image**: *(has image_base64)*


---
