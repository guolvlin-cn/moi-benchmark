# MinerU Parser Debug Output

**生成时间**: 2026-07-29T18:24:20.421482

**Block 总数**: 15


---

## 类型统计

| 类型 | 数量 |
|------|------|
| equation | 2 |
| footer | 3 |
| header | 2 |
| text | 5 |
| title | 3 |

---

## Block 详情

### Block 0: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 2.0
- **bbox**: `BBox(x0=378, y0=63, x1=462, y1=85)`
- **标题级别**: 1

**Content**:

```
线性回归

```

**Image**: *(has image_base64)*


---

### Block 1: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 3.0
- **bbox**: `BBox(x0=137, y0=117, x1=198, y1=131)`
- **标题级别**: 1

**Content**:

```
1、线性回归

```

**Image**: *(has image_base64)*


---

### Block 2: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 4.0
- **bbox**: `BBox(x0=136, y0=136, x1=793, y1=169)`

**Content**:

```
线性回归时回归问题的一种，线性回归利用称为线性回归方程的最小平方函数对一个或多个自变量和因变量之间关系进行建模。这种函数是一个或多个称为回归系数的模型参数的线性组合。只有一个自变量的情况称为简单线性回归，大于一个自变量情况的叫做多元线性回归。

```

**Image**: *(has image_base64)*


---

### Block 3: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 5.0
- **bbox**: `BBox(x0=137, y0=173, x1=212, y1=187)`

**Content**:

```
线性回归模型为

```

**Image**: *(has image_base64)*


---

### Block 4: equation

- **类型**: `equation`
- **源类型**: `interline_equation`
- **页码**: 1
- **索引**: 6.0
- **bbox**: `BBox(x0=440, y0=191, x1=494, y1=205)`

**Content**:

```
\hat {y} = w x + b

```

**Image**: *(has image_base64)*


---

### Block 5: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 7.0
- **bbox**: `BBox(x0=136, y0=211, x1=588, y1=225)`

**Content**:

```
\widehat{y} 为预测值，自变量x和因变量y是一致的，目标是通过已知数据点，求解线性模型中的w和b两个参数。

```

**Image**: *(has image_base64)*


---

### Block 6: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 8.0
- **bbox**: `BBox(x0=143, y0=231, x1=209, y1=243)`
- **标题级别**: 1

**Content**:

```
(1) 损失函数

```

**Image**: *(has image_base64)*


---

### Block 7: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 9.0
- **bbox**: `BBox(x0=136, y0=248, x1=792, y1=279)`

**Content**:

```
针对任何模型求解问题，最终都是可以得到一组预测值 \hat{y} ，对于已有的真实值 y ，数据行数为 n ，可以得到预测值与真实值之间的平均饿平方距离，统计中一般称其为MAE（mean square error）均方误差，公式如下：

```

**Image**: *(has image_base64)*


---

### Block 8: equation

- **类型**: `equation`
- **源类型**: `interline_equation`
- **页码**: 1
- **索引**: 10.0
- **bbox**: `BBox(x0=425, y0=272, x1=510, y1=306)`

**Content**:

```
L ^ {\vdots} = \frac {1}{n} \sum_ {i = 1} ^ {n} (\hat {y} _ {1} - y _ {i}) ^ {2}

```

**Image**: *(has image_base64)*


---

### Block 9: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 11.0
- **bbox**: `BBox(x0=137, y0=305, x1=236, y1=319)`

**Content**:

```
该公式称为损失函数。

```

**Image**: *(has image_base64)*


---

### Block 10: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 1
- **索引**: -999.999
- **bbox**: `BBox(x0=14, y0=10, x1=223, y1=30)`

**Content**:

```
Confidential/xzixong261030

```

**Image**: *(has image_base64)*


---

### Block 11: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 1
- **索引**: -999.9988
- **bbox**: `BBox(x0=744, y0=12, x1=876, y1=27)`

**Content**:

```
2026年7月29日18时24分

```

**Image**: *(has image_base64)*


---

### Block 12: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 1
- **索引**: 9999.0504
- **bbox**: `BBox(x0=65, y0=504, x1=111, y1=529)`

**Content**:

```
SMIC

```

**Image**: *(has image_base64)*


---

### Block 13: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 1
- **索引**: 9999.0505
- **bbox**: `BBox(x0=456, y0=505, x1=533, y1=514)`

**Content**:

```
MatrixOne Intelligence

```

**Image**: *(has image_base64)*


---

### Block 14: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 1
- **索引**: 9999.0514
- **bbox**: `BBox(x0=305, y0=514, x1=685, y1=524)`

**Content**:

```
Copyright © 2026 矩阵起源（深圳）信息科技有限公司粤公安网备44030402004672号|粤ICP备2021044820号

```

**Image**: *(has image_base64)*


---
