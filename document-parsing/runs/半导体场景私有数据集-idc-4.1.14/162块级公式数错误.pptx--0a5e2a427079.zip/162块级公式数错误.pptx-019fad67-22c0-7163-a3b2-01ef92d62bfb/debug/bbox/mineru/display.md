# MINERU BBox Visualization

## Page 1

![Page 1](./pages/page-1.webp)
