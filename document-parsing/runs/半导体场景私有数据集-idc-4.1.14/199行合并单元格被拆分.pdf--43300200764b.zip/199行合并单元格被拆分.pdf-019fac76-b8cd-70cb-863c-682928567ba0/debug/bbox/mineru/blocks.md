# MinerU Parser Debug Output

**生成时间**: 2026-07-29T14:01:51.639123

**Block 总数**: 60


---

## 类型统计

| 类型 | 数量 |
|------|------|
| footer | 8 |
| header | 8 |
| list | 16 |
| text | 18 |
| title | 10 |

---

## Block 详情

### Block 0: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 1.0
- **bbox**: `BBox(x0=58, y0=61, x1=214, y1=86)`
- **标题级别**: 1

**Content**:

```
1. 检测结果总结

```

**Image**: *(has image_base64)*


---

### Block 1: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 2.0
- **bbox**: `BBox(x0=216, y0=97, x1=373, y1=123)`
- **标题级别**: 1

**Content**:

```
检测结果报告单

```

**Image**: *(has image_base64)*


---

### Block 2: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 1
- **索引**: 3.0
- **bbox**: `BBox(x0=198, y0=133, x1=388, y1=151)`

**Content**:

```
TABLE_placeHOLDER_001
```

**Image**: *(no image)*


---

### Block 3: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 4.0
- **bbox**: `BBox(x0=257, y0=362, x1=331, y1=375)`

**Content**:

```
(本页以下空白)

```

**Image**: *(has image_base64)*


---

### Block 4: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 5.0
- **bbox**: `BBox(x0=373, y0=642, x1=521, y1=655)`

**Content**:

```
利诚检测认证集团股份有限公司

```

**Image**: *(has image_base64)*


---

### Block 5: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 6.0
- **bbox**: `BBox(x0=433, y0=658, x1=520, y1=670)`

**Content**:

```
2025年07月15日

```

**Image**: *(has image_base64)*


---

### Block 6: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 7.0
- **bbox**: `BBox(x0=56, y0=686, x1=123, y1=699)`

**Content**:

```
编制人：陈某

```

**Image**: *(has image_base64)*


---

### Block 7: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 8.0
- **bbox**: `BBox(x0=188, y0=686, x1=264, y1=699)`

**Content**:

```
审核人：曾某某

```

**Image**: *(has image_base64)*


---

### Block 8: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 9.0
- **bbox**: `BBox(x0=309, y0=686, x1=443, y1=699)`

**Content**:

```
签发 (授权签字人)：成某某

```

**Image**: *(has image_base64)*


---

### Block 9: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 10.0
- **bbox**: `BBox(x0=57, y0=755, x1=180, y1=772)`
- **标题级别**: 1

**Content**:

```
1. 采样及检测数据

```

**Image**: *(has image_base64)*


---

### Block 10: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 1
- **索引**: -999.996
- **bbox**: `BBox(x0=419, y0=40, x1=531, y1=52)`

**Content**:

```
报告编号：LC-ZX250050-1

```

**Image**: *(has image_base64)*


---

### Block 11: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 1
- **索引**: 9999.0796
- **bbox**: `BBox(x0=57, y0=796, x1=176, y1=807)`

**Content**:

```
利诚检测认证集团股份有限共

```

**Image**: *(has image_base64)*


---

### Block 12: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 9.0
- **bbox**: `BBox(x0=79, y0=56, x1=215, y1=69)`

**Content**:

```
(1) 《工作场所空气中xxxx》
```

**Image**: *(has image_base64)*


---

### Block 13: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 9.001
- **bbox**: `BBox(x0=79, y0=72, x1=215, y1=85)`

**Content**:

```
(2) 《工作场所空气中xxxx》
```

**Image**: *(has image_base64)*


---

### Block 14: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 9.002
- **bbox**: `BBox(x0=79, y0=88, x1=215, y1=101)`

**Content**:

```
(3) 《工作场所空气中xxxx》
```

**Image**: *(has image_base64)*


---

### Block 15: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 9.003
- **bbox**: `BBox(x0=79, y0=104, x1=215, y1=116)`

**Content**:

```
(4) 《工作场所空气中xxxx》
```

**Image**: *(has image_base64)*


---

### Block 16: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 9.004
- **bbox**: `BBox(x0=79, y0=119, x1=215, y1=132)`

**Content**:

```
(5) 《工作场所空气中xxxx》
```

**Image**: *(has image_base64)*


---

### Block 17: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 9.005
- **bbox**: `BBox(x0=79, y0=135, x1=215, y1=148)`

**Content**:

```
(6) 《工作场所空气中xxxx》
```

**Image**: *(has image_base64)*


---

### Block 18: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 9.006
- **bbox**: `BBox(x0=79, y0=150, x1=215, y1=163)`

**Content**:

```
(7) 《工作场所空气中xxxx》
```

**Image**: *(has image_base64)*


---

### Block 19: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 9.007
- **bbox**: `BBox(x0=79, y0=165, x1=215, y1=179)`

**Content**:

```
(8) 《工作场所空气中xxxx》
```

**Image**: *(has image_base64)*


---

### Block 20: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 2
- **索引**: 10.0
- **bbox**: `BBox(x0=56, y0=187, x1=178, y1=204)`
- **标题级别**: 1

**Content**:

```
2. 仪器名称及编号

```

**Image**: *(has image_base64)*


---

### Block 21: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 2
- **索引**: 11.0
- **bbox**: `BBox(x0=56, y0=213, x1=179, y1=226)`
- **标题级别**: 2

**Content**:

```
2.1. 采样仪器名称及编号：

```

**Image**: *(has image_base64)*


---

### Block 22: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 17.0
- **bbox**: `BBox(x0=79, y0=229, x1=229, y1=242)`

**Content**:

```
(1) EM-1500 气体采样器 xxxxx
```

**Image**: *(has image_base64)*


---

### Block 23: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 17.001
- **bbox**: `BBox(x0=79, y0=244, x1=229, y1=257)`

**Content**:

```
(2) EM-1500 气体采样器 xxxxx
```

**Image**: *(has image_base64)*


---

### Block 24: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 17.002
- **bbox**: `BBox(x0=79, y0=260, x1=229, y1=272)`

**Content**:

```
(3) EM-1500 气体采样器 xxxxxx
```

**Image**: *(has image_base64)*


---

### Block 25: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 17.003
- **bbox**: `BBox(x0=79, y0=275, x1=229, y1=288)`

**Content**:

```
(4) EM-1500 气体采样器 xxxxx
```

**Image**: *(has image_base64)*


---

### Block 26: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 17.004
- **bbox**: `BBox(x0=79, y0=291, x1=229, y1=304)`

**Content**:

```
(5) EM-1500 气体采样器 xxxxxx
```

**Image**: *(has image_base64)*


---

### Block 27: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 2
- **索引**: 18.0
- **bbox**: `BBox(x0=56, y0=307, x1=179, y1=320)`
- **标题级别**: 2

**Content**:

```
2.2. 检测一起名称及编号：

```

**Image**: *(has image_base64)*


---

### Block 28: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 22.0
- **bbox**: `BBox(x0=79, y0=323, x1=184, y1=336)`

**Content**:

```
(1) UV-1900IXXXXXXX
```

**Image**: *(has image_base64)*


---

### Block 29: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 22.001
- **bbox**: `BBox(x0=79, y0=339, x1=179, y1=351)`

**Content**:

```
(2) PF-1-01XXXXXX
```

**Image**: *(has image_base64)*


---

### Block 30: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 22.002
- **bbox**: `BBox(x0=79, y0=354, x1=196, y1=367)`

**Content**:

```
(3) GXH-2010XXXXXX
```

**Image**: *(has image_base64)*


---

### Block 31: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 2
- **索引**: 23.0
- **bbox**: `BBox(x0=56, y0=377, x1=192, y1=394)`
- **标题级别**: 1

**Content**:

```
3. 最低定量浓度情况

```

**Image**: *(has image_base64)*


---

### Block 32: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 2
- **索引**: 24.0
- **bbox**: `BBox(x0=198, y0=410, x1=389, y1=427)`

**Content**:

```
TABLE_placeHOLDER_002
```

**Image**: *(no image)*


---

### Block 33: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 2
- **索引**: -999.996
- **bbox**: `BBox(x0=419, y0=40, x1=530, y1=51)`

**Content**:

```
报告编号：LC-ZX250050-1

```

**Image**: *(has image_base64)*


---

### Block 34: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 2
- **索引**: 9999.0796
- **bbox**: `BBox(x0=57, y0=796, x1=176, y1=807)`

**Content**:

```
利诚检测认证集团股份有限共

```

**Image**: *(has image_base64)*


---

### Block 35: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 3
- **索引**: 1.0
- **bbox**: `BBox(x0=55, y0=56, x1=171, y1=81)`
- **标题级别**: 1

**Content**:

```
2. 检测结果

```

**Image**: *(has image_base64)*


---

### Block 36: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 3
- **索引**: 2.0
- **bbox**: `BBox(x0=55, y0=89, x1=215, y1=109)`
- **标题级别**: 2

**Content**:

```
2.1.化学因素检测结果

```

**Image**: *(has image_base64)*


---

### Block 37: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 3.0
- **bbox**: `BBox(x0=112, y0=116, x1=477, y1=138)`

**Content**:

```
工作场所空气中读物浓度检测结果 单位： \mathrm{mg / m^3}

```

**Image**: *(has image_base64)*


---

### Block 38: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 3
- **索引**: 4.0
- **bbox**: `BBox(x0=199, y0=144, x1=392, y1=161)`

**Content**:

```
TABLE_placeHOLDER_003
```

**Image**: *(no image)*


---

### Block 39: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 3
- **索引**: -999.996
- **bbox**: `BBox(x0=419, y0=40, x1=531, y1=52)`

**Content**:

```
报告编号：LC-ZX250050-1

```

**Image**: *(has image_base64)*


---

### Block 40: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 3
- **索引**: 9999.0796
- **bbox**: `BBox(x0=57, y0=796, x1=176, y1=807)`

**Content**:

```
利诚检测认证集团股份有限共

```

**Image**: *(has image_base64)*


---

### Block 41: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 4
- **索引**: 1.0
- **bbox**: `BBox(x0=200, y0=62, x1=390, y1=78)`

**Content**:

```
TABLE_placeHOLDER_004
```

**Image**: *(no image)*


---

### Block 42: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 4
- **索引**: -999.996
- **bbox**: `BBox(x0=419, y0=40, x1=530, y1=51)`

**Content**:

```
报告编号：LC-ZX250050-1

```

**Image**: *(has image_base64)*


---

### Block 43: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 4
- **索引**: 9999.0796
- **bbox**: `BBox(x0=57, y0=796, x1=176, y1=807)`

**Content**:

```
利诚检测认证集团股份有限共

```

**Image**: *(has image_base64)*


---

### Block 44: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 5
- **索引**: 1.0
- **bbox**: `BBox(x0=199, y0=62, x1=391, y1=79)`

**Content**:

```
TABLE_placeHOLDER_005
```

**Image**: *(no image)*


---

### Block 45: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 5
- **索引**: -999.996
- **bbox**: `BBox(x0=419, y0=40, x1=530, y1=51)`

**Content**:

```
报告编号：LC-ZX250050-1

```

**Image**: *(has image_base64)*


---

### Block 46: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 5
- **索引**: 9999.0796
- **bbox**: `BBox(x0=57, y0=796, x1=176, y1=807)`

**Content**:

```
利诚检测认证集团股份有限共

```

**Image**: *(has image_base64)*


---

### Block 47: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 6
- **索引**: 1.0
- **bbox**: `BBox(x0=200, y0=62, x1=391, y1=79)`

**Content**:

```
TABLE_placeHOLDER_006
```

**Image**: *(no image)*


---

### Block 48: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 6
- **索引**: -999.996
- **bbox**: `BBox(x0=419, y0=40, x1=530, y1=51)`

**Content**:

```
报告编号：LC-ZX250050-1

```

**Image**: *(has image_base64)*


---

### Block 49: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 6
- **索引**: 9999.0796
- **bbox**: `BBox(x0=57, y0=796, x1=176, y1=807)`

**Content**:

```
利诚检测认证集团股份有限共

```

**Image**: *(has image_base64)*


---

### Block 50: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 7
- **索引**: 1.0
- **bbox**: `BBox(x0=199, y0=60, x1=390, y1=76)`

**Content**:

```
TABLE_placeHOLDER_007
```

**Image**: *(no image)*


---

### Block 51: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 7
- **索引**: 2.0
- **bbox**: `BBox(x0=57, y0=140, x1=101, y1=153)`

**Content**:

```
以下空白

```

**Image**: *(has image_base64)*


---

### Block 52: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 7
- **索引**: -999.996
- **bbox**: `BBox(x0=419, y0=40, x1=530, y1=51)`

**Content**:

```
报告编号：LC-ZX250050-1

```

**Image**: *(has image_base64)*


---

### Block 53: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 7
- **索引**: 9999.0796
- **bbox**: `BBox(x0=57, y0=796, x1=176, y1=807)`

**Content**:

```
利诚检测认证集团股份有限共

```

**Image**: *(has image_base64)*


---

### Block 54: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 8
- **索引**: 1.0
- **bbox**: `BBox(x0=56, y0=56, x1=389, y1=80)`
- **标题级别**: 1

**Content**:

```
3. 工作场所有害因素职业接触限制

```

**Image**: *(has image_base64)*


---

### Block 55: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 8
- **索引**: 2.0
- **bbox**: `BBox(x0=57, y0=84, x1=166, y1=98)`

**Content**:

```
化学因素职业接触限值

```

**Image**: *(has image_base64)*


---

### Block 56: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 8
- **索引**: 3.0
- **bbox**: `BBox(x0=193, y0=108, x1=384, y1=125)`

**Content**:

```
TABLE_placeHOLDER_008
```

**Image**: *(no image)*


---

### Block 57: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 8
- **索引**: 4.0
- **bbox**: `BBox(x0=247, y0=465, x1=341, y1=483)`

**Content**:

```
***报告结束***

```

**Image**: *(has image_base64)*


---

### Block 58: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 8
- **索引**: -999.996
- **bbox**: `BBox(x0=419, y0=40, x1=531, y1=52)`

**Content**:

```
报告编号：LC-ZX250050-1

```

**Image**: *(has image_base64)*


---

### Block 59: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 8
- **索引**: 9999.0796
- **bbox**: `BBox(x0=57, y0=796, x1=176, y1=807)`

**Content**:

```
利诚检测认证集团股份有限共

```

**Image**: *(has image_base64)*


---
