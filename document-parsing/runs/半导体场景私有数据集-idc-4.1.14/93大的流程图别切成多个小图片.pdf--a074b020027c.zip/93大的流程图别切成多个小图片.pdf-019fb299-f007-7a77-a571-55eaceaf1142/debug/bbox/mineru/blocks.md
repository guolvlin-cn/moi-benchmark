# MinerU Parser Debug Output

**生成时间**: 2026-07-30T18:38:51.365526

**Block 总数**: 18


---

## 类型统计

| 类型 | 数量 |
|------|------|
| header | 1 |
| image | 10 |
| text | 6 |
| title | 1 |

---

## Block 详情

### Block 0: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 1.0
- **bbox**: `BBox(x0=160, y0=104, x1=434, y1=116)`
- **标题级别**: 1

**Content**:

```
SEMCUREEDTOR MANUFACTURING PROCESS FLOWCHART

```

**Image**: *(has image_base64)*


---

### Block 1: image

- **类型**: `image`
- **源类型**: `image`
- **页码**: 1
- **索引**: 2.0
- **bbox**: `BBox(x0=110, y0=138, x1=220, y1=253)`

**Content**:

*(empty)*

**Image**: *(has image_base64)*


---

### Block 2: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 3.0
- **bbox**: `BBox(x0=117, y0=259, x1=220, y1=283)`

**Content**:

```
Sillion ingots are sfed inio thin wafers. Scatter plot sheaion the between wafer thickness and uniformity.

```

**Image**: *(has image_base64)*


---

### Block 3: image

- **类型**: `image`
- **源类型**: `image`
- **页码**: 1
- **索引**: 4.0
- **bbox**: `BBox(x0=221, y0=200, x1=240, y1=219)`

**Content**:

*(empty)*

**Image**: *(has image_base64)*


---

### Block 4: image

- **类型**: `image`
- **源类型**: `image`
- **页码**: 1
- **索引**: 6.0
- **bbox**: `BBox(x0=245, y0=157, x1=346, y1=253)`
- **Captions**: ['Photolithography\n']

**Content**:

*(empty)*

**Image**: *(has image_base64)*


---

### Block 5: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 7.0
- **bbox**: `BBox(x0=246, y0=259, x1=345, y1=283)`

**Content**:

```
Patterns are transferred onlo the the water Ine cater ahowe the exposure time vs feckire stre accuracy.

```

**Image**: *(has image_base64)*


---

### Block 6: image

- **类型**: `image`
- **源类型**: `image`
- **页码**: 1
- **索引**: 8.0
- **bbox**: `BBox(x0=349, y0=200, x1=368, y1=219)`

**Content**:

*(empty)*

**Image**: *(has image_base64)*


---

### Block 7: image

- **类型**: `image`
- **源类型**: `image`
- **页码**: 1
- **索引**: 10.0
- **bbox**: `BBox(x0=372, y0=157, x1=476, y1=253)`
- **Captions**: ['Etching\n']

**Content**:

*(empty)*

**Image**: *(has image_base64)*


---

### Block 8: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 11.0
- **bbox**: `BBox(x0=383, y0=259, x1=464, y1=283)`

**Content**:

```
Unvanted material is removed Scatter plot shoaia ahows etch depth against aolesicity ratio.

```

**Image**: *(has image_base64)*


---

### Block 9: image

- **类型**: `image`
- **源类型**: `image`
- **页码**: 1
- **索引**: 12.0
- **bbox**: `BBox(x0=287, y0=300, x1=305, y1=318)`

**Content**:

*(empty)*

**Image**: *(has image_base64)*


---

### Block 10: image

- **类型**: `image`
- **源类型**: `image`
- **页码**: 1
- **索引**: 13.0
- **bbox**: `BBox(x0=417, y0=300, x1=434, y1=318)`

**Content**:

*(empty)*

**Image**: *(has image_base64)*


---

### Block 11: image

- **类型**: `image`
- **源类型**: `image`
- **页码**: 1
- **索引**: 15.0
- **bbox**: `BBox(x0=113, y0=342, x1=216, y1=434)`
- **Captions**: ['Ion Implantation\n']

**Content**:

*(empty)*

**Image**: *(has image_base64)*


---

### Block 12: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 16.0
- **bbox**: `BBox(x0=124, y0=440, x1=210, y1=470)`

**Content**:

```
Introducing impurities to change to change alethic progre allein scatter iccn pckes linncettaith putthers, elenstste to fulf.

```

**Image**: *(has image_base64)*


---

### Block 13: image

- **类型**: `image`
- **源类型**: `image`
- **页码**: 1
- **索引**: 18.0
- **bbox**: `BBox(x0=246, y0=343, x1=346, y1=434)`
- **Captions**: ['Thin Film Deposition\n']

**Content**:

*(empty)*

**Image**: *(has image_base64)*


---

### Block 14: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 19.0
- **bbox**: `BBox(x0=253, y0=440, x1=338, y1=470)`

**Content**:

```
Adding layers of conductive conducive or insulating material. Scatter ploowe vs ion doss agonia us,mesulation

```

**Image**: *(has image_base64)*


---

### Block 15: image

- **类型**: `image`
- **源类型**: `image`
- **页码**: 1
- **索引**: 21.0
- **bbox**: `BBox(x0=372, y0=345, x1=471, y1=434)`
- **Captions**: ['Electrical Testing & Packaging\n']

**Content**:

*(empty)*

**Image**: *(has image_base64)*


---

### Block 16: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 22.0
- **bbox**: `BBox(x0=379, y0=440, x1=473, y1=471)`

**Content**:

```
Pess heiform id euiig a trnd majine  
paclaging talge sicstter iinn  
scatter ion to toris imtheta coddum arteriency utull pruity.

```

**Image**: *(has image_base64)*


---

### Block 17: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 1
- **索引**: -999.9928
- **bbox**: `BBox(x0=88, y0=72, x1=226, y1=85)`

**Content**:

```
大的流程图被切成多个小图片

```

**Image**: *(has image_base64)*


---
