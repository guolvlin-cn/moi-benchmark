# MinerU Parser Debug Output

**生成时间**: 2026-07-29T14:11:03.810127

**Block 总数**: 12


---

## 类型统计

| 类型 | 数量 |
|------|------|
| header | 3 |
| image | 1 |
| text | 5 |
| title | 3 |

---

## Block 详情

### Block 0: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 1.0
- **bbox**: `BBox(x0=58, y0=76, x1=421, y1=104)`
- **标题级别**: 1

**Content**:

```
全球供应链风险评估深度报告

```

**Image**: *(has image_base64)*


---

### Block 1: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 2.0
- **bbox**: `BBox(x0=58, y0=118, x1=825, y1=132)`

**Content**:

```
下表详细列出了当前季度针对亚太及北美市场的供应链稳定性审查结果。请注意，表格直接承接此段文字，未设显著间距以模拟高信息密度版式：

```

**Image**: *(has image_base64)*


---

### Block 2: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 1
- **索引**: 3.0
- **bbox**: `BBox(x0=383, y0=164, x1=571, y1=179)`

**Content**:

```
TABLE_placeHOLDER_001
```

**Image**: *(no image)*


---

### Block 3: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 1
- **索引**: -999.9954
- **bbox**: `BBox(x0=67, y0=46, x1=210, y1=57)`

**Content**:

```
Case 1: 紧凑布局与分段多线结构

```

**Image**: *(has image_base64)*


---

### Block 4: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 2
- **索引**: 1.0
- **bbox**: `BBox(x0=56, y0=75, x1=507, y1=104)`
- **标题级别**: 1

**Content**:

```
研发中心核心技术矩阵与投入产出比

```

**Image**: *(has image_base64)*


---

### Block 5: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 2
- **索引**: 2.0
- **bbox**: `BBox(x0=219, y0=138, x1=409, y1=154)`

**Content**:

```
TABLE_placeHOLDER_002
```

**Image**: *(no image)*


---

### Block 6: image

- **类型**: `image`
- **源类型**: `image`
- **页码**: 2
- **索引**: 3.0
- **bbox**: `BBox(x0=604, y0=127, x1=908, y1=393)`
- **Footnotes**: ['注：左表数据系基于2025年研发审计报告所得。对于技术成熟度的定性评估参考了Gartner最新发布的行业曲线图。\n']

**Content**:

*(empty)*

**Image**: *(has image_base64)*


---

### Block 7: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 2
- **索引**: -999.9954
- **bbox**: `BBox(x0=67, y0=46, x1=210, y1=57)`

**Content**:

```
Case 2: 侧边图文与密集型参数表

```

**Image**: *(has image_base64)*


---

### Block 8: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 3
- **索引**: 1.0
- **bbox**: `BBox(x0=56, y0=74, x1=546, y1=106)`
- **标题级别**: 1

**Content**:

```
企业社会责任(CSR)实施准则与争议处理

```

**Image**: *(has image_base64)*


---

### Block 9: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 2.0
- **bbox**: `BBox(x0=58, y0=117, x1=450, y1=132)`

**Content**:

```
以下条款作为员工手册附件，具有法律效力，请务必详细阅读每一行细则：

```

**Image**: *(has image_base64)*


---

### Block 10: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 3
- **索引**: 3.0
- **bbox**: `BBox(x0=380, y0=160, x1=571, y1=177)`

**Content**:

```
TABLE_placeHOLDER_003
```

**Image**: *(no image)*


---

### Block 11: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 3
- **索引**: -999.9955
- **bbox**: `BBox(x0=67, y0=45, x1=210, y1=57)`

**Content**:

```
Case 3: 极大行高测试与多级分隔

```

**Image**: *(has image_base64)*


---
