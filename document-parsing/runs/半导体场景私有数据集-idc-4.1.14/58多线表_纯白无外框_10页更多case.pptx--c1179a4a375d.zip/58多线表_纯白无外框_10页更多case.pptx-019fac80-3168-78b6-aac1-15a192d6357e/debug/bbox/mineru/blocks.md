# MinerU Parser Debug Output

**生成时间**: 2026-07-29T14:12:14.648844

**Block 总数**: 57


---

## 类型统计

| 类型 | 数量 |
|------|------|
| header | 10 |
| list | 4 |
| text | 32 |
| title | 11 |

---

## Block 详情

### Block 0: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 1.0
- **bbox**: `BBox(x0=55, y0=83, x1=499, y1=120)`
- **标题级别**: 1

**Content**:

```
全球供应链风险评估深度报告

```

**Image**: *(has image_base64)*


---

### Block 1: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 2.0
- **bbox**: `BBox(x0=55, y0=129, x1=346, y1=147)`

**Content**:

```
段落与表格几乎零间距，测试高密度版式

```

**Image**: *(has image_base64)*


---

### Block 2: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 3.0
- **bbox**: `BBox(x0=55, y0=171, x1=754, y1=190)`

**Content**:

```
下表列出本季度亚太及北美市场供应链稳定性审查结果。注意：表格紧贴此段文字以模拟高信息密度版式。

```

**Image**: *(has image_base64)*


---

### Block 3: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 1
- **索引**: 4.0
- **bbox**: `BBox(x0=395, y0=214, x1=584, y1=231)`

**Content**:

```
TABLE_placeHOLDER_001
```

**Image**: *(no image)*


---

### Block 4: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 1
- **索引**: -999.9955
- **bbox**: `BBox(x0=85, y0=45, x1=380, y1=62)`

**Content**:

```
Case 1: 紧贴文本 + 分段多线表（纯白无外框）

```

**Image**: *(has image_base64)*


---

### Block 5: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 2
- **索引**: 1.0
- **bbox**: `BBox(x0=53, y0=83, x1=605, y1=120)`
- **标题级别**: 1

**Content**:

```
研发中心核心技术矩阵与投入产出比

```

**Image**: *(has image_base64)*


---

### Block 6: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 2.0
- **bbox**: `BBox(x0=55, y0=129, x1=313, y1=147)`

**Content**:

```
左表右图：测试并列布局与边界识别

```

**Image**: *(has image_base64)*


---

### Block 7: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 3.0
- **bbox**: `BBox(x0=53, y0=172, x1=427, y1=189)`

**Content**:

```
左侧为技术矩阵与成熟度评估；右侧为研发场景示意与注释。

```

**Image**: *(has image_base64)*


---

### Block 8: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 2
- **索引**: 4.0
- **bbox**: `BBox(x0=406, y0=205, x1=598, y1=223)`

**Content**:

```
TABLE_placeHOLDER_002
```

**Image**: *(no image)*


---

### Block 9: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 2
- **索引**: -999.9955
- **bbox**: `BBox(x0=86, y0=45, x1=380, y1=62)`

**Content**:

```
Case 2: 图文混排 + 密集参数表（纯白无外框）

```

**Image**: *(has image_base64)*


---

### Block 10: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 3
- **索引**: 1.0
- **bbox**: `BBox(x0=53, y0=84, x1=704, y1=122)`
- **标题级别**: 1

**Content**:

```
企业社会责任（CSR）实施准则与争议处理

```

**Image**: *(has image_base64)*


---

### Block 11: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 2.0
- **bbox**: `BBox(x0=55, y0=129, x1=329, y1=147)`

**Content**:

```
长段落撑高行高：测试换行与线条保持

```

**Image**: *(has image_base64)*


---

### Block 12: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 3.0
- **bbox**: `BBox(x0=53, y0=171, x1=607, y1=190)`

**Content**:

```
以下条款作为员工手册附件，具有法律效力，请务必逐行阅读（长文本撑高行高）。

```

**Image**: *(has image_base64)*


---

### Block 13: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 3
- **索引**: 4.0
- **bbox**: `BBox(x0=393, y0=210, x1=586, y1=227)`

**Content**:

```
TABLE_placeHOLDER_003
```

**Image**: *(no image)*


---

### Block 14: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 3
- **索引**: -999.9955
- **bbox**: `BBox(x0=85, y0=45, x1=380, y1=63)`

**Content**:

```
Case 3: 超长单元格 + 多级分隔（纯白无外框）

```

**Image**: *(has image_base64)*


---

### Block 15: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 4
- **索引**: 1.0
- **bbox**: `BBox(x0=53, y0=83, x1=500, y1=120)`
- **标题级别**: 1

**Content**:

```
季度经营指标拆解与偏差归因

```

**Image**: *(has image_base64)*


---

### Block 16: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 4
- **索引**: 2.0
- **bbox**: `BBox(x0=55, y0=129, x1=315, y1=147)`

**Content**:

```
同页多表：测试表格之间近距离干扰

```

**Image**: *(has image_base64)*


---

### Block 17: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 4
- **索引**: 3.0
- **bbox**: `BBox(x0=53, y0=171, x1=512, y1=190)`

**Content**:

```
同页上下两张多线表：上表为关键指标，下表为偏差归因。两表间距极小。

```

**Image**: *(has image_base64)*


---

### Block 18: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 4
- **索引**: 4.0
- **bbox**: `BBox(x0=395, y0=203, x1=587, y1=221)`

**Content**:

```
TABLE_placeHOLDER_004
```

**Image**: *(no image)*


---

### Block 19: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 4
- **索引**: -999.9955
- **bbox**: `BBox(x0=93, y0=45, x1=374, y1=63)`

**Content**:

```
Case 4: 上下双表 + 细分分段（纯白无外框）

```

**Image**: *(has image_base64)*


---

### Block 20: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 5
- **索引**: 1.0
- **bbox**: `BBox(x0=54, y0=83, x1=501, y1=120)`
- **标题级别**: 1

**Content**:

```
客户分层策略与转化漏斗诊断

```

**Image**: *(has image_base64)*


---

### Block 21: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 5
- **索引**: 2.0
- **bbox**: `BBox(x0=55, y0=129, x1=315, y1=147)`

**Content**:

```
右侧边栏说明与表格紧贴：测试误检

```

**Image**: *(has image_base64)*


---

### Block 22: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 5
- **索引**: 3.0
- **bbox**: `BBox(x0=53, y0=172, x1=538, y1=190)`

**Content**:

```
表格与右侧注释面板紧贴，且注释含多行文本，模拟报告页常见“边栏说明”。

```

**Image**: *(has image_base64)*


---

### Block 23: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 5
- **索引**: 4.0
- **bbox**: `BBox(x0=253, y0=206, x1=446, y1=224)`

**Content**:

```
TABLE_placeHOLDER_005
```

**Image**: *(no image)*


---

### Block 24: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 5
- **索引**: 5.0
- **bbox**: `BBox(x0=688, y0=215, x1=748, y1=231)`
- **标题级别**: 1

**Content**:

```
边栏注释

```

**Image**: *(has image_base64)*


---

### Block 25: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 10.0
- **bbox**: `BBox(x0=687, y0=244, x1=931, y1=273)`

**Content**:

```
- 分层以“生命周期价值 + 交付复杂度”综合判定。
```

**Image**: *(has image_base64)*


---

### Block 26: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 10.001
- **bbox**: `BBox(x0=688, y0=274, x1=881, y1=287)`

**Content**:

```
A类以共创为主，避免低价标准包。
```

**Image**: *(has image_base64)*


---

### Block 27: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 10.002
- **bbox**: `BBox(x0=688, y0=288, x1=892, y1=301)`

**Content**:

```
C类重点优化获客成本与自助化转化
```

**Image**: *(has image_base64)*


---

### Block 28: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 10.003
- **bbox**: `BBox(x0=688, y0=302, x1=896, y1=316)`

**Content**:

```
- 指标口径需与财务对齐（季度复核）。
```

**Image**: *(has image_base64)*


---

### Block 29: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 5
- **索引**: -999.9955
- **bbox**: `BBox(x0=93, y0=45, x1=374, y1=63)`

**Content**:

```
Case 5: 表格 + 侧边注释面板（纯白无外框）

```

**Image**: *(has image_base64)*


---

### Block 30: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 6
- **索引**: 1.0
- **bbox**: `BBox(x0=55, y0=83, x1=537, y1=120)`
- **标题级别**: 1

**Content**:

```
战略项目里程碑与风险追踪台账

```

**Image**: *(has image_base64)*


---

### Block 31: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 6
- **索引**: 2.0
- **bbox**: `BBox(x0=55, y0=129, x1=273, y1=149)`

**Content**:

```
顶部里程碑条 + 下方表格混排

```

**Image**: *(has image_base64)*


---

### Block 32: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 6
- **索引**: 3.0
- **bbox**: `BBox(x0=54, y0=172, x1=388, y1=190)`

**Content**:

```
顶部为里程碑条，下面为风险台账多线表（无外框）。

```

**Image**: *(has image_base64)*


---

### Block 33: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 6
- **索引**: 4.0
- **bbox**: `BBox(x0=395, y0=210, x1=587, y1=227)`

**Content**:

```
TABLE_placeHOLDER_006
```

**Image**: *(no image)*


---

### Block 34: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 6
- **索引**: -999.9955
- **bbox**: `BBox(x0=106, y0=45, x1=362, y1=63)`

**Content**:

```
Case 6: 流程条 + 多线表（纯白无外框）

```

**Image**: *(has image_base64)*


---

### Block 35: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 7
- **索引**: 1.0
- **bbox**: `BBox(x0=53, y0=84, x1=747, y1=125)`
- **标题级别**: 1

**Content**:

```
跨境合规检查清单（Compliance Checklist）

```

**Image**: *(has image_base64)*


---

### Block 36: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 7
- **索引**: 2.0
- **bbox**: `BBox(x0=55, y0=129, x1=281, y1=147)`

**Content**:

```
双语混排：测试字符宽度与断行

```

**Image**: *(has image_base64)*


---

### Block 37: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 7
- **索引**: 3.0
- **bbox**: `BBox(x0=53, y0=172, x1=474, y1=189)`

**Content**:

```
双语表头 + 复杂字段：适合测试英文单词、中文换行与列宽稳定性。

```

**Image**: *(has image_base64)*


---

### Block 38: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 7
- **索引**: 4.0
- **bbox**: `BBox(x0=395, y0=208, x1=586, y1=225)`

**Content**:

```
TABLE_placeHOLDER_007
```

**Image**: *(no image)*


---

### Block 39: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 7
- **索引**: 5.0
- **bbox**: `BBox(x0=53, y0=389, x1=526, y1=404)`

**Content**:

```
备注：Result 建议使用（通过/待整改/不适用）三态；Evidence 以编号与链接便于追溯。

```

**Image**: *(has image_base64)*


---

### Block 40: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 7
- **索引**: -999.9955
- **bbox**: `BBox(x0=85, y0=45, x1=380, y1=62)`

**Content**:

```
Case 7: 中英双语表头 + 长字段（纯白无外框）

```

**Image**: *(has image_base64)*


---

### Block 41: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 8
- **索引**: 1.0
- **bbox**: `BBox(x0=53, y0=84, x1=584, y1=122)`
- **标题级别**: 1

**Content**:

```
财务报表关键比率与同比/环比对照

```

**Image**: *(has image_base64)*


---

### Block 42: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 8
- **索引**: 2.0
- **bbox**: `BBox(x0=55, y0=129, x1=281, y1=147)`

**Content**:

```
大量数字符号：测试列宽与对齐

```

**Image**: *(has image_base64)*


---

### Block 43: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 8
- **索引**: 3.0
- **bbox**: `BBox(x0=53, y0=172, x1=436, y1=190)`

**Content**:

```
数值表强调对齐：建议在同列内使用统一格式（%、pp、×）。

```

**Image**: *(has image_base64)*


---

### Block 44: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 8
- **索引**: 4.0
- **bbox**: `BBox(x0=395, y0=206, x1=586, y1=223)`

**Content**:

```
TABLE_placeHOLDER_008
```

**Image**: *(no image)*


---

### Block 45: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 8
- **索引**: -999.9955
- **bbox**: `BBox(x0=99, y0=45, x1=366, y1=63)`

**Content**:

```
Case 8: 高密数值表 + 对齐（纯白无外框）

```

**Image**: *(has image_base64)*


---

### Block 46: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 9
- **索引**: 1.0
- **bbox**: `BBox(x0=55, y0=83, x1=536, y1=120)`
- **标题级别**: 1

**Content**:

```
信息安全控制点与审计发现摘要

```

**Image**: *(has image_base64)*


---

### Block 47: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 9
- **索引**: 2.0
- **bbox**: `BBox(x0=55, y0=129, x1=300, y1=147)`

**Content**:

```
同一单元格多段落：测试层次保真

```

**Image**: *(has image_base64)*


---

### Block 48: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 9
- **索引**: 3.0
- **bbox**: `BBox(x0=55, y0=172, x1=434, y1=190)`

**Content**:

```
单元格内多段落/项目符号：常见于审计发现与整改建议汇总。

```

**Image**: *(has image_base64)*


---

### Block 49: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 9
- **索引**: 4.0
- **bbox**: `BBox(x0=395, y0=207, x1=586, y1=224)`

**Content**:

```
TABLE_placeHOLDER_009
```

**Image**: *(no image)*


---

### Block 50: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 9
- **索引**: -999.9955
- **bbox**: `BBox(x0=70, y0=45, x1=396, y1=63)`

**Content**:

```
Case 9: 单元格内项目符号 + 多段落（纯白无外框）

```

**Image**: *(has image_base64)*


---

### Block 51: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 10
- **索引**: 1.0
- **bbox**: `BBox(x0=53, y0=84, x1=719, y1=123)`
- **标题级别**: 1

**Content**:

```
人力资源绩效指标（KPI/OKR）与评分规则

```

**Image**: *(has image_base64)*


---

### Block 52: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 10
- **索引**: 2.0
- **bbox**: `BBox(x0=55, y0=129, x1=257, y1=149)`

**Content**:

```
表格贴近页边界 + 脚注干扰

```

**Image**: *(has image_base64)*


---

### Block 53: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 10
- **索引**: 3.0
- **bbox**: `BBox(x0=53, y0=172, x1=485, y1=190)`

**Content**:

```
表格贴近页面底部，并附脚注：测试底部线条是否被裁切及脚注干扰。

```

**Image**: *(has image_base64)*


---

### Block 54: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 10
- **索引**: 4.0
- **bbox**: `BBox(x0=394, y0=204, x1=587, y1=221)`

**Content**:

```
TABLE_placeHOLDER_010
```

**Image**: *(no image)*


---

### Block 55: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 10
- **索引**: 5.0
- **bbox**: `BBox(x0=53, y0=429, x1=528, y1=446)`

**Content**:

```
脚注：权重可按岗位调整；评分建议季度末由直属主管与HRBP联合校准，减少主观偏差。

```

**Image**: *(has image_base64)*


---

### Block 56: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 10
- **索引**: -999.9955
- **bbox**: `BBox(x0=101, y0=45, x1=366, y1=63)`

**Content**:

```
Case 10: 表格贴底 + 脚注（纯白无外框）

```

**Image**: *(has image_base64)*


---
