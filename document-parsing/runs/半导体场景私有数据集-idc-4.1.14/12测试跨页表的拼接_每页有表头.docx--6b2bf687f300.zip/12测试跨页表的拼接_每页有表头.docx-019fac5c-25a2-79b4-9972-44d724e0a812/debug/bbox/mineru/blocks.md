# MinerU Parser Debug Output

**生成时间**: 2026-07-29T13:32:55.279535

**Block 总数**: 26


---

## 类型统计

| 类型 | 数量 |
|------|------|
| list | 10 |
| text | 10 |
| title | 6 |

---

## Block 详情

### Block 0: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 0.0
- **bbox**: `BBox(x0=88, y0=150, x1=276, y1=169)`
- **标题级别**: 1

**Content**:

```
1. Overall scheme design

```

**Image**: *(has image_base64)*


---

### Block 1: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 1.0
- **bbox**: `BBox(x0=108, y0=170, x1=329, y1=185)`
- **标题级别**: 2

**Content**:

```
1.1.Overview of system architecture

```

**Image**: *(has image_base64)*


---

### Block 2: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 2.0
- **bbox**: `BBox(x0=128, y0=188, x1=506, y1=231)`

**Content**:

```
The system is designed with a layered architecture, encompassing a data layer, a model layer, and an application layer. This design ensures the independence between modules and facilitates the addition of new functional modules in the future.

```

**Image**: *(has image_base64)*


---

### Block 3: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 3.0
- **bbox**: `BBox(x0=108, y0=234, x1=222, y1=250)`
- **标题级别**: 2

**Content**:

```
1.2.技术选型说明

```

**Image**: *(has image_base64)*


---

### Block 4: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 4.0
- **bbox**: `BBox(x0=128, y0=253, x1=271, y1=269)`
- **标题级别**: 3

**Content**:

```
1.2.1.后端与基础设施

```

**Image**: *(has image_base64)*


---

### Block 5: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 9.0
- **bbox**: `BBox(x0=168, y0=274, x1=271, y1=285)`

**Content**:

```
编程语言：Python
```

**Image**: *(has image_base64)*


---

### Block 6: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 9.001
- **bbox**: `BBox(x0=168, y0=289, x1=276, y1=301)`

**Content**:

```
- 服务框架：FastAPI
```

**Image**: *(has image_base64)*


---

### Block 7: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 9.002
- **bbox**: `BBox(x0=168, y0=304, x1=302, y1=316)`

**Content**:

```
- 模型部署：vLLM/Triton
```

**Image**: *(has image_base64)*


---

### Block 8: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 9.003
- **bbox**: `BBox(x0=168, y0=320, x1=341, y1=332)`

**Content**:

```
- 容器与编排：Docker + Kubernetes
```

**Image**: *(has image_base64)*


---

### Block 9: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 10.0
- **bbox**: `BBox(x0=128, y0=335, x1=226, y1=351)`
- **标题级别**: 3

**Content**:

```
1.2.2.模型相关

```

**Image**: *(has image_base64)*


---

### Block 10: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 14.0
- **bbox**: `BBox(x0=168, y0=354, x1=279, y1=367)`

**Content**:

```
- 大语言模型（LLM）
```

**Image**: *(has image_base64)*


---

### Block 11: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 14.001
- **bbox**: `BBox(x0=168, y0=370, x1=295, y1=383)`

**Content**:

```
向量模型（Embedding）
```

**Image**: *(has image_base64)*


---

### Block 12: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 14.002
- **bbox**: `BBox(x0=168, y0=386, x1=279, y1=398)`

**Content**:

```
- RAG 检索增强生成
```

**Image**: *(has image_base64)*


---

### Block 13: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 15.0
- **bbox**: `BBox(x0=128, y0=401, x1=256, y1=417)`
- **标题级别**: 3

**Content**:

```
1.2.3.其他模型相关

```

**Image**: *(has image_base64)*


---

### Block 14: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 19.0
- **bbox**: `BBox(x0=168, y0=421, x1=280, y1=433)`

**Content**:

```
- 视觉大模型（VLM）
```

**Image**: *(has image_base64)*


---

### Block 15: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 19.001
- **bbox**: `BBox(x0=168, y0=437, x1=295, y1=449)`

**Content**:

```
向量模型（Embedding）
```

**Image**: *(has image_base64)*


---

### Block 16: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 19.002
- **bbox**: `BBox(x0=168, y0=453, x1=279, y1=465)`

**Content**:

```
- RAG 检索增强生成
```

**Image**: *(has image_base64)*


---

### Block 17: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 20.0
- **bbox**: `BBox(x0=87, y0=483, x1=151, y1=496)`

**Content**:

```
case1 普通表

```

**Image**: *(has image_base64)*


---

### Block 18: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 1
- **索引**: 21.0
- **bbox**: `BBox(x0=201, y0=506, x1=390, y1=522)`

**Content**:

```
TABLE_placeHOLDER_001
```

**Image**: *(no image)*


---

### Block 19: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 2
- **索引**: 0.0
- **bbox**: `BBox(x0=201, y0=157, x1=392, y1=173)`

**Content**:

```
TABLE_placeHOLDER_002
```

**Image**: *(no image)*


---

### Block 20: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 0.0
- **bbox**: `BBox(x0=88, y0=150, x1=151, y1=162)`

**Content**:

```
case2 多线表

```

**Image**: *(has image_base64)*


---

### Block 21: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 3
- **索引**: 1.0
- **bbox**: `BBox(x0=201, y0=173, x1=391, y1=188)`

**Content**:

```
TABLE_placeHOLDER_003
```

**Image**: *(no image)*


---

### Block 22: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 4
- **索引**: 0.0
- **bbox**: `BBox(x0=201, y0=158, x1=391, y1=173)`

**Content**:

```
TABLE_placeHOLDER_004
```

**Image**: *(no image)*


---

### Block 23: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 5
- **索引**: 0.0
- **bbox**: `BBox(x0=88, y0=150, x1=151, y1=162)`

**Content**:

```
case3 三线表

```

**Image**: *(has image_base64)*


---

### Block 24: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 5
- **索引**: 1.0
- **bbox**: `BBox(x0=199, y0=172, x1=390, y1=188)`

**Content**:

```
TABLE_placeHOLDER_005
```

**Image**: *(no image)*


---

### Block 25: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 6
- **索引**: 0.0
- **bbox**: `BBox(x0=199, y0=156, x1=390, y1=173)`

**Content**:

```
TABLE_placeHOLDER_006
```

**Image**: *(no image)*


---
