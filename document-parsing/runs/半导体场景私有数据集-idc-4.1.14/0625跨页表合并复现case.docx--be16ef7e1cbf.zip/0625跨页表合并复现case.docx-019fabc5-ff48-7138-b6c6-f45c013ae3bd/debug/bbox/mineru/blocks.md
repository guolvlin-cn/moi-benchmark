# MinerU Parser Debug Output

**生成时间**: 2026-07-29T10:49:09.274605

**Block 总数**: 39


---

## 类型统计

| 类型 | 数量 |
|------|------|
| list | 2 |
| text | 35 |
| title | 2 |

---

## Block 详情

### Block 0: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 1
- **索引**: 0.0
- **bbox**: `BBox(x0=201, y0=167, x1=390, y1=185)`

**Content**:

```
TABLE_placeHOLDER_001
```

**Image**: *(no image)*


---

### Block 1: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 2
- **索引**: 0.0
- **bbox**: `BBox(x0=201, y0=137, x1=392, y1=153)`

**Content**:

```
TABLE_placeHOLDER_002
```

**Image**: *(no image)*


---

### Block 2: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 3
- **索引**: 0.0
- **bbox**: `BBox(x0=201, y0=153, x1=392, y1=169)`

**Content**:

```
TABLE_placeHOLDER_003
```

**Image**: *(no image)*


---

### Block 3: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 4
- **索引**: 0.0
- **bbox**: `BBox(x0=201, y0=169, x1=392, y1=185)`

**Content**:

```
TABLE_placeHOLDER_004
```

**Image**: *(no image)*


---

### Block 4: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 5
- **索引**: 0.0
- **bbox**: `BBox(x0=42, y0=180, x1=71, y1=190)`

**Content**:

```
notes:

```

**Image**: *(has image_base64)*


---

### Block 5: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 3.0
- **bbox**: `BBox(x0=43, y0=194, x1=202, y1=206)`

**Content**:

```
1. The factory floor hummed with a.
```

**Image**: *(has image_base64)*


---

### Block 6: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 3.001
- **bbox**: `BBox(x0=42, y0=210, x1=116, y1=221)`

**Content**:

```
2. robotic arms.
```

**Image**: *(has image_base64)*


---

### Block 7: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 5
- **索引**: 4.0
- **bbox**: `BBox(x0=201, y0=247, x1=393, y1=264)`

**Content**:

```
TABLE_placeHOLDER_005
```

**Image**: *(no image)*


---

### Block 8: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 6
- **索引**: 0.0
- **bbox**: `BBox(x0=201, y0=124, x1=393, y1=140)`

**Content**:

```
TABLE_placeHOLDER_006
```

**Image**: *(no image)*


---

### Block 9: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 6
- **索引**: 1.0
- **bbox**: `BBox(x0=201, y0=310, x1=393, y1=327)`

**Content**:

```
TABLE_placeHOLDER_007
```

**Image**: *(no image)*


---

### Block 10: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 7
- **索引**: 0.0
- **bbox**: `BBox(x0=201, y0=124, x1=393, y1=140)`

**Content**:

```
TABLE_placeHOLDER_008
```

**Image**: *(no image)*


---

### Block 11: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 8
- **索引**: 0.0
- **bbox**: `BBox(x0=42, y0=498, x1=70, y1=511)`

**Content**:

```
0626

```

**Image**: *(has image_base64)*


---

### Block 12: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 8
- **索引**: 1.0
- **bbox**: `BBox(x0=42, y0=526, x1=72, y1=540)`

**Content**:

```
配置：

```

**Image**: *(has image_base64)*


---

### Block 13: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 8
- **索引**: 2.0
- **bbox**: `BBox(x0=42, y0=555, x1=211, y1=571)`

**Content**:

```
enable_table_html_regeneration = 1

```

**Image**: *(has image_base64)*


---

### Block 14: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 8
- **索引**: 3.0
- **bbox**: `BBox(x0=42, y0=584, x1=262, y1=598)`

**Content**:

```
enable_table_embedding_imageexoction = 1

```

**Image**: *(has image_base64)*


---

### Block 15: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 8
- **索引**: 4.0
- **bbox**: `BBox(x0=42, y0=612, x1=186, y1=626)`

**Content**:

```
enable_mergeable_table_split=1

```

**Image**: *(has image_base64)*


---

### Block 16: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 8
- **索引**: 5.0
- **bbox**: `BBox(x0=42, y0=640, x1=212, y1=655)`

**Content**:

```
enablecross_page_table_merge = 1

```

**Image**: *(has image_base64)*


---

### Block 17: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 8
- **索引**: 6.0
- **bbox**: `BBox(x0=42, y0=667, x1=157, y1=682)`

**Content**:

```
unmerge_table.cells=0

```

**Image**: *(has image_base64)*


---

### Block 18: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 8
- **索引**: 7.0
- **bbox**: `BBox(x0=42, y0=695, x1=210, y1=709)`

**Content**:

```
enable_table在线line_image_text=1

```

**Image**: *(has image_base64)*


---

### Block 19: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 8
- **索引**: 8.0
- **bbox**: `BBox(x0=42, y0=723, x1=213, y1=737)`

**Content**:

```
cross_page_merge_header_table=1

```

**Image**: *(has image_base64)*


---

### Block 20: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 8
- **索引**: 9.0
- **bbox**: `BBox(x0=42, y0=751, x1=230, y1=765)`

**Content**:

```
enable CROSS_page_physical_filter=1

```

**Image**: *(has image_base64)*


---

### Block 21: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 9
- **索引**: 0.0
- **bbox**: `BBox(x0=41, y0=142, x1=483, y1=156)`

**Content**:

```
将前五个表格称为表 1-表 5, 将最后一个表格前半部分称为表 6, 后半部分称为表 7

```

**Image**: *(has image_base64)*


---

### Block 22: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 9
- **索引**: 1.0
- **bbox**: `BBox(x0=42, y0=199, x1=161, y1=213)`
- **标题级别**: 1

**Content**:

```
1. 不该合并的被合并：

```

**Image**: *(has image_base64)*


---

### Block 23: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 9
- **索引**: 2.0
- **bbox**: `BBox(x0=41, y0=228, x1=550, y1=259)`

**Content**:

```
现象：表1表2合并为一张表；表3表4合并为一张表；表5未被合并，独立存在，表5上方文字被正常识别为文字，且阅读顺序准确，先文本再表5

```

**Image**: *(has image_base64)*


---

### Block 24: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 9
- **索引**: 3.0
- **bbox**: `BBox(x0=42, y0=275, x1=106, y1=289)`

**Content**:

```
debug 信息:

```

**Image**: *(has image_base64)*


---

### Block 25: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 9
- **索引**: 4.0
- **bbox**: `BBox(x0=41, y0=303, x1=229, y1=318)`

**Content**:

```
docx 转 pdf 无误；paddle 识别无误；

```

**Image**: *(has image_base64)*


---

### Block 26: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 9
- **索引**: 5.0
- **bbox**: `BBox(x0=41, y0=333, x1=262, y1=348)`

**Content**:

```
cross_page_table_MATCH/下有4次vlm调用

```

**Image**: *(has image_base64)*


---

### Block 27: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 9
- **索引**: 6.0
- **bbox**: `BBox(x0=41, y0=362, x1=552, y1=439)`

**Content**:

```
md_1:判断表1和表2是否属于同一个跨页表，返回“true，两个表格具有完全一致的列结构（risk level，wl，产品类别），且内容属于同一主题范畴，都是关于不同风险等级（risk level）和晶圆数量（wl）下的可行性验证要求，表a针对logic products，表b针对nvm products，这属于同一分类表格下的不同产品条目。两个表格的行号和wl值完全对应，说明它们是并列展示不同产品线的同一套标准，而非跨页延续，因此，它们属于同一个跨页表格的不同部分。”

```

**Image**: *(has image_base64)*


---

### Block 28: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 9
- **索引**: 7.0
- **bbox**: `BBox(x0=41, y0=454, x1=552, y1=515)`

**Content**:

```
md_2:判断表2和表3是否属于同一个跨页表，返回“false，这两个表格虽然列结构完全一致（risk level，wl，for nvm products），但他们还是针对不同产品类别的独立表格，表b拥有完整的表头，且内容从risk level1开始重新列举，属于同一文档中并列的两个独立分类表，并非一个表格跨页延续。”

```

**Image**: *(has image_base64)*


---

### Block 29: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 9
- **索引**: 8.0
- **bbox**: `BBox(x0=41, y0=530, x1=550, y1=576)`

**Content**:

```
md_3:判断表3和表4是否属于同一个跨页表，返回“true，两者拥有完全一致的列结构，表a针对nor flash，表b针对nand flash，两者是同一分类表格下的不同产品类别条目，符合跨页表格的特征。”

```

**Image**: *(has image_base64)*


---

### Block 30: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 9
- **索引**: 9.0
- **bbox**: `BBox(x0=41, y0=591, x1=552, y1=652)`

**Content**:

```
md_4:判断表5和表6是否属于同一个跨页表，返回“false，虽然两个表格的列结构相似，且主题都涉及可靠性风险评估，但它们是描述两个不同产品类别的独立表格，表a针对for other products（28nm and above），表b针对for automotive rsa cosign flow,此外两个表都有各自完整的表头，且风险等级都是从1开始重新计数，因此是两个独立的表格”

```

**Image**: *(has image_base64)*


---

### Block 31: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 9
- **索引**: 10.0
- **bbox**: `BBox(x0=41, y0=666, x1=250, y1=681)`
- **标题级别**: 1

**Content**:

```
表 6 和表 7 未进入 vlm 判断跨页表流程

```

**Image**: *(has image_base64)*


---

### Block 32: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 9
- **索引**: 11.0
- **bbox**: `BBox(x0=41, y0=724, x1=432, y1=740)`

**Content**:

```
```cpp
tableprocess-cross_page.append-page2/下有两次 vlm 记录，为 vlm 生成续表

```

**Image**: *(has image_base64)*


---

### Block 33: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 10
- **索引**: 0.0
- **bbox**: `BBox(x0=41, y0=114, x1=149, y1=128)`

**Content**:

```
2. 该合并的未合并：

```

**Image**: *(has image_base64)*


---

### Block 34: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 10
- **索引**: 1.0
- **bbox**: `BBox(x0=41, y0=143, x1=141, y1=158)`

**Content**:

```
现象：仍然未合并

```

**Image**: *(has image_base64)*


---

### Block 35: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 10
- **索引**: 2.0
- **bbox**: `BBox(x0=41, y0=174, x1=107, y1=188)`

**Content**:

```
debug 信息:

```

**Image**: *(has image_base64)*


---

### Block 36: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 10
- **索引**: 3.0
- **bbox**: `BBox(x0=41, y0=203, x1=289, y1=218)`

**Content**:

```
docx 转 pdf 无误，格式保留；paddle 识别无误；

```

**Image**: *(has image_base64)*


---

### Block 37: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 10
- **索引**: 4.0
- **bbox**: `BBox(x0=41, y0=232, x1=550, y1=263)`

**Content**:

```
从pdf上来看，满足：两个表在相邻页，上表底边超过 50\% ，下表上边在 50\% 内，宽度几乎一样，表中间没有文本，页眉页脚已被剔除干净

```

**Image**: *(has image_base64)*


---

### Block 38: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 10
- **索引**: 5.0
- **bbox**: `BBox(x0=41, y0=277, x1=106, y1=292)`

**Content**:

```
无其他思路

```

**Image**: *(has image_base64)*


---
