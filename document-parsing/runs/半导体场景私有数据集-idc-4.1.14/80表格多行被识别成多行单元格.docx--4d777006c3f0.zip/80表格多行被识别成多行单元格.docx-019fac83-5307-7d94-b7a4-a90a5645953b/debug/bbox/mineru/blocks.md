# MinerU Parser Debug Output

**生成时间**: 2026-07-29T14:15:22.669498

**Block 总数**: 2


---

## 类型统计

| 类型 | 数量 |
|------|------|
| text | 2 |

---

## Block 详情

### Block 0: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 1
- **索引**: 1.0
- **bbox**: `BBox(x0=201, y0=247, x1=392, y1=264)`

**Content**:

```
TABLE_placeHOLDER_002
```

**Image**: *(no image)*


---

### Block 1: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 1
- **索引**: -999.9921
- **bbox**: `BBox(x0=195, y0=79, x1=383, y1=95)`

**Content**:

```
TABLE_placeHOLDER_001
```

**Image**: *(no image)*


---
