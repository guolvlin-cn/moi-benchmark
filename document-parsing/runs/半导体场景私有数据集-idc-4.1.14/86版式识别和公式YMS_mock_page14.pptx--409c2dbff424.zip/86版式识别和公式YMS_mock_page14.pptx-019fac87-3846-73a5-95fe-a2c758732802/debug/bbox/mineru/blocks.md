# MinerU Parser Debug Output

**生成时间**: 2026-07-29T14:19:46.136436

**Block 总数**: 71


---

## 类型统计

| 类型 | 数量 |
|------|------|
| footer | 10 |
| header | 8 |
| image | 10 |
| list | 11 |
| text | 29 |
| title | 3 |

---

## Block 详情

### Block 0: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 2.0
- **bbox**: `BBox(x0=323, y0=206, x1=635, y1=267)`
- **标题级别**: 1

**Content**:

```
YMSmock

```

**Image**: *(has image_base64)*


---

### Block 1: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 1
- **索引**: -999.9992
- **bbox**: `BBox(x0=5, y0=8, x1=222, y1=32)`

**Content**:

```
SMIC dental/xzixong261030

```

**Image**: *(has image_base64)*


---

### Block 2: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 1
- **索引**: -999.9988
- **bbox**: `BBox(x0=808, y0=12, x1=937, y1=25)`

**Content**:

```
2026年7月29日14时19分

```

**Image**: *(has image_base64)*


---

### Block 3: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 1
- **索引**: 9999.0504
- **bbox**: `BBox(x0=63, y0=504, x1=111, y1=529)`

**Content**:

```
SMIC

```

**Image**: *(has image_base64)*


---

### Block 4: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 1
- **索引**: 9999.0502
- **bbox**: `BBox(x0=437, y0=502, x1=552, y1=513)`

**Content**:

```
MatrixOne Intelligence

```

**Image**: *(has image_base64)*


---

### Block 5: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 1
- **索引**: 9999.0515
- **bbox**: `BBox(x0=211, y0=515, x1=778, y1=529)`

**Content**:

```
Copyright © 2026 矩阵起源（深圳）信息科技有限公司粤公安网备 44030402004672号 | 粤ICP备2021044820号

```

**Image**: *(has image_base64)*


---

### Block 6: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 2
- **索引**: 2.0
- **bbox**: `BBox(x0=372, y0=55, x1=553, y1=85)`
- **标题级别**: 1

**Content**:

```
P14: 正态分布

```

**Image**: *(has image_base64)*


---

### Block 7: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 3.0
- **bbox**: `BBox(x0=53, y0=145, x1=860, y1=192)`

**Content**:

```
- 正态分布（又称高斯分布）是统计学中最重要、最常见的连续概率分布。其曲线呈对称的“钟形”，完美描述了自然界、社会及测量中大量随机变量的分布规律。高斯是首位将这一分布与误差理论深刻结合，并赋予其强大实际应用价值的科学家。正是由于他在天文学和测量学领域的权威影响，这个分布才在欧洲科学界被广泛知晓和应用，因此得名“高斯分布”。

```

**Image**: *(has image_base64)*


---

### Block 8: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 6.0
- **bbox**: `BBox(x0=88, y0=196, x1=810, y1=210)`

**Content**:

```
- 正态曲线（钟形曲线）的核心特征是：以均值为中心完全对称，形状由均值(μ)和标准差(σ)唯一决定，并服从“68-95-99.7”经验法则。
```

**Image**: *(has image_base64)*


---

### Block 9: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 6.001
- **bbox**: `BBox(x0=88, y0=213, x1=852, y1=241)`

**Content**:

```
- 正态分布的概率密度函数（Probability Density Function, PDF）的数学表达式为:1. 当 x = \mu 时，指数部分为0，函数取到最大值。2. 当 x 远离 \mu 时， (x - \mu)^2 增大，指数部分迅速衰减为0，导致概率密度急剧下降。
```

**Image**: *(has image_base64)*


---

### Block 10: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 7.0
- **bbox**: `BBox(x0=54, y0=250, x1=146, y1=265)`

**Content**:

```
- 正态曲线下

```

**Image**: *(has image_base64)*


---

### Block 11: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 8.0
- **bbox**: `BBox(x0=90, y0=270, x1=332, y1=284)`

**Content**:

```
- 横轴区间 (\mu - \sigma, \mu + \sigma) 内的面积为 68.268949\%

```

**Image**: *(has image_base64)*


---

### Block 12: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 9.0
- **bbox**: `BBox(x0=126, y0=288, x1=277, y1=300)`

**Content**:

```
P{|X-μ|<σ}=2Φ（1）-1=0.6826

```

**Image**: *(has image_base64)*


---

### Block 13: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 10.0
- **bbox**: `BBox(x0=90, y0=304, x1=388, y1=318)`

**Content**:

```
- 横轴区间（ \mu - 1.96\sigma, \mu + 1.96\sigma ）内的面积为 95.449974\%

```

**Image**: *(has image_base64)*


---

### Block 14: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 11.0
- **bbox**: `BBox(x0=127, y0=322, x1=282, y1=334)`

**Content**:

```
\mathsf{P}\{|X - \mu | <   2\sigma \} = 2\Phi （2）-1=0.9544

```

**Image**: *(has image_base64)*


---

### Block 15: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 12.0
- **bbox**: `BBox(x0=90, y0=337, x1=385, y1=352)`

**Content**:

```
横轴区间（ \mu - 2.58\sigma, \mu + 2.58\sigma ）内的面积为 99.730020\%

```

**Image**: *(has image_base64)*


---

### Block 16: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 13.0
- **bbox**: `BBox(x0=127, y0=356, x1=282, y1=367)`

**Content**:

```
\mathsf{P}\{|X - \mu | < 3\sigma \} = 2\Phi （3）-1=0.9974

```

**Image**: *(has image_base64)*


---

### Block 17: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 14.0
- **bbox**: `BBox(x0=53, y0=380, x1=580, y1=430)`

**Content**:

```
- “小概率事件”通常指发生的概率小于5%的事件,认为在一次试验中该事件是几乎不可能发生的.这种认识便是进行推断的出发点.关于这一点我们要有以下两个方面的认识:一是这里的“几乎不可能发生”是针对“一次试验”来说的,因为试验次数多了,该事件当然是很可能发生的;二是当我们运用“小概率事件几乎不可能发生的原理”进行推断时,我们也有5%的犯错误的可能.

```

**Image**: *(has image_base64)*


---

### Block 18: image

- **类型**: `image`
- **源类型**: `image`
- **页码**: 2
- **索引**: 15.0
- **bbox**: `BBox(x0=602, y0=275, x1=865, y1=461)`

**Content**:

*(empty)*

**Image**: *(has image_base64)*


---

### Block 19: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 2
- **索引**: -999.999
- **bbox**: `BBox(x0=14, y0=10, x1=222, y1=30)`

**Content**:

```
Confidential/xzixong261030

```

**Image**: *(has image_base64)*


---

### Block 20: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 2
- **索引**: -999.9988
- **bbox**: `BBox(x0=744, y0=12, x1=876, y1=27)`

**Content**:

```
2026年7月29日14时19分

```

**Image**: *(has image_base64)*


---

### Block 21: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 2
- **索引**: 9999.0504
- **bbox**: `BBox(x0=65, y0=504, x1=111, y1=529)`

**Content**:

```
SMIC

```

**Image**: *(has image_base64)*


---

### Block 22: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 2
- **索引**: 9999.0505
- **bbox**: `BBox(x0=456, y0=505, x1=533, y1=514)`

**Content**:

```
MatrixOne Intelligence

```

**Image**: *(has image_base64)*


---

### Block 23: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 2
- **索引**: 9999.0514
- **bbox**: `BBox(x0=305, y0=514, x1=684, y1=524)`

**Content**:

```
Copyright © 2026 矩阵起源（深圳）信息科技有限公司粤公安网备44030402004672号|粤ICP备2021044820号

```

**Image**: *(has image_base64)*


---

### Block 24: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 3.0
- **bbox**: `BBox(x0=32, y0=82, x1=182, y1=100)`

**Content**:

```
Issue Description:

```

**Image**: *(has image_base64)*


---

### Block 25: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 4.0
- **bbox**: `BBox(x0=69, y0=105, x1=402, y1=122)`

**Content**:

```
\checkmark Pie inform 18ums 03YB S4H154/159 WAT VBG fail

```

**Image**: *(has image_base64)*


---

### Block 26: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 5.0
- **bbox**: `BBox(x0=32, y0=133, x1=107, y1=151)`

**Content**:

```
Impact:

```

**Image**: *(has image_base64)*


---

### Block 27: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 6.0
- **bbox**: `BBox(x0=69, y0=157, x1=185, y1=173)`

**Content**:

```
√ VBG&GOI scrap

```

**Image**: *(has image_base64)*


---

### Block 28: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 7.0
- **bbox**: `BBox(x0=32, y0=184, x1=200, y1=203)`

**Content**:

```
Evidence & Analysis:

```

**Image**: *(has image_base64)*


---

### Block 29: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 13.0
- **bbox**: `BBox(x0=69, y0=208, x1=150, y1=222)`

**Content**:

```
√tile 1 desc
```

**Image**: *(has image_base64)*


---

### Block 30: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 13.001
- **bbox**: `BBox(x0=69, y0=230, x1=151, y1=244)`

**Content**:

```
\checkmark tile 2 desc
```

**Image**: *(has image_base64)*


---

### Block 31: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 13.002
- **bbox**: `BBox(x0=69, y0=251, x1=150, y1=265)`

**Content**:

```
√tile 3 desc
```

**Image**: *(has image_base64)*


---

### Block 32: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 13.003
- **bbox**: `BBox(x0=69, y0=273, x1=150, y1=287)`

**Content**:

```
√tile4desc
```

**Image**: *(has image_base64)*


---

### Block 33: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 13.004
- **bbox**: `BBox(x0=69, y0=294, x1=150, y1=308)`

**Content**:

```
√tile5desc
```

**Image**: *(has image_base64)*


---

### Block 34: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 14.0
- **bbox**: `BBox(x0=32, y0=321, x1=138, y1=338)`

**Content**:

```
Root Cause:

```

**Image**: *(has image_base64)*


---

### Block 35: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 15.0
- **bbox**: `BBox(x0=69, y0=343, x1=442, y1=362)`

**Content**:

```
\checkmark Dry pump含金属成分的密封镀层再高温下附着不稳定

```

**Image**: *(has image_base64)*


---

### Block 36: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 16.0
- **bbox**: `BBox(x0=32, y0=372, x1=111, y1=388)`

**Content**:

```
Actions:

```

**Image**: *(has image_base64)*


---

### Block 37: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 19.0
- **bbox**: `BBox(x0=69, y0=395, x1=504, y1=413)`

**Content**:

```
√ Dry pump维修不是用密封镀层或使用不含金属成分的密封镀层
```

**Image**: *(has image_base64)*


---

### Block 38: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 19.001
- **bbox**: `BBox(x0=69, y0=417, x1=480, y1=454)`

**Content**:

```
\checkmark 值班手册更新：Asher太极更换dry pump constraint LDD loop 11、15
```

**Image**: *(has image_base64)*


---

### Block 39: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 20.0
- **bbox**: `BBox(x0=32, y0=467, x1=160, y1=485)`

**Content**:

```
Lot Disposition

```

**Image**: *(has image_base64)*


---

### Block 40: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 21.0
- **bbox**: `BBox(x0=69, y0=490, x1=199, y1=504)`

**Content**:

```
√ scrap 3xxx xxx xxx

```

**Image**: *(has image_base64)*


---

### Block 41: image

- **类型**: `image`
- **源类型**: `image`
- **页码**: 3
- **索引**: 23.0
- **bbox**: `BBox(x0=513, y0=85, x1=569, y1=124)`

**Content**:

*(empty)*

**Image**: *(has image_base64)*


---

### Block 42: image

- **类型**: `image`
- **源类型**: `image`
- **页码**: 3
- **索引**: 24.0
- **bbox**: `BBox(x0=513, y0=139, x1=569, y1=179)`

**Content**:

*(empty)*

**Image**: *(has image_base64)*


---

### Block 43: image

- **类型**: `image`
- **源类型**: `image`
- **页码**: 3
- **索引**: 25.0
- **bbox**: `BBox(x0=513, y0=203, x1=569, y1=243)`

**Content**:

*(empty)*

**Image**: *(has image_base64)*


---

### Block 44: image

- **类型**: `image`
- **源类型**: `image`
- **页码**: 3
- **索引**: 26.0
- **bbox**: `BBox(x0=513, y0=321, x1=569, y1=360)`

**Content**:

*(empty)*

**Image**: *(has image_base64)*


---

### Block 45: image

- **类型**: `image`
- **源类型**: `image`
- **页码**: 3
- **索引**: 27.0
- **bbox**: `BBox(x0=513, y0=392, x1=569, y1=432)`

**Content**:

*(empty)*

**Image**: *(has image_base64)*


---

### Block 46: image

- **类型**: `image`
- **源类型**: `image`
- **页码**: 3
- **索引**: 28.0
- **bbox**: `BBox(x0=513, y0=454, x1=569, y1=493)`

**Content**:

*(empty)*

**Image**: *(has image_base64)*


---

### Block 47: image

- **类型**: `image`
- **源类型**: `image`
- **页码**: 3
- **索引**: 29.0
- **bbox**: `BBox(x0=596, y0=62, x1=792, y1=199)`

**Content**:

*(empty)*

**Image**: *(has image_base64)*


---

### Block 48: image

- **类型**: `image`
- **源类型**: `image`
- **页码**: 3
- **索引**: 30.0
- **bbox**: `BBox(x0=590, y0=206, x1=774, y1=392)`

**Content**:

*(empty)*

**Image**: *(has image_base64)*


---

### Block 49: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 3
- **索引**: 31.0
- **bbox**: `BBox(x0=799, y0=233, x1=935, y1=247)`

**Content**:

```
TABLE_placeHOLDER_001
```

**Image**: *(no image)*


---

### Block 50: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 3
- **索引**: -999.9989
- **bbox**: `BBox(x0=62, y0=11, x1=220, y1=29)`

**Content**:

```
ential/xzixong261030

```

**Image**: *(has image_base64)*


---

### Block 51: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 3
- **索引**: -999.9989
- **bbox**: `BBox(x0=228, y0=11, x1=784, y1=41)`

**Content**:

```
IMP MCI Tune Beam-AMU Out Of Tange Error

```

**Image**: *(has image_base64)*


---

### Block 52: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 3
- **索引**: 9999.0505
- **bbox**: `BBox(x0=64, y0=505, x1=111, y1=529)`

**Content**:

```
SMIC

```

**Image**: *(has image_base64)*


---

### Block 53: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 4
- **索引**: 2.0
- **bbox**: `BBox(x0=372, y0=55, x1=553, y1=85)`
- **标题级别**: 1

**Content**:

```
P14: 正态分布

```

**Image**: *(has image_base64)*


---

### Block 54: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 4
- **索引**: 3.0
- **bbox**: `BBox(x0=53, y0=145, x1=860, y1=192)`

**Content**:

```
- 正态分布（又称高斯分布）是统计学中最重要、最常见的连续概率分布。其曲线呈对称的“钟形”，完美描述了自然界、社会及测量中大量随机变量的分布规律。高斯是首位将这一分布与误差理论深刻结合，并赋予其强大实际应用价值的科学家。正是由于他在天文学和测量学领域的权威影响，这个分布才在欧洲科学界被广泛知晓和应用，因此得名“高斯分布”。

```

**Image**: *(has image_base64)*


---

### Block 55: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 4
- **索引**: 6.0
- **bbox**: `BBox(x0=88, y0=196, x1=811, y1=210)`

**Content**:

```
- 正态曲线（钟形曲线）的核心特征是：以均值为中心完全对称，形状由均值(μ)和标准差(σ)唯一决定，并服从“68-95-99.7”经验法则。
```

**Image**: *(has image_base64)*


---

### Block 56: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 4
- **索引**: 6.001
- **bbox**: `BBox(x0=88, y0=213, x1=852, y1=241)`

**Content**:

```
- 正态分布的概率密度函数（Probability Density Function, PDF）的数学表达式为:1. 当 x = \mu 时，指数部分为0，函数取到最大值。2. 当 x 远离 \mu 时， (x - \mu)^{2} 增大，指数部分迅速衰减为0，导致概率密度急剧下降。
```

**Image**: *(has image_base64)*


---

### Block 57: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 4
- **索引**: 7.0
- **bbox**: `BBox(x0=54, y0=250, x1=145, y1=265)`

**Content**:

```
- 正态曲线下

```

**Image**: *(has image_base64)*


---

### Block 58: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 4
- **索引**: 8.0
- **bbox**: `BBox(x0=90, y0=270, x1=333, y1=284)`

**Content**:

```
- 横轴区间 (\mu - \sigma, \mu + \sigma) 内的面积为 68.268949\%

```

**Image**: *(has image_base64)*


---

### Block 59: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 4
- **索引**: 9.0
- **bbox**: `BBox(x0=127, y0=288, x1=277, y1=300)`

**Content**:

```
P{|X-μ|<σ}=2Φ（1）-1=0.6826

```

**Image**: *(has image_base64)*


---

### Block 60: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 4
- **索引**: 10.0
- **bbox**: `BBox(x0=90, y0=304, x1=388, y1=318)`

**Content**:

```
- 横轴区间（ \mu - 1.96\sigma, \mu + 1.96\sigma ）内的面积为 95.449974\%

```

**Image**: *(has image_base64)*


---

### Block 61: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 4
- **索引**: 11.0
- **bbox**: `BBox(x0=127, y0=322, x1=282, y1=334)`

**Content**:

```
\mathsf{P}\{|X - \mu | <   2\sigma \} = 2\Phi （2）-1=0.9544

```

**Image**: *(has image_base64)*


---

### Block 62: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 4
- **索引**: 12.0
- **bbox**: `BBox(x0=90, y0=337, x1=385, y1=352)`

**Content**:

```
横轴区间（ \mu - 2.58\sigma, \mu + 2.58\sigma ）内的面积为 99.730020\%

```

**Image**: *(has image_base64)*


---

### Block 63: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 4
- **索引**: 13.0
- **bbox**: `BBox(x0=127, y0=356, x1=282, y1=367)`

**Content**:

```
\mathsf{P}\{|X - \mu | < 3\sigma \} = 2\Phi （3）-1=0.9974

```

**Image**: *(has image_base64)*


---

### Block 64: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 4
- **索引**: 14.0
- **bbox**: `BBox(x0=54, y0=380, x1=580, y1=430)`

**Content**:

```
- “小概率事件”通常指发生的概率小于5%的事件,认为在一次试验中该事件是几乎不可能发生的.这种认识便是进行推断的出发点.关于这一点我们要有以下两个方面的认识:一是这里的“几乎不可能发生”是针对“一次试验”来说的,因为试验次数多了,该事件当然是很可能发生的;二是当我们运用“小概率事件几乎不可能发生的原理”进行推断时,我们也有5%的犯错误的可能.

```

**Image**: *(has image_base64)*


---

### Block 65: image

- **类型**: `image`
- **源类型**: `image`
- **页码**: 4
- **索引**: 15.0
- **bbox**: `BBox(x0=602, y0=275, x1=865, y1=461)`

**Content**:

*(empty)*

**Image**: *(has image_base64)*


---

### Block 66: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 4
- **索引**: -999.999
- **bbox**: `BBox(x0=14, y0=10, x1=222, y1=30)`

**Content**:

```
Confidential/xzixong261030

```

**Image**: *(has image_base64)*


---

### Block 67: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 4
- **索引**: -999.9988
- **bbox**: `BBox(x0=744, y0=12, x1=876, y1=27)`

**Content**:

```
2026年7月29日14时19分

```

**Image**: *(has image_base64)*


---

### Block 68: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 4
- **索引**: 9999.0504
- **bbox**: `BBox(x0=65, y0=504, x1=111, y1=529)`

**Content**:

```
SMIC

```

**Image**: *(has image_base64)*


---

### Block 69: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 4
- **索引**: 9999.0505
- **bbox**: `BBox(x0=456, y0=505, x1=533, y1=514)`

**Content**:

```
MatrixOne Intelligence

```

**Image**: *(has image_base64)*


---

### Block 70: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 4
- **索引**: 9999.0514
- **bbox**: `BBox(x0=305, y0=514, x1=684, y1=524)`

**Content**:

```
Copyright © 2026 矩阵起源（深圳）信息科技有限公司粤公安网备44030402004672号|粤ICP备2021044820号

```

**Image**: *(has image_base64)*


---
