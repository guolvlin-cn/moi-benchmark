# MinerU Parser Debug Output

**生成时间**: 2026-07-29T14:16:01.095293

**Block 总数**: 19


---

## 类型统计

| 类型 | 数量 |
|------|------|
| footer | 4 |
| header | 4 |
| list | 5 |
| text | 4 |
| title | 2 |

---

## Block 详情

### Block 0: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 2.0
- **bbox**: `BBox(x0=323, y0=206, x1=635, y1=267)`
- **标题级别**: 1

**Content**:

```
YMSmock

```

**Image**: *(has image_base64)*


---

### Block 1: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 1
- **索引**: -999.9992
- **bbox**: `BBox(x0=5, y0=8, x1=222, y1=32)`

**Content**:

```
SMIC dental/xzixong261030

```

**Image**: *(has image_base64)*


---

### Block 2: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 1
- **索引**: -999.9988
- **bbox**: `BBox(x0=808, y0=12, x1=937, y1=25)`

**Content**:

```
2026年7月29日14时15分

```

**Image**: *(has image_base64)*


---

### Block 3: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 1
- **索引**: 9999.0504
- **bbox**: `BBox(x0=63, y0=504, x1=111, y1=529)`

**Content**:

```
SMIC

```

**Image**: *(has image_base64)*


---

### Block 4: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 1
- **索引**: 9999.0502
- **bbox**: `BBox(x0=437, y0=502, x1=552, y1=513)`

**Content**:

```
MatrixOne Intelligence

```

**Image**: *(has image_base64)*


---

### Block 5: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 1
- **索引**: 9999.0515
- **bbox**: `BBox(x0=211, y0=515, x1=778, y1=529)`

**Content**:

```
Copyright © 2026 矩阵起源（深圳）信息科技有限公司粤公安网备 44030402004672号 | 粤ICP备2021044820号

```

**Image**: *(has image_base64)*


---

### Block 6: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 2
- **索引**: 2.0
- **bbox**: `BBox(x0=378, y0=63, x1=493, y1=92)`
- **标题级别**: 1

**Content**:

```
线性回归

```

**Image**: *(has image_base64)*


---

### Block 7: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 3.0
- **bbox**: `BBox(x0=136, y0=112, x1=736, y1=149)`

**Content**:

```
《春》是现代散文家朱自清创作的散文，最初发表于1933年7月，此后长期被中国中学语文教材选用。《春》的篇幅很短，全文只有七百多字，共分十个自然段，可分成三部分。

```

**Image**: *(has image_base64)*


---

### Block 8: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 6.0
- **bbox**: `BBox(x0=172, y0=150, x1=635, y1=167)`

**Content**:

```
□ 《第一部分，即第一个自然段，写盼春的心切和迎春的喜悦；
```

**Image**: *(has image_base64)*


---

### Block 9: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 6.001
- **bbox**: `BBox(x0=172, y0=169, x1=732, y1=206)`

**Content**:

```
口 第二部分，即第二至第七个自然段，对春天的景物进行了形象地描绘，第三部分，即第八至第十自然段，是对春天的颂扬。
```

**Image**: *(has image_base64)*


---

### Block 10: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 7.0
- **bbox**: `BBox(x0=136, y0=207, x1=743, y1=242)`

**Content**:

```
□ 在该篇“贮满诗意”的“春的赞歌”中，事实上饱含了作家特定时期的思想情绪、对人生及至人格的追求，

```

**Image**: *(has image_base64)*


---

### Block 11: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 11.0
- **bbox**: `BBox(x0=172, y0=245, x1=557, y1=262)`

**Content**:

```
□ 表现了作家骨子里的传统文化积淀和他对自由境界的向往。
```

**Image**: *(has image_base64)*


---

### Block 12: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 11.001
- **bbox**: `BBox(x0=172, y0=264, x1=732, y1=318)`

**Content**:

```
1927年之后的朱自清，始终在寻觅着、营造着一个灵魂深处的理想世界——梦的世界，用以安放他“颇不宁静”的拳拳之心，抵御外面世界的纷扰，使他在幽闭的书斋中“独善其身”并成就他的治
```

**Image**: *(has image_base64)*


---

### Block 13: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 11.002
- **bbox**: `BBox(x0=172, y0=320, x1=732, y1=356)`

**Content**:

```
□ 在该篇“贮满诗意”的“春的赞歌”中，事实上饱含了作家特定时期的思想情绪、对人生及至人格的追求，表现了作家骨子里
```

**Image**: *(has image_base64)*


---

### Block 14: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 12.0
- **bbox**: `BBox(x0=136, y0=358, x1=366, y1=376)`

**Content**:

```
1R平方(R-squared) Cor平方[0, 1].

```

**Image**: *(has image_base64)*


---

### Block 15: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 2
- **索引**: 13.0
- **bbox**: `BBox(x0=393, y0=397, x1=585, y1=414)`

**Content**:

```
TABLE_placeHOLDER_001
```

**Image**: *(no image)*


---

### Block 16: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 2
- **索引**: -999.999
- **bbox**: `BBox(x0=14, y0=10, x1=222, y1=30)`

**Content**:

```
Confidential/xzixong261030

```

**Image**: *(has image_base64)*


---

### Block 17: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 2
- **索引**: -999.9988
- **bbox**: `BBox(x0=744, y0=12, x1=876, y1=27)`

**Content**:

```
2026年7月29日14时15分

```

**Image**: *(has image_base64)*


---

### Block 18: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 2
- **索引**: 9999.0522
- **bbox**: `BBox(x0=90, y0=522, x1=102, y1=529)`

**Content**:

```
#

```

**Image**: *(has image_base64)*


---
