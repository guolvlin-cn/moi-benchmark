# MinerU Parser Debug Output

**生成时间**: 2026-07-29T14:08:17.405490

**Block 总数**: 15


---

## 类型统计

| 类型 | 数量 |
|------|------|
| list | 12 |
| text | 3 |

---

## Block 详情

### Block 0: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 7.0
- **bbox**: `BBox(x0=87, y0=73, x1=132, y1=84)`

**Content**:

```
1. 绪论
```

**Image**: *(has image_base64)*


---

### Block 1: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 7.001
- **bbox**: `BBox(x0=87, y0=89, x1=163, y1=101)`

**Content**:

```
2. 运算放大器
```

**Image**: *(has image_base64)*


---

### Block 2: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 7.002
- **bbox**: `BBox(x0=87, y0=104, x1=205, y1=116)`

**Content**:

```
3. 二极管及其基本电路
```

**Image**: *(has image_base64)*


---

### Block 3: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 7.003
- **bbox**: `BBox(x0=87, y0=120, x1=236, y1=132)`

**Content**:

```
4. 场效应三极管及其放大电路
```

**Image**: *(has image_base64)*


---

### Block 4: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 7.004
- **bbox**: `BBox(x0=87, y0=135, x1=247, y1=147)`

**Content**:

```
5. 双极结型三极管及其放大电路
```

**Image**: *(has image_base64)*


---

### Block 5: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 7.005
- **bbox**: `BBox(x0=87, y0=151, x1=153, y1=163)`

**Content**:

```
6. 频率响应
```

**Image**: *(has image_base64)*


---

### Block 6: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 7.006
- **bbox**: `BBox(x0=87, y0=166, x1=174, y1=179)`

**Content**:

```
7. 模拟集成电路
```

**Image**: *(has image_base64)*


---

### Block 7: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 8.0
- **bbox**: `BBox(x0=108, y0=182, x1=279, y1=194)`

**Content**:

```
7.1. 模拟集成电路中的直流偏置技术

```

**Image**: *(has image_base64)*


---

### Block 8: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 11.0
- **bbox**: `BBox(x0=128, y0=197, x1=239, y1=210)`

**Content**:

```
7.1.1. FET电流源电路
```

**Image**: *(has image_base64)*


---

### Block 9: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 11.001
- **bbox**: `BBox(x0=128, y0=213, x1=239, y1=225)`

**Content**:

```
7.1.2. BJT 电流源电路
```

**Image**: *(has image_base64)*


---

### Block 10: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 15.0
- **bbox**: `BBox(x0=87, y0=228, x1=184, y1=241)`

**Content**:

```
8. 差分式放大电路
```

**Image**: *(has image_base64)*


---

### Block 11: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 15.001
- **bbox**: `BBox(x0=87, y0=244, x1=237, y1=257)`

**Content**:

```
9. 差分式放大电路的传输特性
```

**Image**: *(has image_base64)*


---

### Block 12: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 15.002
- **bbox**: `BBox(x0=88, y0=259, x1=174, y1=272)`

**Content**:

```
10. 反馈放大电路
```

**Image**: *(has image_base64)*


---

### Block 13: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 16.0
- **bbox**: `BBox(x0=88, y0=338, x1=131, y1=350)`

**Content**:

```
测试表格

```

**Image**: *(has image_base64)*


---

### Block 14: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 1
- **索引**: 17.0
- **bbox**: `BBox(x0=201, y0=359, x1=389, y1=375)`

**Content**:

```
TABLE_placeHOLDER_001
```

**Image**: *(no image)*


---
