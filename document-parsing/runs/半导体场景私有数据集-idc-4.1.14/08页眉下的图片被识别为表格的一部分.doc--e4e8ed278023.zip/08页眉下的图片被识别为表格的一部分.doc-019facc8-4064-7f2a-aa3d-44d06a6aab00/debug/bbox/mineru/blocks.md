# MinerU Parser Debug Output

**生成时间**: 2026-07-29T15:30:54.875948

**Block 总数**: 45


---

## 类型统计

| 类型 | 数量 |
|------|------|
| image | 3 |
| list | 12 |
| text | 21 |
| title | 9 |

---

## Block 详情

### Block 0: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 7.0
- **bbox**: `BBox(x0=35, y0=111, x1=80, y1=124)`

**Content**:

```
1. 绪论
```

**Image**: *(has image_base64)*


---

### Block 1: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 7.001
- **bbox**: `BBox(x0=35, y0=126, x1=112, y1=139)`

**Content**:

```
2. 运算放大器
```

**Image**: *(has image_base64)*


---

### Block 2: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 7.002
- **bbox**: `BBox(x0=35, y0=142, x1=154, y1=155)`

**Content**:

```
3. 二极管及其基本电路
```

**Image**: *(has image_base64)*


---

### Block 3: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 7.003
- **bbox**: `BBox(x0=35, y0=158, x1=185, y1=170)`

**Content**:

```
4. 场效应三极管及其放大电路
```

**Image**: *(has image_base64)*


---

### Block 4: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 7.004
- **bbox**: `BBox(x0=35, y0=174, x1=195, y1=186)`

**Content**:

```
5. 双极结型三极管及其放大电路
```

**Image**: *(has image_base64)*


---

### Block 5: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 7.005
- **bbox**: `BBox(x0=35, y0=190, x1=101, y1=201)`

**Content**:

```
6. 频率响应
```

**Image**: *(has image_base64)*


---

### Block 6: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 7.006
- **bbox**: `BBox(x0=35, y0=205, x1=121, y1=217)`

**Content**:

```
7. 模拟集成电路
```

**Image**: *(has image_base64)*


---

### Block 7: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 8.0
- **bbox**: `BBox(x0=55, y0=220, x1=227, y1=233)`
- **标题级别**: 2

**Content**:

```
7.1. 模拟集成电路中的直流偏置技术

```

**Image**: *(has image_base64)*


---

### Block 8: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 11.0
- **bbox**: `BBox(x0=76, y0=236, x1=184, y1=248)`

**Content**:

```
7.1.1. FET电流源电路
```

**Image**: *(has image_base64)*


---

### Block 9: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 11.001
- **bbox**: `BBox(x0=76, y0=252, x1=182, y1=264)`

**Content**:

```
7.1.2. BJT电流源电路
```

**Image**: *(has image_base64)*


---

### Block 10: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 15.0
- **bbox**: `BBox(x0=35, y0=267, x1=132, y1=280)`

**Content**:

```
8. 差分式放大电路
```

**Image**: *(has image_base64)*


---

### Block 11: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 15.001
- **bbox**: `BBox(x0=35, y0=283, x1=185, y1=296)`

**Content**:

```
9. 差分式放大电路的传输特性
```

**Image**: *(has image_base64)*


---

### Block 12: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 15.002
- **bbox**: `BBox(x0=35, y0=298, x1=121, y1=311)`

**Content**:

```
10. 反馈放大电路
```

**Image**: *(has image_base64)*


---

### Block 13: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 16.0
- **bbox**: `BBox(x0=35, y0=329, x1=80, y1=342)`

**Content**:

```
测试表格

```

**Image**: *(has image_base64)*


---

### Block 14: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 1
- **索引**: 17.0
- **bbox**: `BBox(x0=149, y0=351, x1=337, y1=368)`

**Content**:

```
TABLE_placeHOLDER_001
```

**Image**: *(no image)*


---

### Block 15: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 18.0
- **bbox**: `BBox(x0=35, y0=555, x1=131, y1=575)`
- **标题级别**: 2

**Content**:

```
1.1.解析效果

```

**Image**: *(has image_base64)*


---

### Block 16: image

- **类型**: `image`
- **源类型**: `image`
- **页码**: 2
- **索引**: 0.0
- **bbox**: `BBox(x0=67, y0=110, x1=480, y1=312)`
- **Captions**: ['图一.光照正面外观-\n']

**Content**:

*(empty)*

**Image**: *(has image_base64)*


---

### Block 17: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 2
- **索引**: 2.0
- **bbox**: `BBox(x0=99, y0=365, x1=193, y1=379)`
- **标题级别**: 3

**Content**:

```
1.1.1 广超反面外观

```

**Image**: *(has image_base64)*


---

### Block 18: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 3.0
- **bbox**: `BBox(x0=101, y0=409, x1=136, y1=423)`

**Content**:

```
最下方

```

**Image**: *(has image_base64)*


---

### Block 19: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 4.0
- **bbox**: `BBox(x0=102, y0=471, x1=136, y1=485)`

**Content**:

```
最下方

```

**Image**: *(has image_base64)*


---

### Block 20: image

- **类型**: `image`
- **源类型**: `image`
- **页码**: 2
- **索引**: 5.0
- **bbox**: `BBox(x0=223, y0=386, x1=373, y1=530)`

**Content**:

*(empty)*

**Image**: *(has image_base64)*


---

### Block 21: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 2
- **索引**: 6.0
- **bbox**: `BBox(x0=35, y0=548, x1=143, y1=565)`
- **标题级别**: 3

**Content**:

```
1.1.1. 文本类型

```

**Image**: *(has image_base64)*


---

### Block 22: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 2
- **索引**: 7.0
- **bbox**: `BBox(x0=35, y0=593, x1=143, y1=609)`
- **标题级别**: 4

**Content**:

```
1.1.1.1. 准确性

```

**Image**: *(has image_base64)*


---

### Block 23: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 8.0
- **bbox**: `BBox(x0=35, y0=633, x1=91, y1=645)`

**Content**:

```
\spadesuit 案例1：

```

**Image**: *(has image_base64)*


---

### Block 24: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 9.0
- **bbox**: `BBox(x0=35, y0=649, x1=278, y1=661)`

**Content**:

```
https://github.com/matrixorigin/MO-Cloud/issues/7018

```

**Image**: *(has image_base64)*


---

### Block 25: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 10.0
- **bbox**: `BBox(x0=36, y0=665, x1=90, y1=677)`

**Content**:

```
闵可夫斯基

```

**Image**: *(has image_base64)*


---

### Block 26: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 11.0
- **bbox**: `BBox(x0=36, y0=680, x1=114, y1=692)`

**Content**:

```
闵可夫·J·斯基

```

**Image**: *(has image_base64)*


---

### Block 27: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 12.0
- **bbox**: `BBox(x0=36, y0=696, x1=105, y1=708)`

**Content**:

```
测试记录：

```

**Image**: *(has image_base64)*


---

### Block 28: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 13.0
- **bbox**: `BBox(x0=35, y0=711, x1=242, y1=724)`

**Content**:

```
1. 2026-01-07 30B 模型 QA 环境验证未复现

```

**Image**: *(has image_base64)*


---

### Block 29: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 3
- **索引**: 0.0
- **bbox**: `BBox(x0=35, y0=145, x1=143, y1=163)`
- **标题级别**: 3

**Content**:

```
1.1.2. 图片类型

```

**Image**: *(has image_base64)*


---

### Block 30: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 3
- **索引**: 1.0
- **bbox**: `BBox(x0=35, y0=191, x1=143, y1=208)`
- **标题级别**: 4

**Content**:

```
1.1.2.1. 散点图

```

**Image**: *(has image_base64)*


---

### Block 31: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 2.0
- **bbox**: `BBox(x0=35, y0=232, x1=278, y1=244)`

**Content**:

```
https://github.com/matrixorigin/MO-Cloud/issues/6999

```

**Image**: *(has image_base64)*


---

### Block 32: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 3.0
- **bbox**: `BBox(x0=35, y0=262, x1=105, y1=274)`

**Content**:

```
预期结果：

```

**Image**: *(has image_base64)*


---

### Block 33: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 4.0
- **bbox**: `BBox(x0=35, y0=277, x1=278, y1=290)`

**Content**:

```
必须作为整体进行 Caption 和 OCR 解析，不能被拆分

```

**Image**: *(has image_base64)*


---

### Block 34: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 5.0
- **bbox**: `BBox(x0=35, y0=293, x1=105, y1=305)`

**Content**:

```
测试记录：

```

**Image**: *(has image_base64)*


---

### Block 35: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 6.0
- **bbox**: `BBox(x0=35, y0=309, x1=242, y1=322)`

**Content**:

```
2. 2026-01-07 30B 模型 QA 环境验证未复现

```

**Image**: *(has image_base64)*


---

### Block 36: image

- **类型**: `image`
- **源类型**: `image`
- **页码**: 3
- **索引**: 7.0
- **bbox**: `BBox(x0=42, y0=361, x1=383, y1=502)`

**Content**:

*(empty)*

**Image**: *(has image_base64)*


---

### Block 37: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 3
- **索引**: 8.0
- **bbox**: `BBox(x0=35, y0=560, x1=143, y1=578)`
- **标题级别**: 3

**Content**:

```
1.1.3. 表格类型

```

**Image**: *(has image_base64)*


---

### Block 38: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 3
- **索引**: 9.0
- **bbox**: `BBox(x0=35, y0=607, x1=143, y1=623)`
- **标题级别**: 4

**Content**:

```
1.1.3.1. 三线表

```

**Image**: *(has image_base64)*


---

### Block 39: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 10.0
- **bbox**: `BBox(x0=34, y0=647, x1=564, y1=706)`

**Content**:

```
The rapid advancement of semiconductor technology has fundamentally transformed the landscape of modern embedded systems. In today's industrial environment, the integration of high-performance microcontrollers, such as the STM32 series or ARM-based processors, is no longer just about raw clock speed. Instead, the focus has shifted toward power efficiency, hardware-level security, and seamless peripheral integration.

```

**Image**: *(has image_base64)*


---

### Block 40: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 11.0
- **bbox**: `BBox(x0=34, y0=725, x1=564, y1=737)`

**Content**:

```
Systems must now handle complex tasks ranging from real-time sensor fusion to high-speed data transmission via

```

**Image**: *(has image_base64)*


---

### Block 41: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 4
- **索引**: 0.0
- **bbox**: `BBox(x0=35, y0=113, x1=163, y1=125)`

**Content**:

```
encrypted network protocols.

```

**Image**: *(has image_base64)*


---

### Block 42: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 4
- **索引**: 1.0
- **bbox**: `BBox(x0=148, y0=135, x1=339, y1=151)`

**Content**:

```
TABLE_placeHOLDER_002
```

**Image**: *(no image)*


---

### Block 43: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 5
- **索引**: 0.0
- **bbox**: `BBox(x0=149, y0=119, x1=342, y1=137)`

**Content**:

```
TABLE_placeHOLDER_003
```

**Image**: *(no image)*


---

### Block 44: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 5
- **索引**: 1.0
- **bbox**: `BBox(x0=203, y0=353, x1=395, y1=370)`

**Content**:

```
TABLE_placeHOLDER_004
```

**Image**: *(no image)*


---
