# MinerU Parser Debug Output

**生成时间**: 2026-07-29T13:29:33.939733

**Block 总数**: 37


---

## 类型统计

| 类型 | 数量 |
|------|------|
| header | 18 |
| text | 18 |
| title | 1 |

---

## Block 详情

### Block 0: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 0.0
- **bbox**: `BBox(x0=88, y0=73, x1=174, y1=85)`

**Content**:

```
测试跨页表的拼接

```

**Image**: *(has image_base64)*


---

### Block 1: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 1.0
- **bbox**: `BBox(x0=87, y0=104, x1=158, y1=117)`
- **标题级别**: 1

**Content**:

```
case1 普通表

```

**Image**: *(has image_base64)*


---

### Block 2: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 1
- **索引**: 2.0
- **bbox**: `BBox(x0=201, y0=126, x1=390, y1=142)`

**Content**:

```
TABLE_placeHOLDER_001
```

**Image**: *(no image)*


---

### Block 3: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 2
- **索引**: 0.0
- **bbox**: `BBox(x0=201, y0=79, x1=393, y1=96)`

**Content**:

```
TABLE_placeHOLDER_002
```

**Image**: *(no image)*


---

### Block 4: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 3
- **索引**: 0.0
- **bbox**: `BBox(x0=201, y0=79, x1=393, y1=96)`

**Content**:

```
TABLE_placeHOLDER_003
```

**Image**: *(no image)*


---

### Block 5: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 4
- **索引**: 0.0
- **bbox**: `BBox(x0=88, y0=73, x1=157, y1=85)`

**Content**:

```
case2 多线表

```

**Image**: *(has image_base64)*


---

### Block 6: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 4
- **索引**: 1.0
- **bbox**: `BBox(x0=201, y0=95, x1=391, y1=111)`

**Content**:

```
TABLE_placeHOLDER_004
```

**Image**: *(no image)*


---

### Block 7: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 5
- **索引**: 0.0
- **bbox**: `BBox(x0=201, y0=79, x1=392, y1=95)`

**Content**:

```
TABLE_placeHOLDER_005
```

**Image**: *(no image)*


---

### Block 8: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 6
- **索引**: 0.0
- **bbox**: `BBox(x0=201, y0=79, x1=392, y1=95)`

**Content**:

```
TABLE_placeHOLDER_006
```

**Image**: *(no image)*


---

### Block 9: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 7
- **索引**: 1.0
- **bbox**: `BBox(x0=199, y0=95, x1=391, y1=111)`

**Content**:

```
TABLE_placeHOLDER_007
```

**Image**: *(no image)*


---

### Block 10: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 7
- **索引**: -999.9927
- **bbox**: `BBox(x0=88, y0=73, x1=156, y1=85)`

**Content**:

```
case3 三线表

```

**Image**: *(has image_base64)*


---

### Block 11: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 8
- **索引**: 0.0
- **bbox**: `BBox(x0=196, y0=83, x1=386, y1=100)`

**Content**:

```
TABLE_placeHOLDER_008
```

**Image**: *(no image)*


---

### Block 12: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 9
- **索引**: 0.0
- **bbox**: `BBox(x0=200, y0=81, x1=390, y1=98)`

**Content**:

```
TABLE_placeHOLDER_009
```

**Image**: *(no image)*


---

### Block 13: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 10
- **索引**: 3.0
- **bbox**: `BBox(x0=201, y0=106, x1=391, y1=122)`

**Content**:

```
TABLE_placeHOLDER_010
```

**Image**: *(no image)*


---

### Block 14: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 10
- **索引**: 4.0
- **bbox**: `BBox(x0=86, y0=150, x1=198, y1=163)`

**Content**:

```
case4 带页眉页脚的表

```

**Image**: *(has image_base64)*


---

### Block 15: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 10
- **索引**: 5.0
- **bbox**: `BBox(x0=201, y0=173, x1=390, y1=188)`

**Content**:

```
TABLE_placeHOLDER_011
```

**Image**: *(no image)*


---

### Block 16: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 10
- **索引**: -999.9958
- **bbox**: `BBox(x0=87, y0=42, x1=188, y1=52)`

**Content**:

```
2026.01.05 11:49 01234

```

**Image**: *(has image_base64)*


---

### Block 17: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 10
- **索引**: -999.993
- **bbox**: `BBox(x0=105, y0=70, x1=149, y1=92)`

**Content**:

```
#

```

**Image**: *(has image_base64)*


---

### Block 18: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 10
- **索引**: -999.993
- **bbox**: `BBox(x0=152, y0=70, x1=174, y1=92)`

**Content**:

```
驼阵起源

```

**Image**: *(has image_base64)*


---

### Block 19: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 11
- **索引**: 5.0
- **bbox**: `BBox(x0=201, y0=156, x1=392, y1=172)`

**Content**:

```
TABLE_placeHOLDER_013
```

**Image**: *(no image)*


---

### Block 20: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 11
- **索引**: -999.9958
- **bbox**: `BBox(x0=87, y0=42, x1=188, y1=52)`

**Content**:

```
2026.01.05 11:49 01234

```

**Image**: *(has image_base64)*


---

### Block 21: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 11
- **索引**: -999.993
- **bbox**: `BBox(x0=105, y0=70, x1=149, y1=92)`

**Content**:

```
#

```

**Image**: *(has image_base64)*


---

### Block 22: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 11
- **索引**: -999.993
- **bbox**: `BBox(x0=152, y0=70, x1=174, y1=92)`

**Content**:

```
驼阵起源

```

**Image**: *(has image_base64)*


---

### Block 23: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 11
- **索引**: -999.9905
- **bbox**: `BBox(x0=185, y0=95, x1=412, y1=108)`

**Content**:

```
矩阵起源 MatrixOne_Al 原生超融合数据库产品

```

**Image**: *(has image_base64)*


---

### Block 24: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 11
- **索引**: -999.989
- **bbox**: `BBox(x0=201, y0=110, x1=392, y1=125)`

**Content**:

```
TABLE_placeHOLDER_012
```

**Image**: *(no image)*


---

### Block 25: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 12
- **索引**: 5.0
- **bbox**: `BBox(x0=201, y0=155, x1=392, y1=171)`

**Content**:

```
TABLE_placeHOLDER_015
```

**Image**: *(no image)*


---

### Block 26: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 12
- **索引**: -999.9958
- **bbox**: `BBox(x0=87, y0=42, x1=188, y1=52)`

**Content**:

```
2026.01.05 11:49 01234

```

**Image**: *(has image_base64)*


---

### Block 27: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 12
- **索引**: -999.993
- **bbox**: `BBox(x0=105, y0=70, x1=149, y1=92)`

**Content**:

```
#

```

**Image**: *(has image_base64)*


---

### Block 28: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 12
- **索引**: -999.993
- **bbox**: `BBox(x0=152, y0=70, x1=174, y1=92)`

**Content**:

```
驼阵起源

```

**Image**: *(has image_base64)*


---

### Block 29: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 12
- **索引**: -999.9905
- **bbox**: `BBox(x0=185, y0=95, x1=412, y1=108)`

**Content**:

```
矩阵起源 MatrixOne_Al 原生超融合数据库产品

```

**Image**: *(has image_base64)*


---

### Block 30: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 12
- **索引**: -999.989
- **bbox**: `BBox(x0=201, y0=110, x1=391, y1=123)`

**Content**:

```
TABLE PLACEHOLDER 014

```

**Image**: *(has image_base64)*


---

### Block 31: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 13
- **索引**: 5.0
- **bbox**: `BBox(x0=201, y0=156, x1=392, y1=173)`

**Content**:

```
TABLE_placeHOLDER_017
```

**Image**: *(no image)*


---

### Block 32: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 13
- **索引**: -999.9958
- **bbox**: `BBox(x0=87, y0=42, x1=188, y1=52)`

**Content**:

```
2026.01.05 11:49 01234

```

**Image**: *(has image_base64)*


---

### Block 33: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 13
- **索引**: -999.993
- **bbox**: `BBox(x0=105, y0=70, x1=149, y1=92)`

**Content**:

```
#

```

**Image**: *(has image_base64)*


---

### Block 34: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 13
- **索引**: -999.993
- **bbox**: `BBox(x0=152, y0=70, x1=174, y1=92)`

**Content**:

```
驼阵起源

```

**Image**: *(has image_base64)*


---

### Block 35: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 13
- **索引**: -999.9905
- **bbox**: `BBox(x0=185, y0=95, x1=412, y1=108)`

**Content**:

```
矩阵起源 MatrixOne_Al 原生超融合数据库产品

```

**Image**: *(has image_base64)*


---

### Block 36: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 13
- **索引**: -999.989
- **bbox**: `BBox(x0=201, y0=110, x1=392, y1=124)`

**Content**:

```
TABLE PLACEHOLDER 016

```

**Image**: *(has image_base64)*


---
