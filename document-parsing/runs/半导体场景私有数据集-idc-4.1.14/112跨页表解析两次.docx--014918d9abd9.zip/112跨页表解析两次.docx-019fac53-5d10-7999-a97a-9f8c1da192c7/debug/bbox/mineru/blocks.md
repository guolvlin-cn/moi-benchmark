# MinerU Parser Debug Output

**生成时间**: 2026-07-29T13:23:05.084952

**Block 总数**: 5


---

## 类型统计

| 类型 | 数量 |
|------|------|
| text | 4 |
| title | 1 |

---

## Block 详情

### Block 0: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 0.0
- **bbox**: `BBox(x0=32, y0=131, x1=562, y1=229)`

**Content**:

```
中芯国际（证券代码：00981.HK/688981.SH）是世界领先的集成电路晶圆代工企业之一，也是中国大陆集成电路制造业领导者，拥有领先的工艺制造能力、产能优势、服务配套，向全球客户提供0.35微米到FinFET不同技术节点的晶圆代工与技术服务。中芯国际总部位于中国上海，拥有全球化的制造和服务基地，在上海、北京、天津、深圳建有三座8英寸晶圆厂和四座12英寸晶圆厂；在上海、北京、天津各有一座12英寸晶圆厂在建中。中芯国际还在美国、欧洲、日本和中国台湾设立营销办事处、提供客户服务，同时在中国香港设立了代表处。详细资讯请参考中芯国际网站www.smics.com

```

**Image**: *(has image_base64)*


---

### Block 1: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 1.0
- **bbox**: `BBox(x0=32, y0=242, x1=557, y1=337)`

**Content**:

```
Semiconductor Manufacturing International Corp is an investment holding company principally engaged in integrated circuit foundry business. The Company is engaged in the manufacturing and testing of silicon wafers and types of compound semiconductor integrated circuit wafers. The Company also provides integrated circuit-related development, design and technical services, photomask manufacturing, testing and sales of self-produced products as well as other services. The Company provides foundry and technical services to domestic and foreign customers

```

**Image**: *(has image_base64)*


---

### Block 2: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 2.0
- **bbox**: `BBox(x0=249, y0=428, x1=345, y1=444)`
- **标题级别**: 1

**Content**:

```
表一 中英文对应

```

**Image**: *(has image_base64)*


---

### Block 3: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 1
- **索引**: 3.0
- **bbox**: `BBox(x0=201, y0=451, x1=390, y1=468)`

**Content**:

```
TABLE_placeHOLDER_001
```

**Image**: *(no image)*


---

### Block 4: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 2
- **索引**: 0.0
- **bbox**: `BBox(x0=201, y0=139, x1=391, y1=156)`

**Content**:

```
TABLE_placeHOLDER_002
```

**Image**: *(no image)*


---
