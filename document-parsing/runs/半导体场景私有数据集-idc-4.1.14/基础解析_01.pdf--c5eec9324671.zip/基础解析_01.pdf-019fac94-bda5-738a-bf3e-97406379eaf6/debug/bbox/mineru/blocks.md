# MinerU Parser Debug Output

**生成时间**: 2026-07-29T14:34:26.174084

**Block 总数**: 7


---

## 类型统计

| 类型 | 数量 |
|------|------|
| text | 5 |
| title | 2 |

---

## Block 详情

### Block 0: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 0.0
- **bbox**: `BBox(x0=214, y0=84, x1=380, y1=106)`
- **标题级别**: 1

**Content**:

```
系统功能模块说明书

```

**Image**: *(has image_base64)*


---

### Block 1: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 1.0
- **bbox**: `BBox(x0=157, y0=118, x1=436, y1=132)`

**Content**:

```
文档编号：SYS-2026-001 | 版本：V1.0 | 日期：2026-04-17

```

**Image**: *(has image_base64)*


---

### Block 2: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 2.0
- **bbox**: `BBox(x0=69, y0=142, x1=186, y1=159)`
- **标题级别**: 1

**Content**:

```
一、功能模块总览

```

**Image**: *(has image_base64)*


---

### Block 3: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 3.0
- **bbox**: `BBox(x0=69, y0=169, x1=525, y1=196)`

**Content**:

```
下表列出了系统各功能模块的详细说明。表格包含合并单元格和嵌入流程图，用于展示多模态文档解析能力。

```

**Image**: *(has image_base64)*


---

### Block 4: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 1
- **索引**: 4.0
- **bbox**: `BBox(x0=208, y0=216, x1=399, y1=233)`

**Content**:

```
TABLE_placeHOLDER_001
```

**Image**: *(no image)*


---

### Block 5: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 2
- **索引**: 0.0
- **bbox**: `BBox(x0=208, y0=79, x1=400, y1=96)`

**Content**:

```
TABLE_placeHOLDER_002
```

**Image**: *(no image)*


---

### Block 6: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 1.0
- **bbox**: `BBox(x0=69, y0=391, x1=409, y1=404)`

**Content**:

```
注：以上模块规划基于2026年度产品路线图，实际交付时间以项目排期为准。

```

**Image**: *(has image_base64)*


---
