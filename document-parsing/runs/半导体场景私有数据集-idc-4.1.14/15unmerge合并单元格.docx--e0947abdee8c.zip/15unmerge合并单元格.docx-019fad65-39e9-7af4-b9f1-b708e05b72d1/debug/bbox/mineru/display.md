# MINERU BBox Visualization

## Page 1

![Page 1](./pages/page-1.webp)

## Page 2

![Page 2](./pages/page-2.webp)

## Page 3

![Page 3](./pages/page-3.webp)

## Page 4

![Page 4](./pages/page-4.webp)

## Page 5

![Page 5](./pages/page-5.webp)

## Page 6

![Page 6](./pages/page-6.webp)

## Page 7

![Page 7](./pages/page-7.webp)
