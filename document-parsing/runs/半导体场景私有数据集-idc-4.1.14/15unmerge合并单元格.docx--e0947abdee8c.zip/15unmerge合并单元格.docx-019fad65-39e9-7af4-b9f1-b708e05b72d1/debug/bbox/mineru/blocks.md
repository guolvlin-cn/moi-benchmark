# MinerU Parser Debug Output

**生成时间**: 2026-07-29T18:22:22.720236

**Block 总数**: 139


---

## 类型统计

| 类型 | 数量 |
|------|------|
| image | 1 |
| list | 76 |
| text | 41 |
| title | 21 |

---

## Block 详情

### Block 0: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 0.0
- **bbox**: `BBox(x0=229, y0=151, x1=358, y1=165)`
- **标题级别**: 1

**Content**:

```
AI应用落地方案说明书

```

**Image**: *(has image_base64)*


---

### Block 1: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 1.0
- **bbox**: `BBox(x0=38, y0=191, x1=547, y1=205)`
- **标题级别**: 1

**Content**:

```
1. Project background and objectives. 错误！未定义书签。

```

**Image**: *(has image_base64)*


---

### Block 2: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 6.0
- **bbox**: `BBox(x0=58, y0=207, x1=547, y1=221)`

**Content**:

```
1.1. DCC: Document Control Center 错误！未定义书签。
```

**Image**: *(has image_base64)*


---

### Block 3: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 6.001
- **bbox**: `BBox(x0=58, y0=223, x1=547, y1=237)`

**Content**:

```
1.2. DCN: Document Change Notice(for Company Rules and Regulations)………错误！未定义书签。
```

**Image**: *(has image_base64)*


---

### Block 4: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 6.002
- **bbox**: `BBox(x0=58, y0=239, x1=547, y1=253)`

**Content**:

```
1.3.DMS：Document Management System..错误！未定义书签。
```

**Image**: *(has image_base64)*


---

### Block 5: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 6.003
- **bbox**: `BBox(x0=58, y0=254, x1=547, y1=268)`

**Content**:

```
1.4. Background description 错误！未定义书签。
```

**Image**: *(has image_base64)*


---

### Block 6: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 13.0
- **bbox**: `BBox(x0=79, y0=269, x1=547, y1=283)`

**Content**:

```
1.4.1. Industry prospects1 错误！未定义书签。
```

**Image**: *(has image_base64)*


---

### Block 7: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 13.001
- **bbox**: `BBox(x0=80, y0=285, x1=547, y1=299)`

**Content**:

```
1.4.2. Industry prospects2 错误！未定义书签。
```

**Image**: *(has image_base64)*


---

### Block 8: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 13.002
- **bbox**: `BBox(x0=80, y0=301, x1=547, y1=314)`

**Content**:

```
1.4.3. Industry prospects3 错误！未定义书签。
```

**Image**: *(has image_base64)*


---

### Block 9: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 13.003
- **bbox**: `BBox(x0=80, y0=317, x1=547, y1=330)`

**Content**:

```
1.4.4. Industry prospects4 错误！未定义书签。
```

**Image**: *(has image_base64)*


---

### Block 10: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 13.004
- **bbox**: `BBox(x0=80, y0=333, x1=547, y1=346)`

**Content**:

```
1.4.5. Industry prospects 错误！未定义书签。
```

**Image**: *(has image_base64)*


---

### Block 11: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 13.005
- **bbox**: `BBox(x0=80, y0=348, x1=547, y1=361)`

**Content**:

```
1.4.6. Main pain points. 错误！未定义书签。
```

**Image**: *(has image_base64)*


---

### Block 12: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 14.0
- **bbox**: `BBox(x0=58, y0=364, x1=547, y1=376)`

**Content**:

```
1.5. Construction objectives. 错误！未定义书签。

```

**Image**: *(has image_base64)*


---

### Block 13: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 15.0
- **bbox**: `BBox(x0=36, y0=380, x1=552, y1=392)`
- **标题级别**: 1

**Content**:

```
2. Overall scheme design 3

```

**Image**: *(has image_base64)*


---

### Block 14: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 18.0
- **bbox**: `BBox(x0=58, y0=395, x1=552, y1=407)`

**Content**:

```
2.1. Overview of system architecture 3
```

**Image**: *(has image_base64)*


---

### Block 15: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 18.001
- **bbox**: `BBox(x0=58, y0=410, x1=552, y1=423)`

**Content**:

```
2.2.技术选型说明 3
```

**Image**: *(has image_base64)*


---

### Block 16: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 22.0
- **bbox**: `BBox(x0=79, y0=425, x1=552, y1=439)`

**Content**:

```
2.2.1.后端与基础设施 3
```

**Image**: *(has image_base64)*


---

### Block 17: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 22.001
- **bbox**: `BBox(x0=79, y0=441, x1=552, y1=454)`

**Content**:

```
2.2.2. 模型相关 3
```

**Image**: *(has image_base64)*


---

### Block 18: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 22.002
- **bbox**: `BBox(x0=79, y0=456, x1=552, y1=470)`

**Content**:

```
2.2.3. 其他模型相关
```

**Image**: *(has image_base64)*


---

### Block 19: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 23.0
- **bbox**: `BBox(x0=58, y0=473, x1=552, y1=486)`
- **标题级别**: 2

**Content**:

```
2.3. Technical selection description 3

```

**Image**: *(has image_base64)*


---

### Block 20: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 26.0
- **bbox**: `BBox(x0=79, y0=488, x1=552, y1=501)`

**Content**:

```
2.3.1. Backend and Infrastructure 3
```

**Image**: *(has image_base64)*


---

### Block 21: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 26.001
- **bbox**: `BBox(x0=79, y0=504, x1=552, y1=517)`

**Content**:

```
2.3.2. Model-related 4
```

**Image**: *(has image_base64)*


---

### Block 22: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 33.0
- **bbox**: `BBox(x0=79, y0=519, x1=547, y1=532)`

**Content**:

```
2.3.3. Other model-related 错误！未定义书签。
```

**Image**: *(has image_base64)*


---

### Block 23: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 33.001
- **bbox**: `BBox(x0=79, y0=535, x1=547, y1=548)`

**Content**:

```
2.3.4. Backend and Infrastructure 错误！未定义书签。
```

**Image**: *(has image_base64)*


---

### Block 24: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 33.002
- **bbox**: `BBox(x0=79, y0=550, x1=547, y1=563)`

**Content**:

```
2.3.5. Model-related 错误！未定义书签。
```

**Image**: *(has image_base64)*


---

### Block 25: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 33.003
- **bbox**: `BBox(x0=79, y0=565, x1=547, y1=578)`

**Content**:

```
2.3.6. Other model-related 错误！未定义书签。
```

**Image**: *(has image_base64)*


---

### Block 26: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 33.004
- **bbox**: `BBox(x0=79, y0=581, x1=547, y1=594)`

**Content**:

```
2.3.7. RAG: Retrieval Augmented GenerationOther model-related 错误！未定义书签。
```

**Image**: *(has image_base64)*


---

### Block 27: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 33.005
- **bbox**: `BBox(x0=79, y0=597, x1=547, y1=610)`

**Content**:

```
2.3.8. Other model-related 错误！未定义书签。
```

**Image**: *(has image_base64)*


---

### Block 28: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 34.0
- **bbox**: `BBox(x0=36, y0=613, x1=552, y1=625)`
- **标题级别**: 1

**Content**:

```
3. Core functional modules 4

```

**Image**: *(has image_base64)*


---

### Block 29: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 35.0
- **bbox**: `BBox(x0=58, y0=629, x1=553, y1=657)`

**Content**:

```
3.1. All documents generated by function departments should be named according to the below-mentioned categories of documents. 4

```

**Image**: *(has image_base64)*


---

### Block 30: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 39.0
- **bbox**: `BBox(x0=79, y0=660, x1=552, y1=672)`

**Content**:

```
3.1.1. Data Source 4
```

**Image**: *(has image_base64)*


---

### Block 31: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 39.001
- **bbox**: `BBox(x0=79, y0=675, x1=552, y1=688)`

**Content**:

```
3.1.2. All documents generated by function de 4
```

**Image**: *(has image_base64)*


---

### Block 32: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 39.002
- **bbox**: `BBox(x0=79, y0=690, x1=552, y1=703)`

**Content**:

```
3.1.3. 数据处理模块包括以下流程
```

**Image**: *(has image_base64)*


---

### Block 33: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 40.0
- **bbox**: `BBox(x0=58, y0=706, x1=552, y1=719)`
- **标题级别**: 2

**Content**:

```
3.2. 模型服务模块 4

```

**Image**: *(has image_base64)*


---

### Block 34: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 41.0
- **bbox**: `BBox(x0=79, y0=722, x1=553, y1=735)`

**Content**:

```
3.2.1. 推理服务 ..... 4

```

**Image**: *(has image_base64)*


---

### Block 35: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 0.0
- **bbox**: `BBox(x0=77, y0=142, x1=554, y1=156)`

**Content**:

```
3.2.2. 模型更新策略 4

```

**Image**: *(has image_base64)*


---

### Block 36: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 4.0
- **bbox**: `BBox(x0=57, y0=158, x1=553, y1=171)`

**Content**:

```
3.3.应用层模块 5
```

**Image**: *(has image_base64)*


---

### Block 37: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 4.001
- **bbox**: `BBox(x0=78, y0=173, x1=553, y1=186)`

**Content**:

```
3.3.1.典型应用场景 5
```

**Image**: *(has image_base64)*


---

### Block 38: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 4.002
- **bbox**: `BBox(x0=78, y0=189, x1=547, y1=202)`

**Content**:

```
3.3.2. 权限与安全 错误！未定义书签。
```

**Image**: *(has image_base64)*


---

### Block 39: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 5.0
- **bbox**: `BBox(x0=35, y0=205, x1=550, y1=218)`

**Content**:

```
4. 4. Implementation plan and milestones 错误！未定义书签。

```

**Image**: *(has image_base64)*


---

### Block 40: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 9.0
- **bbox**: `BBox(x0=57, y0=221, x1=553, y1=233)`

**Content**:

```
4.1. Categories and hierarchy of documents 5
```

**Image**: *(has image_base64)*


---

### Block 41: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 9.001
- **bbox**: `BBox(x0=57, y0=236, x1=553, y1=249)`

**Content**:

```
4.2. 实施阶段划分 5
```

**Image**: *(has image_base64)*


---

### Block 42: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 9.002
- **bbox**: `BBox(x0=57, y0=251, x1=547, y1=265)`

**Content**:

```
4.3. 风险与应对 ………………………………………… 错误！未定义书签。
```

**Image**: *(has image_base64)*


---

### Block 43: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 12.0
- **bbox**: `BBox(x0=78, y0=267, x1=547, y1=280)`

**Content**:

```
4.3.1. 技术风险 错误！未定义书签。
```

**Image**: *(has image_base64)*


---

### Block 44: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 12.001
- **bbox**: `BBox(x0=78, y0=282, x1=547, y1=296)`

**Content**:

```
4.3.2. 业务风险 错误！未定义书签。
```

**Image**: *(has image_base64)*


---

### Block 45: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 13.0
- **bbox**: `BBox(x0=36, y0=299, x1=553, y1=312)`

**Content**:

```
5. Attachment 5

```

**Image**: *(has image_base64)*


---

### Block 46: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 24.0
- **bbox**: `BBox(x0=57, y0=314, x1=553, y1=327)`

**Content**:

```
5.1. Attachment1: Formate for xxxx1 5
```

**Image**: *(has image_base64)*


---

### Block 47: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 24.001
- **bbox**: `BBox(x0=57, y0=329, x1=553, y1=343)`

**Content**:

```
5.2. Attachment1: Formate for xxxxxx2 5
```

**Image**: *(has image_base64)*


---

### Block 48: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 24.002
- **bbox**: `BBox(x0=57, y0=345, x1=553, y1=358)`

**Content**:

```
5.3. Attachment1: Formate for xxxx3 5
```

**Image**: *(has image_base64)*


---

### Block 49: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 24.003
- **bbox**: `BBox(x0=57, y0=360, x1=547, y1=374)`

**Content**:

```
5.4. Attachment1: Formate for xxxx4 错误！未定义书签。
```

**Image**: *(has image_base64)*


---

### Block 50: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 24.004
- **bbox**: `BBox(x0=57, y0=376, x1=547, y1=390)`

**Content**:

```
5.5. Attachment1: Formate for xxxx5 错误！未定义书签。
```

**Image**: *(has image_base64)*


---

### Block 51: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 24.005
- **bbox**: `BBox(x0=57, y0=392, x1=547, y1=405)`

**Content**:

```
5.6. Attachment1: Formate for xxxx6 错误！未定义书签。
```

**Image**: *(has image_base64)*


---

### Block 52: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 24.006
- **bbox**: `BBox(x0=57, y0=407, x1=547, y1=421)`

**Content**:

```
5.7. Attachment1: Formate for xxxxx7 错误！未定义书签。
```

**Image**: *(has image_base64)*


---

### Block 53: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 24.007
- **bbox**: `BBox(x0=57, y0=423, x1=547, y1=437)`

**Content**:

```
5.8. Attachment1: Formate for xxxxx8 错误！未定义书签。
```

**Image**: *(has image_base64)*


---

### Block 54: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 24.008
- **bbox**: `BBox(x0=57, y0=439, x1=547, y1=452)`

**Content**:

```
5.9. Attachment1: Formate for xxxxxx9 错误！未定义书签。
```

**Image**: *(has image_base64)*


---

### Block 55: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 24.009
- **bbox**: `BBox(x0=57, y0=454, x1=547, y1=467)`

**Content**:

```
5.10. Attachment1: Formate for xxxx10 错误！未定义书签。
```

**Image**: *(has image_base64)*


---

### Block 56: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 25.0
- **bbox**: `BBox(x0=36, y0=470, x1=553, y1=483)`

**Content**:

```
6. 总结与展望 ..... 5

```

**Image**: *(has image_base64)*


---

### Block 57: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 3
- **索引**: 0.0
- **bbox**: `BBox(x0=35, y0=142, x1=169, y1=156)`
- **标题级别**: 1

**Content**:

```
1. Overall scheme design

```

**Image**: *(has image_base64)*


---

### Block 58: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 3
- **索引**: 1.0
- **bbox**: `BBox(x0=55, y0=156, x1=238, y1=169)`
- **标题级别**: 2

**Content**:

```
1.1. Overview of system architecture

```

**Image**: *(has image_base64)*


---

### Block 59: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 2.0
- **bbox**: `BBox(x0=76, y0=170, x1=554, y1=215)`

**Content**:

```
The system is designed with a layered architecture, encompassing a data layer, a model layer, and an application layer. This design ensures the independence between modules and facilitates the addition of new functional modules in the future.

```

**Image**: *(has image_base64)*


---

### Block 60: image

- **类型**: `image`
- **源类型**: `image`
- **页码**: 3
- **索引**: 3.0
- **bbox**: `BBox(x0=81, y0=217, x1=509, y1=444)`

**Content**:

*(empty)*

**Image**: *(has image_base64)*


---

### Block 61: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 3
- **索引**: 4.0
- **bbox**: `BBox(x0=55, y0=449, x1=154, y1=464)`
- **标题级别**: 2

**Content**:

```
1.2. 技术选型说明

```

**Image**: *(has image_base64)*


---

### Block 62: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 3
- **索引**: 5.0
- **bbox**: `BBox(x0=76, y0=465, x1=198, y1=479)`
- **标题级别**: 3

**Content**:

```
1.2.1. 后端与基础设施

```

**Image**: *(has image_base64)*


---

### Block 63: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 10.0
- **bbox**: `BBox(x0=116, y0=481, x1=232, y1=496)`

**Content**:

```
编程语言：Python
```

**Image**: *(has image_base64)*


---

### Block 64: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 10.001
- **bbox**: `BBox(x0=116, y0=497, x1=237, y1=510)`

**Content**:

```
- 服务框架：FastAPI
```

**Image**: *(has image_base64)*


---

### Block 65: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 10.002
- **bbox**: `BBox(x0=116, y0=513, x1=267, y1=526)`

**Content**:

```
- 模型部署：vLLM/Triton
```

**Image**: *(has image_base64)*


---

### Block 66: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 10.003
- **bbox**: `BBox(x0=116, y0=528, x1=312, y1=541)`

**Content**:

```
- 容器与编排：Docker + Kubernetes
```

**Image**: *(has image_base64)*


---

### Block 67: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 3
- **索引**: 11.0
- **bbox**: `BBox(x0=76, y0=544, x1=162, y1=557)`
- **标题级别**: 3

**Content**:

```
1.2.2. 模型相关

```

**Image**: *(has image_base64)*


---

### Block 68: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 15.0
- **bbox**: `BBox(x0=116, y0=559, x1=240, y1=572)`

**Content**:

```
- 大语言模型（LLM）
```

**Image**: *(has image_base64)*


---

### Block 69: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 15.001
- **bbox**: `BBox(x0=116, y0=574, x1=258, y1=589)`

**Content**:

```
向量模型（Embedding）
```

**Image**: *(has image_base64)*


---

### Block 70: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 15.002
- **bbox**: `BBox(x0=116, y0=591, x1=240, y1=603)`

**Content**:

```
- RAG 检索增强生成
```

**Image**: *(has image_base64)*


---

### Block 71: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 3
- **索引**: 16.0
- **bbox**: `BBox(x0=76, y0=605, x1=186, y1=619)`
- **标题级别**: 3

**Content**:

```
1.2.3. 其他模型相关

```

**Image**: *(has image_base64)*


---

### Block 72: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 20.0
- **bbox**: `BBox(x0=116, y0=621, x1=242, y1=634)`

**Content**:

```
- 视觉大模型（VLM）
```

**Image**: *(has image_base64)*


---

### Block 73: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 20.001
- **bbox**: `BBox(x0=116, y0=637, x1=258, y1=651)`

**Content**:

```
向量模型（Embedding）
```

**Image**: *(has image_base64)*


---

### Block 74: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 20.002
- **bbox**: `BBox(x0=116, y0=653, x1=240, y1=666)`

**Content**:

```
- RAG 检索增强生成
```

**Image**: *(has image_base64)*


---

### Block 75: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 3
- **索引**: 21.0
- **bbox**: `BBox(x0=55, y0=668, x1=229, y1=682)`
- **标题级别**: 2

**Content**:

```
1.3. Technical selection description

```

**Image**: *(has image_base64)*


---

### Block 76: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 3
- **索引**: 22.0
- **bbox**: `BBox(x0=76, y0=682, x1=244, y1=694)`
- **标题级别**: 3

**Content**:

```
1.3.1. Backend and Infrastructure

```

**Image**: *(has image_base64)*


---

### Block 77: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 26.0
- **bbox**: `BBox(x0=116, y0=697, x1=290, y1=711)`

**Content**:

```
- Programming language: Python
```

**Image**: *(has image_base64)*


---

### Block 78: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 26.001
- **bbox**: `BBox(x0=116, y0=713, x1=274, y1=724)`

**Content**:

```
Service framework: FastAPI
```

**Image**: *(has image_base64)*


---

### Block 79: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 26.002
- **bbox**: `BBox(x0=116, y0=728, x1=304, y1=742)`

**Content**:

```
- Model deployment: vLLM / Triton
```

**Image**: *(has image_base64)*


---

### Block 80: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 4
- **索引**: 0.0
- **bbox**: `BBox(x0=115, y0=142, x1=384, y1=155)`

**Content**:

```
- Containers and orchestration: Docker + Kubernetes

```

**Image**: *(has image_base64)*


---

### Block 81: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 4
- **索引**: 1.0
- **bbox**: `BBox(x0=76, y0=158, x1=183, y1=169)`

**Content**:

```
1.3.2. Model-related

```

**Image**: *(has image_base64)*


---

### Block 82: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 4
- **索引**: 7.0
- **bbox**: `BBox(x0=116, y0=173, x1=286, y1=186)`

**Content**:

```
Large Language Model (LLM)
```

**Image**: *(has image_base64)*


---

### Block 83: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 4
- **索引**: 7.001
- **bbox**: `BBox(x0=116, y0=188, x1=268, y1=201)`

**Content**:

```
- Vector model (Embedding)
```

**Image**: *(has image_base64)*


---

### Block 84: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 4
- **索引**: 7.002
- **bbox**: `BBox(x0=116, y0=205, x1=268, y1=218)`

**Content**:

```
- Vector model (Embedding)
```

**Image**: *(has image_base64)*


---

### Block 85: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 4
- **索引**: 7.003
- **bbox**: `BBox(x0=116, y0=220, x1=327, y1=233)`

**Content**:

```
RAG: Retrieval Augmented Generation
```

**Image**: *(has image_base64)*


---

### Block 86: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 4
- **索引**: 7.004
- **bbox**: `BBox(x0=116, y0=235, x1=274, y1=248)`

**Content**:

```
Service framework: FastAPI
```

**Image**: *(has image_base64)*


---

### Block 87: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 4
- **索引**: 8.0
- **bbox**: `BBox(x0=34, y0=266, x1=178, y1=279)`

**Content**:

```
2. Core functional modules

```

**Image**: *(has image_base64)*


---

### Block 88: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 4
- **索引**: 9.0
- **bbox**: `BBox(x0=54, y0=281, x1=553, y1=312)`

**Content**:

```
2.1. All documents generated by function departments should be named according to the below-mentioned categories of documents.

```

**Image**: *(has image_base64)*


---

### Block 89: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 4
- **索引**: 10.0
- **bbox**: `BBox(x0=74, y0=313, x1=173, y1=325)`

**Content**:

```
2.1.1. Data Source

```

**Image**: *(has image_base64)*


---

### Block 90: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 4
- **索引**: 11.0
- **bbox**: `BBox(x0=104, y0=327, x1=280, y1=342)`

**Content**:

```
A. Equipment pperation instruction

```

**Image**: *(has image_base64)*


---

### Block 91: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 4
- **索引**: 12.0
- **bbox**: `BBox(x0=213, y0=349, x1=402, y1=367)`

**Content**:

```
TABLE_placeHOLDER_001
```

**Image**: *(no image)*


---

### Block 92: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 4
- **索引**: 13.0
- **bbox**: `BBox(x0=104, y0=427, x1=207, y1=439)`

**Content**:

```
B. Other documents

```

**Image**: *(has image_base64)*


---

### Block 93: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 4
- **索引**: 14.0
- **bbox**: `BBox(x0=213, y0=449, x1=403, y1=466)`

**Content**:

```
TABLE_placeHOLDER_002
```

**Image**: *(no image)*


---

### Block 94: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 4
- **索引**: 15.0
- **bbox**: `BBox(x0=74, y0=525, x1=305, y1=539)`

**Content**:

```
2.1.2. All documents generated by function de

```

**Image**: *(has image_base64)*


---

### Block 95: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 4
- **索引**: 16.0
- **bbox**: `BBox(x0=74, y0=539, x1=258, y1=552)`

**Content**:

```
2.1.3. 数据处理模块包括以下流程

```

**Image**: *(has image_base64)*


---

### Block 96: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 4
- **索引**: 20.0
- **bbox**: `BBox(x0=97, y0=555, x1=303, y1=569)`

**Content**:

```
- 清洗无效数据，去除空值与重复数据
```

**Image**: *(has image_base64)*


---

### Block 97: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 4
- **索引**: 20.001
- **bbox**: `BBox(x0=98, y0=571, x1=249, y1=585)`

**Content**:

```
- 结构化与切分（Chunking）
```

**Image**: *(has image_base64)*


---

### Block 98: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 4
- **索引**: 20.002
- **bbox**: `BBox(x0=97, y0=586, x1=327, y1=600)`

**Content**:

```
- 向量化与索引构建，用于快速检索和匹配
```

**Image**: *(has image_base64)*


---

### Block 99: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 4
- **索引**: 21.0
- **bbox**: `BBox(x0=54, y0=602, x1=153, y1=614)`

**Content**:

```
2.2. 模型服务模块

```

**Image**: *(has image_base64)*


---

### Block 100: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 4
- **索引**: 22.0
- **bbox**: `BBox(x0=74, y0=618, x1=161, y1=630)`

**Content**:

```
2.2.1. 推理服务

```

**Image**: *(has image_base64)*


---

### Block 101: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 4
- **索引**: 23.0
- **bbox**: `BBox(x0=97, y0=632, x1=553, y1=661)`

**Content**:

```
模型通过统一的API服务对外提供能力，支持高并发和流式输出，以满足业务实时性要求。

```

**Image**: *(has image_base64)*


---

### Block 102: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 4
- **索引**: 24.0
- **bbox**: `BBox(x0=74, y0=664, x1=185, y1=677)`

**Content**:

```
2.2.2. 模型更新策略

```

**Image**: *(has image_base64)*


---

### Block 103: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 4
- **索引**: 27.0
- **bbox**: `BBox(x0=116, y0=681, x1=305, y1=695)`

**Content**:

```
- 支持模型热更新，避免服务中断
```

**Image**: *(has image_base64)*


---

### Block 104: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 4
- **索引**: 27.001
- **bbox**: `BBox(x0=116, y0=698, x1=371, y1=713)`

**Content**:

```
- 支持多版本并行部署，便于 A/B 测试和回滚
```

**Image**: *(has image_base64)*


---

### Block 105: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 5
- **索引**: 0.0
- **bbox**: `BBox(x0=54, y0=142, x1=140, y1=155)`
- **标题级别**: 2

**Content**:

```
2.3. 应用层模块

```

**Image**: *(has image_base64)*


---

### Block 106: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 5
- **索引**: 1.0
- **bbox**: `BBox(x0=74, y0=158, x1=185, y1=171)`
- **标题级别**: 3

**Content**:

```
2.3.1．典型应用场景

```

**Image**: *(has image_base64)*


---

### Block 107: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 4.0
- **bbox**: `BBox(x0=116, y0=174, x1=209, y1=188)`

**Content**:

```
智能问答助手
```

**Image**: *(has image_base64)*


---

### Block 108: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 4.001
- **bbox**: `BBox(x0=116, y0=192, x1=221, y1=206)`

**Content**:

```
文档检索与总结
```

**Image**: *(has image_base64)*


---

### Block 109: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 5
- **索引**: 5.0
- **bbox**: `BBox(x0=54, y0=210, x1=268, y1=223)`
- **标题级别**: 2

**Content**:

```
2.4. Categories and hierarchy of documents

```

**Image**: *(has image_base64)*


---

### Block 110: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 5
- **索引**: 6.0
- **bbox**: `BBox(x0=174, y0=231, x1=364, y1=248)`

**Content**:

```
TABLE_placeHOLDER_003
```

**Image**: *(no image)*


---

### Block 111: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 5
- **索引**: 7.0
- **bbox**: `BBox(x0=54, y0=412, x1=152, y1=428)`
- **标题级别**: 2

**Content**:

```
2.5. 实施阶段划分

```

**Image**: *(has image_base64)*


---

### Block 112: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 5
- **索引**: 8.0
- **bbox**: `BBox(x0=174, y0=437, x1=364, y1=454)`

**Content**:

```
TABLE_placeHOLDER_004
```

**Image**: *(no image)*


---

### Block 113: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 5
- **索引**: 9.0
- **bbox**: `BBox(x0=35, y0=604, x1=116, y1=617)`
- **标题级别**: 1

**Content**:

```
3. Attachment

```

**Image**: *(has image_base64)*


---

### Block 114: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 13.0
- **bbox**: `BBox(x0=54, y0=618, x1=246, y1=631)`

**Content**:

```
3.1. Attachment1: Formate for xxxxxx1
```

**Image**: *(has image_base64)*


---

### Block 115: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 13.001
- **bbox**: `BBox(x0=54, y0=634, x1=246, y1=647)`

**Content**:

```
3.2. Attachment1: Formate for xxxxxx2
```

**Image**: *(has image_base64)*


---

### Block 116: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 13.002
- **bbox**: `BBox(x0=54, y0=650, x1=246, y1=663)`

**Content**:

```
3.3. Attachment1: Formate for xxxxxx3
```

**Image**: *(has image_base64)*


---

### Block 117: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 5
- **索引**: 14.0
- **bbox**: `BBox(x0=35, y0=682, x1=120, y1=695)`
- **标题级别**: 1

**Content**:

```
4. 总结与展望

```

**Image**: *(has image_base64)*


---

### Block 118: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 5
- **索引**: 15.0
- **bbox**: `BBox(x0=54, y0=698, x1=205, y1=713)`
- **标题级别**: 2

**Content**:

```
4.1. Effective period of TECN

```

**Image**: *(has image_base64)*


---

### Block 119: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 5
- **索引**: 16.0
- **bbox**: `BBox(x0=54, y0=722, x1=553, y1=737)`

**Content**:

```
SMIC document security levels are categorized accounting to the security control level's defined in

```

**Image**: *(has image_base64)*


---

### Block 120: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 6
- **索引**: 0.0
- **bbox**: `BBox(x0=56, y0=142, x1=485, y1=157)`

**Content**:

```
"CR-GWNL-01-1001 SMIC Classified Information Protection Policy (CIPP)"as follows

```

**Image**: *(has image_base64)*


---

### Block 121: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 6
- **索引**: 1.0
- **bbox**: `BBox(x0=222, y0=167, x1=372, y1=181)`

**Content**:

```
Security B-SMIC Confidential

```

**Image**: *(has image_base64)*


---

### Block 122: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 6
- **索引**: 2.0
- **bbox**: `BBox(x0=224, y0=191, x1=364, y1=206)`

**Content**:

```
Security C-SMIC Restricted

```

**Image**: *(has image_base64)*


---

### Block 123: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 6
- **索引**: 3.0
- **bbox**: `BBox(x0=54, y0=216, x1=205, y1=230)`

**Content**:

```
4.2. Effective period of TECN

```

**Image**: *(has image_base64)*


---

### Block 124: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 6
- **索引**: 8.0
- **bbox**: `BBox(x0=75, y0=232, x1=376, y1=246)`

**Content**:

```
A. Document format should follow the requirements sign-off
```

**Image**: *(has image_base64)*


---

### Block 125: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 6
- **索引**: 8.001
- **bbox**: `BBox(x0=75, y0=248, x1=390, y1=261)`

**Content**:

```
B. Document sign-off should follow the requirements in item 20
```

**Image**: *(has image_base64)*


---

### Block 126: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 6
- **索引**: 8.002
- **bbox**: `BBox(x0=75, y0=263, x1=438, y1=277)`

**Content**:

```
C. Document access authority should follow the requirements in item 18.2
```

**Image**: *(has image_base64)*


---

### Block 127: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 6
- **索引**: 8.003
- **bbox**: `BBox(x0=75, y0=279, x1=430, y1=293)`

**Content**:

```
D. Document effectiveness cycle time should be within 14 working days
```

**Image**: *(has image_base64)*


---

### Block 128: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 6
- **索引**: 9.0
- **bbox**: `BBox(x0=54, y0=295, x1=553, y1=340)`

**Content**:

```
4.3. All documents generated by function departments should be named according to the below-mentioned categories of documents for example,"SMIC Document Control Procedure" Document title naming rules are follows:

```

**Image**: *(has image_base64)*


---

### Block 129: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 6
- **索引**: 10.0
- **bbox**: `BBox(x0=74, y0=342, x1=191, y1=354)`

**Content**:

```
4.3.1. FAB documents

```

**Image**: *(has image_base64)*


---

### Block 130: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 6
- **索引**: 11.0
- **bbox**: `BBox(x0=98, y0=357, x1=277, y1=370)`

**Content**:

```
A. Equipment operation instruction

```

**Image**: *(has image_base64)*


---

### Block 131: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 6
- **索引**: 12.0
- **bbox**: `BBox(x0=203, y0=379, x1=393, y1=396)`

**Content**:

```
TABLE_placeHOLDER_005
```

**Image**: *(no image)*


---

### Block 132: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 6
- **索引**: 13.0
- **bbox**: `BBox(x0=98, y0=498, x1=204, y1=510)`

**Content**:

```
B. Other documents

```

**Image**: *(has image_base64)*


---

### Block 133: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 6
- **索引**: 14.0
- **bbox**: `BBox(x0=203, y0=520, x1=393, y1=536)`

**Content**:

```
TABLE_placeHOLDER_006
```

**Image**: *(no image)*


---

### Block 134: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 6
- **索引**: 15.0
- **bbox**: `BBox(x0=74, y0=671, x1=244, y1=684)`

**Content**:

```
4.3.2. Non-FAB documents/DCN

```

**Image**: *(has image_base64)*


---

### Block 135: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 6
- **索引**: 16.0
- **bbox**: `BBox(x0=95, y0=687, x1=298, y1=701)`

**Content**:

```
(E.g. Mask Operation, RE lab, Facility, etc)

```

**Image**: *(has image_base64)*


---

### Block 136: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 6
- **索引**: 17.0
- **bbox**: `BBox(x0=204, y0=709, x1=394, y1=725)`

**Content**:

```
TABLE_placeHOLDER_007
```

**Image**: *(no image)*


---

### Block 137: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 7
- **索引**: 0.0
- **bbox**: `BBox(x0=204, y0=149, x1=395, y1=165)`

**Content**:

```
TABLE_placeHOLDER_008
```

**Image**: *(no image)*


---

### Block 138: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 7
- **索引**: 1.0
- **bbox**: `BBox(x0=74, y0=253, x1=529, y1=301)`

**Content**:

```
4.3.3. Technology development related documents naming rule is defined in "TD-GENL-01-2047 SMIC Design Rules Template" and "TD-GENL-01-2064 SMIC PDK Document Title and Attached File Naming Rule"

```

**Image**: *(has image_base64)*


---
