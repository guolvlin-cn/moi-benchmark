# MinerU Parser Debug Output

**生成时间**: 2026-07-29T13:24:06.458672

**Block 总数**: 7


---

## 类型统计

| 类型 | 数量 |
|------|------|
| text | 5 |
| title | 2 |

---

## Block 详情

### Block 0: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 0.0
- **bbox**: `BBox(x0=251, y0=74, x1=343, y1=100)`
- **标题级别**: 1

**Content**:

```
检测结果

```

**Image**: *(has image_base64)*


---

### Block 1: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 1.0
- **bbox**: `BBox(x0=88, y0=104, x1=158, y1=118)`
- **标题级别**: 1

**Content**:

```
一、工业废气

```

**Image**: *(has image_base64)*


---

### Block 2: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 1
- **索引**: 2.0
- **bbox**: `BBox(x0=201, y0=126, x1=390, y1=142)`

**Content**:

```
TABLE_placeHOLDER_001
```

**Image**: *(no image)*


---

### Block 3: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 2
- **索引**: 0.0
- **bbox**: `BBox(x0=201, y0=79, x1=391, y1=95)`

**Content**:

```
TABLE_placeHOLDER_002
```

**Image**: *(no image)*


---

### Block 4: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 1.0
- **bbox**: `BBox(x0=88, y0=268, x1=301, y1=280)`

**Content**:

```
备注：“Qsn 表示标干流量；H 表示排气筒高度。

```

**Image**: *(has image_base64)*


---

### Block 5: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 2.0
- **bbox**: `BBox(x0=91, y0=284, x1=237, y1=296)`

**Content**:

```
“ND”表示检测结果低于检出限。

```

**Image**: *(has image_base64)*


---

### Block 6: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 3.0
- **bbox**: `BBox(x0=91, y0=299, x1=338, y1=312)`

**Content**:

```
“/”表示样品的排放浓度未检出时，排放速率无须计算。

```

**Image**: *(has image_base64)*


---
