# MinerU Parser Debug Output

**生成时间**: 2026-07-29T18:17:17.427688

**Block 总数**: 202


---

## 类型统计

| 类型 | 数量 |
|------|------|
| header | 1 |
| image | 1 |
| list | 126 |
| text | 37 |
| title | 37 |

---

## Block 详情

### Block 0: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 0.0
- **bbox**: `BBox(x0=176, y0=126, x1=411, y1=152)`
- **标题级别**: 1

**Content**:

```
AI 应用落地方案说明书

```

**Image**: *(has image_base64)*


---

### Block 1: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 1.0
- **bbox**: `BBox(x0=36, y0=180, x1=555, y1=195)`

**Content**:

```
1. Project background and objectives 3

```

**Image**: *(has image_base64)*


---

### Block 2: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 6.0
- **bbox**: `BBox(x0=58, y0=196, x1=553, y1=209)`

**Content**:

```
1.1.DCC:Document Control Center 3
```

**Image**: *(has image_base64)*


---

### Block 3: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 6.001
- **bbox**: `BBox(x0=58, y0=211, x1=553, y1=226)`

**Content**:

```
1.2. DCN: Document Change Notice(for Company Rules and Regulations) 3
```

**Image**: *(has image_base64)*


---

### Block 4: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 6.002
- **bbox**: `BBox(x0=58, y0=227, x1=553, y1=241)`

**Content**:

```
1.3.DMS:Document Management System 3
```

**Image**: *(has image_base64)*


---

### Block 5: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 6.003
- **bbox**: `BBox(x0=58, y0=243, x1=553, y1=256)`

**Content**:

```
1.4. Background description 3
```

**Image**: *(has image_base64)*


---

### Block 6: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 13.0
- **bbox**: `BBox(x0=79, y0=259, x1=553, y1=271)`

**Content**:

```
1.4.1. Industry prospects 3
```

**Image**: *(has image_base64)*


---

### Block 7: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 13.001
- **bbox**: `BBox(x0=79, y0=274, x1=553, y1=287)`

**Content**:

```
1.4.2. Industry prospects2 3
```

**Image**: *(has image_base64)*


---

### Block 8: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 13.002
- **bbox**: `BBox(x0=79, y0=290, x1=553, y1=302)`

**Content**:

```
1.4.3. Industry prospects3 3
```

**Image**: *(has image_base64)*


---

### Block 9: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 13.003
- **bbox**: `BBox(x0=79, y0=306, x1=553, y1=318)`

**Content**:

```
1.4.4. Industry prospects4 3
```

**Image**: *(has image_base64)*


---

### Block 10: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 13.004
- **bbox**: `BBox(x0=79, y0=321, x1=553, y1=333)`

**Content**:

```
1.4.5. Industry prospects 3
```

**Image**: *(has image_base64)*


---

### Block 11: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 13.005
- **bbox**: `BBox(x0=79, y0=337, x1=553, y1=349)`

**Content**:

```
1.4.6. Main pain points 3
```

**Image**: *(has image_base64)*


---

### Block 12: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 14.0
- **bbox**: `BBox(x0=58, y0=353, x1=553, y1=365)`

**Content**:

```
1.5. Construction objectives 3

```

**Image**: *(has image_base64)*


---

### Block 13: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 15.0
- **bbox**: `BBox(x0=36, y0=368, x1=553, y1=380)`

**Content**:

```
2. Overall scheme design 4

```

**Image**: *(has image_base64)*


---

### Block 14: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 18.0
- **bbox**: `BBox(x0=58, y0=383, x1=553, y1=396)`

**Content**:

```
2.1. Overview of system architecture 4
```

**Image**: *(has image_base64)*


---

### Block 15: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 18.001
- **bbox**: `BBox(x0=58, y0=398, x1=553, y1=411)`

**Content**:

```
2.2. 技术选型说明 4
```

**Image**: *(has image_base64)*


---

### Block 16: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 22.0
- **bbox**: `BBox(x0=79, y0=414, x1=553, y1=427)`

**Content**:

```
2.2.1.后端与基础设施 4
```

**Image**: *(has image_base64)*


---

### Block 17: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 22.001
- **bbox**: `BBox(x0=79, y0=429, x1=553, y1=442)`

**Content**:

```
2.2.2.模型相关 4
```

**Image**: *(has image_base64)*


---

### Block 18: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 22.002
- **bbox**: `BBox(x0=79, y0=445, x1=553, y1=458)`

**Content**:

```
2.2.3. 其他模型相关
```

**Image**: *(has image_base64)*


---

### Block 19: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 23.0
- **bbox**: `BBox(x0=58, y0=461, x1=553, y1=474)`

**Content**:

```
2.3. Technical selection description 4

```

**Image**: *(has image_base64)*


---

### Block 20: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 32.0
- **bbox**: `BBox(x0=79, y0=476, x1=553, y1=489)`

**Content**:

```
2.3.1. Bootstrap and Infrastructure 4
```

**Image**: *(has image_base64)*


---

### Block 21: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 32.001
- **bbox**: `BBox(x0=79, y0=492, x1=553, y1=505)`

**Content**:

```
2.3.2.Model-related 5
```

**Image**: *(has image_base64)*


---

### Block 22: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 32.002
- **bbox**: `BBox(x0=79, y0=507, x1=553, y1=520)`

**Content**:

```
2.3.3. Other model-related 5
```

**Image**: *(has image_base64)*


---

### Block 23: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 32.003
- **bbox**: `BBox(x0=79, y0=523, x1=553, y1=535)`

**Content**:

```
2.3.4. Bootstrap and Infrastructure 5
```

**Image**: *(has image_base64)*


---

### Block 24: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 32.004
- **bbox**: `BBox(x0=79, y0=539, x1=553, y1=551)`

**Content**:

```
2.3.5. Model-related 5
```

**Image**: *(has image_base64)*


---

### Block 25: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 32.005
- **bbox**: `BBox(x0=79, y0=555, x1=553, y1=567)`

**Content**:

```
2.3.6. Other model-related 5
```

**Image**: *(has image_base64)*


---

### Block 26: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 32.006
- **bbox**: `BBox(x0=79, y0=571, x1=553, y1=582)`

**Content**:

```
2.3.7. RAG: Retrieval Augmented GenerationOther model-related 5
```

**Image**: *(has image_base64)*


---

### Block 27: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 32.007
- **bbox**: `BBox(x0=79, y0=586, x1=553, y1=597)`

**Content**:

```
2.3.8. Other model-related 5
```

**Image**: *(has image_base64)*


---

### Block 28: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 33.0
- **bbox**: `BBox(x0=36, y0=602, x1=553, y1=613)`

**Content**:

```
3. Core functional modules 5

```

**Image**: *(has image_base64)*


---

### Block 29: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 34.0
- **bbox**: `BBox(x0=58, y0=617, x1=553, y1=645)`

**Content**:

```
3.1. All documents generated by function departments should be named according to the below-mentioned categories of documents. 5

```

**Image**: *(has image_base64)*


---

### Block 30: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 38.0
- **bbox**: `BBox(x0=79, y0=648, x1=553, y1=661)`

**Content**:

```
3.1.1.Data Source 5
```

**Image**: *(has image_base64)*


---

### Block 31: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 38.001
- **bbox**: `BBox(x0=79, y0=664, x1=553, y1=676)`

**Content**:

```
3.1.2. All documents generated by function de 6
```

**Image**: *(has image_base64)*


---

### Block 32: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 38.002
- **bbox**: `BBox(x0=79, y0=679, x1=553, y1=692)`

**Content**:

```
3.1.3. 数据处理模块包括以下流程 6
```

**Image**: *(has image_base64)*


---

### Block 33: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 39.0
- **bbox**: `BBox(x0=58, y0=695, x1=553, y1=708)`

**Content**:

```
3.2. 模型服务模块 6

```

**Image**: *(has image_base64)*


---

### Block 34: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 42.0
- **bbox**: `BBox(x0=79, y0=710, x1=553, y1=723)`

**Content**:

```
3.2.1.推理服务 6
```

**Image**: *(has image_base64)*


---

### Block 35: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 42.001
- **bbox**: `BBox(x0=79, y0=726, x1=553, y1=738)`

**Content**:

```
3.2.2. 模型更新策略 6
```

**Image**: *(has image_base64)*


---

### Block 36: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 0.0
- **bbox**: `BBox(x0=57, y0=116, x1=553, y1=128)`

**Content**:

```
3.3.应用层模块 6

```

**Image**: *(has image_base64)*


---

### Block 37: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 3.0
- **bbox**: `BBox(x0=77, y0=131, x1=553, y1=144)`

**Content**:

```
3.3.1.典型应用场景 6
```

**Image**: *(has image_base64)*


---

### Block 38: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 3.001
- **bbox**: `BBox(x0=78, y0=147, x1=553, y1=159)`

**Content**:

```
3.3.2. 权限与安全 6
```

**Image**: *(has image_base64)*


---

### Block 39: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 4.0
- **bbox**: `BBox(x0=35, y0=163, x1=553, y1=175)`

**Content**:

```
4. 4. Implementation plan and milestones 6

```

**Image**: *(has image_base64)*


---

### Block 40: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 8.0
- **bbox**: `BBox(x0=57, y0=178, x1=553, y1=190)`

**Content**:

```
4.1. Categories and hierarchy of documents 6
```

**Image**: *(has image_base64)*


---

### Block 41: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 8.001
- **bbox**: `BBox(x0=57, y0=193, x1=553, y1=206)`

**Content**:

```
4.2. 实施阶段划分
```

**Image**: *(has image_base64)*


---

### Block 42: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 8.002
- **bbox**: `BBox(x0=57, y0=209, x1=553, y1=222)`

**Content**:

```
4.3.风险与应对
```

**Image**: *(has image_base64)*


---

### Block 43: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 11.0
- **bbox**: `BBox(x0=77, y0=225, x1=553, y1=238)`

**Content**:

```
4.3.1. 技术风险
```

**Image**: *(has image_base64)*


---

### Block 44: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 11.001
- **bbox**: `BBox(x0=78, y0=240, x1=553, y1=253)`

**Content**:

```
4.3.2.业务风险
```

**Image**: *(has image_base64)*


---

### Block 45: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 12.0
- **bbox**: `BBox(x0=35, y0=257, x1=553, y1=269)`

**Content**:

```
5. Attachment 8

```

**Image**: *(has image_base64)*


---

### Block 46: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 23.0
- **bbox**: `BBox(x0=57, y0=272, x1=553, y1=285)`

**Content**:

```
5.1. Attachment1: Formate for xxxx1 8
```

**Image**: *(has image_base64)*


---

### Block 47: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 23.001
- **bbox**: `BBox(x0=57, y0=287, x1=553, y1=300)`

**Content**:

```
5.2. Attachment1: Formate for xxxx2 8
```

**Image**: *(has image_base64)*


---

### Block 48: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 23.002
- **bbox**: `BBox(x0=57, y0=303, x1=553, y1=315)`

**Content**:

```
5.3. Attachment1: Formate for xxxx3 8
```

**Image**: *(has image_base64)*


---

### Block 49: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 23.003
- **bbox**: `BBox(x0=57, y0=318, x1=553, y1=331)`

**Content**:

```
5.4. Attachment1: Formate for xxxx4 8
```

**Image**: *(has image_base64)*


---

### Block 50: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 23.004
- **bbox**: `BBox(x0=57, y0=334, x1=553, y1=347)`

**Content**:

```
5.5. Attachment1: Formate for xxxx5 8
```

**Image**: *(has image_base64)*


---

### Block 51: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 23.005
- **bbox**: `BBox(x0=57, y0=349, x1=553, y1=362)`

**Content**:

```
5.6. Attachment1: Formate for xxxx6 8
```

**Image**: *(has image_base64)*


---

### Block 52: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 23.006
- **bbox**: `BBox(x0=57, y0=365, x1=553, y1=378)`

**Content**:

```
5.7. Attachment1: Formate for xxxx7 8
```

**Image**: *(has image_base64)*


---

### Block 53: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 23.007
- **bbox**: `BBox(x0=57, y0=380, x1=553, y1=393)`

**Content**:

```
5.8. Attachment1: Formate for xxxxxx8 8
```

**Image**: *(has image_base64)*


---

### Block 54: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 23.008
- **bbox**: `BBox(x0=57, y0=396, x1=553, y1=409)`

**Content**:

```
5.9. Attachment1: Formate for xxxx9 8
```

**Image**: *(has image_base64)*


---

### Block 55: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 23.009
- **bbox**: `BBox(x0=57, y0=412, x1=553, y1=424)`

**Content**:

```
5.10. Attachment1: Formate for xxxx10 8
```

**Image**: *(has image_base64)*


---

### Block 56: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 24.0
- **bbox**: `BBox(x0=35, y0=428, x1=553, y1=440)`

**Content**:

```
6. 总结与展望 ..... 8

```

**Image**: *(has image_base64)*


---

### Block 57: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 3
- **索引**: 0.0
- **bbox**: `BBox(x0=38, y0=116, x1=307, y1=136)`
- **标题级别**: 1

**Content**:

```
1. Project background and objectives

```

**Image**: *(has image_base64)*


---

### Block 58: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 5.0
- **bbox**: `BBox(x0=55, y0=137, x1=283, y1=153)`

**Content**:

```
1.1.DCC: Document Control Center
```

**Image**: *(has image_base64)*


---

### Block 59: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 5.001
- **bbox**: `BBox(x0=55, y0=156, x1=510, y1=173)`

**Content**:

```
1.2.DCN: Document Change Notice (for Company Rules and Regulations)
```

**Image**: *(has image_base64)*


---

### Block 60: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 5.002
- **bbox**: `BBox(x0=55, y0=176, x1=320, y1=192)`

**Content**:

```
1.3.DMS: Document Management System
```

**Image**: *(has image_base64)*


---

### Block 61: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 5.003
- **bbox**: `BBox(x0=55, y0=195, x1=224, y1=211)`

**Content**:

```
1.4. Background description
```

**Image**: *(has image_base64)*


---

### Block 62: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 6.0
- **bbox**: `BBox(x0=75, y0=211, x1=554, y1=306)`

**Content**:

```
With the continuous evolution of artificial intelligence technology, large language models (LLM) and multimodal models have demonstrated remarkable capabilities in comprehension, generation, and reasoning. An increasing number of enterprises are beginning to experiment with integrating AI technology into their actual business processes, aiming to enhance information processing efficiency, optimize decision-making quality, and reduce reliance on human experience. Against this backdrop, the focus of AI application has gradually shifted from "model effect demonstration" to "systematic implementation capability". How to embed model capabilities into existing business systems is a stable and controllable manner has become a common concern for both technical and business teams.

```

**Image**: *(has image_base64)*


---

### Block 63: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 12.0
- **bbox**: `BBox(x0=77, y0=308, x1=229, y1=324)`

**Content**:

```
1.4.1. Industry prospects 1
```

**Image**: *(has image_base64)*


---

### Block 64: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 12.001
- **bbox**: `BBox(x0=77, y0=326, x1=230, y1=341)`

**Content**:

```
1.4.2. Industry prospects2
```

**Image**: *(has image_base64)*


---

### Block 65: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 12.002
- **bbox**: `BBox(x0=77, y0=343, x1=230, y1=359)`

**Content**:

```
1.4.3. Industry prospects3
```

**Image**: *(has image_base64)*


---

### Block 66: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 12.003
- **bbox**: `BBox(x0=77, y0=360, x1=230, y1=376)`

**Content**:

```
1.4.4. Industry prospects4
```

**Image**: *(has image_base64)*


---

### Block 67: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 12.004
- **bbox**: `BBox(x0=77, y0=378, x1=223, y1=394)`

**Content**:

```
1.4.5. Industry prospects
```

**Image**: *(has image_base64)*


---

### Block 68: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 13.0
- **bbox**: `BBox(x0=119, y0=394, x1=415, y1=407)`

**Content**:

```
The current industry as a whole exhibits the following characteristics:

```

**Image**: *(has image_base64)*


---

### Block 69: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 17.0
- **bbox**: `BBox(x0=121, y0=407, x1=552, y1=432)`

**Content**:

```
- The capabilities of pre-trained models have rapidly improved, but there are still differences in scenario generalization
```

**Image**: *(has image_base64)*


---

### Block 70: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 17.001
- **bbox**: `BBox(x0=121, y0=433, x1=552, y1=456)`

**Content**:

```
- The scale of internal data within the enterprise continues to grow, leading to a strong demand for intelligent retrieval and analysis
```

**Image**: *(has image_base64)*


---

### Block 71: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 17.002
- **bbox**: `BBox(x0=121, y0=457, x1=552, y1=481)`

**Content**:

```
- AI systems are gradually evolving from single-point applications towards platformization and servitization
```

**Image**: *(has image_base64)*


---

### Block 72: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 3
- **索引**: 18.0
- **bbox**: `BBox(x0=76, y0=482, x1=215, y1=499)`
- **标题级别**: 3

**Content**:

```
1.4.6. Main pain points

```

**Image**: *(has image_base64)*


---

### Block 73: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 19.0
- **bbox**: `BBox(x0=119, y0=501, x1=473, y1=513)`

**Content**:

```
In the actual implementation process, common issues include but are not limited to:

```

**Image**: *(has image_base64)*


---

### Block 74: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 23.0
- **bbox**: `BBox(x0=121, y0=517, x1=552, y1=542)`

**Content**:

```
- The data sources are complex, with a coexistence of structured, semi-structured, and unstructured data
```

**Image**: *(has image_base64)*


---

### Block 75: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 23.001
- **bbox**: `BBox(x0=121, y0=547, x1=552, y1=576)`

**Content**:

```
- The coupling between model services and business logic is too high, resulting in poor system maintainability
```

**Image**: *(has image_base64)*


---

### Block 76: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 23.002
- **bbox**: `BBox(x0=121, y0=578, x1=552, y1=605)`

**Content**:

```
- Without a unified evaluation and monitoring mechanism, it is difficult to continuously ensure the effectiveness of the model
```

**Image**: *(has image_base64)*


---

### Block 77: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 3
- **索引**: 24.0
- **bbox**: `BBox(x0=56, y0=609, x1=223, y1=625)`
- **标题级别**: 2

**Content**:

```
1.5.Construction objectives

```

**Image**: *(has image_base64)*


---

### Block 78: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 28.0
- **bbox**: `BBox(x0=97, y0=627, x1=552, y1=655)`

**Content**:

```
A. The goal of this project is to build an AI application system that is scalable, maintainable, and implementable,
```

**Image**: *(has image_base64)*


---

### Block 79: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 28.001
- **bbox**: `BBox(x0=97, y0=658, x1=425, y1=671)`

**Content**:

```
B. Capable of supporting multiple business scenarios within the enterprise,
```

**Image**: *(has image_base64)*


---

### Block 80: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 28.002
- **bbox**: `BBox(x0=97, y0=673, x1=360, y1=687)`

**Content**:

```
C. Provide a technical foundation for subsequent iterations。
```

**Image**: *(has image_base64)*


---

### Block 81: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 4
- **索引**: 0.0
- **bbox**: `BBox(x0=34, y0=116, x1=223, y1=136)`
- **标题级别**: 1

**Content**:

```
2. Overall scheme design

```

**Image**: *(has image_base64)*


---

### Block 82: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 4
- **索引**: 1.0
- **bbox**: `BBox(x0=54, y0=137, x1=276, y1=153)`
- **标题级别**: 2

**Content**:

```
2.1.Overview of system architecture

```

**Image**: *(has image_base64)*


---

### Block 83: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 4
- **索引**: 2.0
- **bbox**: `BBox(x0=76, y0=154, x1=554, y1=197)`

**Content**:

```
The system is designed with a layered architecture, encompassing a data layer, a model layer, and an application layer. This design ensures the independence between modules and facilitates the addition of new functional modules in the future.

```

**Image**: *(has image_base64)*


---

### Block 84: image

- **类型**: `image`
- **源类型**: `image`
- **页码**: 4
- **索引**: 3.0
- **bbox**: `BBox(x0=82, y0=200, x1=511, y1=429)`

**Content**:

*(empty)*

**Image**: *(has image_base64)*


---

### Block 85: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 4
- **索引**: 4.0
- **bbox**: `BBox(x0=54, y0=433, x1=171, y1=450)`
- **标题级别**: 2

**Content**:

```
2.2.技术选型说明

```

**Image**: *(has image_base64)*


---

### Block 86: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 4
- **索引**: 5.0
- **bbox**: `BBox(x0=74, y0=453, x1=220, y1=470)`
- **标题级别**: 3

**Content**:

```
2.2.1.后端与基础设施

```

**Image**: *(has image_base64)*


---

### Block 87: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 4
- **索引**: 10.0
- **bbox**: `BBox(x0=116, y0=473, x1=221, y1=486)`

**Content**:

```
编程语言：Python
```

**Image**: *(has image_base64)*


---

### Block 88: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 4
- **索引**: 10.001
- **bbox**: `BBox(x0=116, y0=489, x1=224, y1=500)`

**Content**:

```
- 服务框架：FastAPI
```

**Image**: *(has image_base64)*


---

### Block 89: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 4
- **索引**: 10.002
- **bbox**: `BBox(x0=116, y0=504, x1=251, y1=516)`

**Content**:

```
- 模型部署：vLLM/Triton
```

**Image**: *(has image_base64)*


---

### Block 90: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 4
- **索引**: 10.003
- **bbox**: `BBox(x0=116, y0=520, x1=289, y1=532)`

**Content**:

```
- 容器与编排：Docker + Kubernetes
```

**Image**: *(has image_base64)*


---

### Block 91: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 4
- **索引**: 11.0
- **bbox**: `BBox(x0=74, y0=535, x1=174, y1=551)`
- **标题级别**: 3

**Content**:

```
2.2.2. 模型相关

```

**Image**: *(has image_base64)*


---

### Block 92: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 4
- **索引**: 15.0
- **bbox**: `BBox(x0=116, y0=555, x1=228, y1=567)`

**Content**:

```
- 大语言模型（LLM）
```

**Image**: *(has image_base64)*


---

### Block 93: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 4
- **索引**: 15.001
- **bbox**: `BBox(x0=116, y0=571, x1=243, y1=583)`

**Content**:

```
向量模型（Embedding）
```

**Image**: *(has image_base64)*


---

### Block 94: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 4
- **索引**: 15.002
- **bbox**: `BBox(x0=116, y0=586, x1=227, y1=597)`

**Content**:

```
- RAG 检索增强生成
```

**Image**: *(has image_base64)*


---

### Block 95: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 4
- **索引**: 16.0
- **bbox**: `BBox(x0=74, y0=601, x1=204, y1=618)`
- **标题级别**: 3

**Content**:

```
2.2.3.其他模型相关

```

**Image**: *(has image_base64)*


---

### Block 96: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 4
- **索引**: 20.0
- **bbox**: `BBox(x0=116, y0=621, x1=229, y1=634)`

**Content**:

```
- 视觉大模型（VLM）
```

**Image**: *(has image_base64)*


---

### Block 97: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 4
- **索引**: 20.001
- **bbox**: `BBox(x0=116, y0=636, x1=243, y1=650)`

**Content**:

```
向量模型（Embedding）
```

**Image**: *(has image_base64)*


---

### Block 98: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 4
- **索引**: 20.002
- **bbox**: `BBox(x0=116, y0=652, x1=227, y1=664)`

**Content**:

```
- RAG 检索增强生成
```

**Image**: *(has image_base64)*


---

### Block 99: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 4
- **索引**: 21.0
- **bbox**: `BBox(x0=54, y0=667, x1=267, y1=684)`
- **标题级别**: 2

**Content**:

```
2.3. Technical selection description

```

**Image**: *(has image_base64)*


---

### Block 100: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 4
- **索引**: 22.0
- **bbox**: `BBox(x0=74, y0=685, x1=277, y1=700)`
- **标题级别**: 3

**Content**:

```
2.3.1. Backend and Infrastructure

```

**Image**: *(has image_base64)*


---

### Block 101: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 4
- **索引**: 26.0
- **bbox**: `BBox(x0=116, y0=703, x1=271, y1=716)`

**Content**:

```
- Programming language: Python
```

**Image**: *(has image_base64)*


---

### Block 102: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 4
- **索引**: 26.001
- **bbox**: `BBox(x0=116, y0=719, x1=257, y1=729)`

**Content**:

```
Service framework: FastAPI
```

**Image**: *(has image_base64)*


---

### Block 103: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 4
- **索引**: 26.002
- **bbox**: `BBox(x0=116, y0=734, x1=283, y1=745)`

**Content**:

```
Model deployment: vLLM / Triton
```

**Image**: *(has image_base64)*


---

### Block 104: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 5
- **索引**: 0.0
- **bbox**: `BBox(x0=116, y0=116, x1=353, y1=128)`

**Content**:

```
- Containers and orchestration: Docker + Kubernetes

```

**Image**: *(has image_base64)*


---

### Block 105: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 5
- **索引**: 1.0
- **bbox**: `BBox(x0=74, y0=131, x1=199, y1=146)`
- **标题级别**: 3

**Content**:

```
2.3.2. Model-related

```

**Image**: *(has image_base64)*


---

### Block 106: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 5.0
- **bbox**: `BBox(x0=116, y0=149, x1=267, y1=162)`

**Content**:

```
Large Language Model (LLM)
```

**Image**: *(has image_base64)*


---

### Block 107: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 5.001
- **bbox**: `BBox(x0=116, y0=164, x1=251, y1=178)`

**Content**:

```
- Vector model (Embedding)
```

**Image**: *(has image_base64)*


---

### Block 108: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 5.002
- **bbox**: `BBox(x0=116, y0=180, x1=304, y1=193)`

**Content**:

```
RAG: Retrieval Augmented Generation
```

**Image**: *(has image_base64)*


---

### Block 109: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 5
- **索引**: 6.0
- **bbox**: `BBox(x0=74, y0=195, x1=235, y1=210)`
- **标题级别**: 3

**Content**:

```
2.3.3. Other model-related

```

**Image**: *(has image_base64)*


---

### Block 110: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 10.0
- **bbox**: `BBox(x0=116, y0=213, x1=254, y1=226)`

**Content**:

```
Visual Large Model (VLM)
```

**Image**: *(has image_base64)*


---

### Block 111: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 10.001
- **bbox**: `BBox(x0=116, y0=229, x1=251, y1=242)`

**Content**:

```
Vector model (Embedding)
```

**Image**: *(has image_base64)*


---

### Block 112: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 10.002
- **bbox**: `BBox(x0=116, y0=244, x1=303, y1=257)`

**Content**:

```
RAG: Retrieval Augmented Generation
```

**Image**: *(has image_base64)*


---

### Block 113: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 5
- **索引**: 11.0
- **bbox**: `BBox(x0=74, y0=259, x1=277, y1=274)`
- **标题级别**: 3

**Content**:

```
2.3.4. Backend and Infrastructure

```

**Image**: *(has image_base64)*


---

### Block 114: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 16.0
- **bbox**: `BBox(x0=116, y0=277, x1=271, y1=290)`

**Content**:

```
- Programming language: Python
```

**Image**: *(has image_base64)*


---

### Block 115: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 16.001
- **bbox**: `BBox(x0=116, y0=293, x1=257, y1=304)`

**Content**:

```
Service framework: FastAPI
```

**Image**: *(has image_base64)*


---

### Block 116: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 16.002
- **bbox**: `BBox(x0=116, y0=308, x1=283, y1=321)`

**Content**:

```
Model deployment: vLLM / Triton
```

**Image**: *(has image_base64)*


---

### Block 117: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 16.003
- **bbox**: `BBox(x0=116, y0=324, x1=353, y1=336)`

**Content**:

```
- Containers and orchestration: Docker + Kubernetes
```

**Image**: *(has image_base64)*


---

### Block 118: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 5
- **索引**: 17.0
- **bbox**: `BBox(x0=74, y0=338, x1=199, y1=353)`
- **标题级别**: 3

**Content**:

```
2.3.5. Model-related

```

**Image**: *(has image_base64)*


---

### Block 119: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 21.0
- **bbox**: `BBox(x0=116, y0=356, x1=267, y1=370)`

**Content**:

```
Large Language Model (LLM)
```

**Image**: *(has image_base64)*


---

### Block 120: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 21.001
- **bbox**: `BBox(x0=116, y0=372, x1=251, y1=385)`

**Content**:

```
- Vector model (Embedding)
```

**Image**: *(has image_base64)*


---

### Block 121: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 21.002
- **bbox**: `BBox(x0=116, y0=388, x1=303, y1=401)`

**Content**:

```
RAG: Retrieval Augmented Generation
```

**Image**: *(has image_base64)*


---

### Block 122: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 5
- **索引**: 22.0
- **bbox**: `BBox(x0=74, y0=403, x1=235, y1=417)`
- **标题级别**: 3

**Content**:

```
2.3.6. Other model-related

```

**Image**: *(has image_base64)*


---

### Block 123: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 25.0
- **bbox**: `BBox(x0=116, y0=421, x1=254, y1=433)`

**Content**:

```
Visual Large Model (VLM)
```

**Image**: *(has image_base64)*


---

### Block 124: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 25.001
- **bbox**: `BBox(x0=116, y0=436, x1=251, y1=449)`

**Content**:

```
- Vector model (Embedding)
```

**Image**: *(has image_base64)*


---

### Block 125: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 5
- **索引**: 26.0
- **bbox**: `BBox(x0=74, y0=452, x1=506, y1=468)`
- **标题级别**: 3

**Content**:

```
2.3.7. RAG: Retrieval Augmented GenerationOther model-related

```

**Image**: *(has image_base64)*


---

### Block 126: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 30.0
- **bbox**: `BBox(x0=116, y0=470, x1=254, y1=483)`

**Content**:

```
Visual Large Model (VLM)
```

**Image**: *(has image_base64)*


---

### Block 127: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 30.001
- **bbox**: `BBox(x0=116, y0=486, x1=252, y1=498)`

**Content**:

```
- Vector model (Embedding)
```

**Image**: *(has image_base64)*


---

### Block 128: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 30.002
- **bbox**: `BBox(x0=116, y0=502, x1=303, y1=513)`

**Content**:

```
RAG: Retrieval Augmented Generation
```

**Image**: *(has image_base64)*


---

### Block 129: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 5
- **索引**: 31.0
- **bbox**: `BBox(x0=74, y0=516, x1=235, y1=530)`
- **标题级别**: 3

**Content**:

```
2.3.8. Other model-related

```

**Image**: *(has image_base64)*


---

### Block 130: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 36.0
- **bbox**: `BBox(x0=116, y0=534, x1=254, y1=547)`

**Content**:

```
Visual Large Model (VLM)
```

**Image**: *(has image_base64)*


---

### Block 131: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 36.001
- **bbox**: `BBox(x0=116, y0=550, x1=251, y1=563)`

**Content**:

```
- Vector model (Embedding)
```

**Image**: *(has image_base64)*


---

### Block 132: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 36.002
- **bbox**: `BBox(x0=116, y0=565, x1=303, y1=578)`

**Content**:

```
RAG: Retrieval Augmented Generation
```

**Image**: *(has image_base64)*


---

### Block 133: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 36.003
- **bbox**: `BBox(x0=116, y0=581, x1=257, y1=592)`

**Content**:

```
Service framework: FastAPI
```

**Image**: *(has image_base64)*


---

### Block 134: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 5
- **索引**: 37.0
- **bbox**: `BBox(x0=35, y0=613, x1=238, y1=630)`
- **标题级别**: 1

**Content**:

```
3. Core functional modules

```

**Image**: *(has image_base64)*


---

### Block 135: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 5
- **索引**: 38.0
- **bbox**: `BBox(x0=54, y0=632, x1=553, y1=664)`

**Content**:

```
3.1. All documents generated by function departments should be named according to the below-mentioned categories of documents.

```

**Image**: *(has image_base64)*


---

### Block 136: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 5
- **索引**: 39.0
- **bbox**: `BBox(x0=74, y0=664, x1=188, y1=678)`
- **标题级别**: 3

**Content**:

```
3.1.1.Data Source

```

**Image**: *(has image_base64)*


---

### Block 137: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 5
- **索引**: 40.0
- **bbox**: `BBox(x0=104, y0=681, x1=258, y1=694)`

**Content**:

```
A. Equipment pperation instruction

```

**Image**: *(has image_base64)*


---

### Block 138: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 5
- **索引**: 41.0
- **bbox**: `BBox(x0=213, y0=703, x1=402, y1=719)`

**Content**:

```
TABLE_placeHOLDER_001
```

**Image**: *(no image)*


---

### Block 139: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 6
- **索引**: 3.0
- **bbox**: `BBox(x0=75, y0=217, x1=354, y1=234)`
- **标题级别**: 3

**Content**:

```
3.1.2. All documents generated by function de

```

**Image**: *(has image_base64)*


---

### Block 140: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 6
- **索引**: 4.0
- **bbox**: `BBox(x0=75, y0=235, x1=293, y1=252)`
- **标题级别**: 3

**Content**:

```
3.1.3.数据处理模块包括以下流程

```

**Image**: *(has image_base64)*


---

### Block 141: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 6
- **索引**: 8.0
- **bbox**: `BBox(x0=98, y0=254, x1=277, y1=267)`

**Content**:

```
- 清洗无效数据，去除空值与重复数据
```

**Image**: *(has image_base64)*


---

### Block 142: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 6
- **索引**: 8.001
- **bbox**: `BBox(x0=98, y0=270, x1=230, y1=283)`

**Content**:

```
- 结构化与切分（Chunking）
```

**Image**: *(has image_base64)*


---

### Block 143: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 6
- **索引**: 8.002
- **bbox**: `BBox(x0=97, y0=285, x1=298, y1=298)`

**Content**:

```
- 向量化与索引构建，用于快速检索和匹配
```

**Image**: *(has image_base64)*


---

### Block 144: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 6
- **索引**: 9.0
- **bbox**: `BBox(x0=54, y0=301, x1=171, y1=318)`
- **标题级别**: 2

**Content**:

```
3.2.模型服务模块

```

**Image**: *(has image_base64)*


---

### Block 145: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 6
- **索引**: 10.0
- **bbox**: `BBox(x0=75, y0=321, x1=173, y1=338)`
- **标题级别**: 3

**Content**:

```
3.2.1.推理服务

```

**Image**: *(has image_base64)*


---

### Block 146: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 6
- **索引**: 11.0
- **bbox**: `BBox(x0=118, y0=339, x1=542, y1=354)`

**Content**:

```
模型通过统一的API服务对外提供能力，支持高并发和流式输出，以满足业务实时性要求。

```

**Image**: *(has image_base64)*


---

### Block 147: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 6
- **索引**: 12.0
- **bbox**: `BBox(x0=75, y0=356, x1=204, y1=373)`
- **标题级别**: 3

**Content**:

```
3.2.2.模型更新策略

```

**Image**: *(has image_base64)*


---

### Block 148: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 6
- **索引**: 15.0
- **bbox**: `BBox(x0=116, y0=377, x1=284, y1=390)`

**Content**:

```
- 支持模型热更新，避免服务中断
```

**Image**: *(has image_base64)*


---

### Block 149: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 6
- **索引**: 15.001
- **bbox**: `BBox(x0=116, y0=394, x1=343, y1=407)`

**Content**:

```
- 支持多版本并行部署，便于 A/B 测试和回滚
```

**Image**: *(has image_base64)*


---

### Block 150: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 6
- **索引**: 16.0
- **bbox**: `BBox(x0=54, y0=412, x1=156, y1=428)`
- **标题级别**: 2

**Content**:

```
3.3.应用层模块

```

**Image**: *(has image_base64)*


---

### Block 151: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 6
- **索引**: 17.0
- **bbox**: `BBox(x0=75, y0=431, x1=204, y1=448)`
- **标题级别**: 3

**Content**:

```
3.3.1.典型应用场景

```

**Image**: *(has image_base64)*


---

### Block 152: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 6
- **索引**: 21.0
- **bbox**: `BBox(x0=116, y0=453, x1=199, y1=465)`

**Content**:

```
智能问答助手
```

**Image**: *(has image_base64)*


---

### Block 153: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 6
- **索引**: 21.001
- **bbox**: `BBox(x0=116, y0=470, x1=210, y1=483)`

**Content**:

```
文档检索与总结
```

**Image**: *(has image_base64)*


---

### Block 154: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 6
- **索引**: 21.002
- **bbox**: `BBox(x0=116, y0=487, x1=200, y1=499)`

**Content**:

```
业务辅助决策
```

**Image**: *(has image_base64)*


---

### Block 155: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 6
- **索引**: 22.0
- **bbox**: `BBox(x0=75, y0=505, x1=189, y1=522)`
- **标题级别**: 3

**Content**:

```
3.3.2. 权限与安全

```

**Image**: *(has image_base64)*


---

### Block 156: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 6
- **索引**: 26.0
- **bbox**: `BBox(x0=116, y0=526, x1=200, y1=539)`

**Content**:

```
用户身份鉴权
```

**Image**: *(has image_base64)*


---

### Block 157: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 6
- **索引**: 26.001
- **bbox**: `BBox(x0=116, y0=543, x1=232, y1=556)`

**Content**:

```
- 请求审计与日志记录
```

**Image**: *(has image_base64)*


---

### Block 158: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 6
- **索引**: 26.002
- **bbox**: `BBox(x0=116, y0=560, x1=200, y1=573)`

**Content**:

```
数据访问控制
```

**Image**: *(has image_base64)*


---

### Block 159: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 6
- **索引**: 27.0
- **bbox**: `BBox(x0=34, y0=602, x1=339, y1=623)`
- **标题级别**: 1

**Content**:

```
4. 4. Implementation plan and milestones

```

**Image**: *(has image_base64)*


---

### Block 160: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 6
- **索引**: 28.0
- **bbox**: `BBox(x0=54, y0=630, x1=316, y1=647)`
- **标题级别**: 2

**Content**:

```
4.1.Categories and hierarchy of documents

```

**Image**: *(has image_base64)*


---

### Block 161: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 6
- **索引**: 29.0
- **bbox**: `BBox(x0=172, y0=655, x1=362, y1=672)`

**Content**:

```
TABLE_placeHOLDER_004
```

**Image**: *(no image)*


---

### Block 162: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 6
- **索引**: -999.9883
- **bbox**: `BBox(x0=214, y0=117, x1=404, y1=133)`

**Content**:

```
TABLE_placeHOLDER_002
```

**Image**: *(no image)*


---

### Block 163: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 6
- **索引**: -999.9865
- **bbox**: `BBox(x0=104, y0=135, x1=194, y1=147)`

**Content**:

```
B. Other documents

```

**Image**: *(has image_base64)*


---

### Block 164: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 6
- **索引**: -999.9844
- **bbox**: `BBox(x0=213, y0=156, x1=404, y1=174)`

**Content**:

```
TABLE_placeHOLDER_003
```

**Image**: *(no image)*


---

### Block 165: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 7
- **索引**: 1.0
- **bbox**: `BBox(x0=54, y0=163, x1=171, y1=180)`
- **标题级别**: 2

**Content**:

```
4.2.实施阶段划分

```

**Image**: *(has image_base64)*


---

### Block 166: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 7
- **索引**: 2.0
- **bbox**: `BBox(x0=172, y0=190, x1=363, y1=206)`

**Content**:

```
TABLE_placeHOLDER_006
```

**Image**: *(no image)*


---

### Block 167: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 7
- **索引**: 3.0
- **bbox**: `BBox(x0=54, y0=325, x1=155, y1=341)`
- **标题级别**: 2

**Content**:

```
4.3.风险与应对

```

**Image**: *(has image_base64)*


---

### Block 168: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 7
- **索引**: 4.0
- **bbox**: `BBox(x0=74, y0=345, x1=174, y1=361)`
- **标题级别**: 3

**Content**:

```
4.3.1.技术风险

```

**Image**: *(has image_base64)*


---

### Block 169: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 7
- **索引**: 7.0
- **bbox**: `BBox(x0=116, y0=366, x1=326, y1=379)`

**Content**:

```
- 模型效果不稳定 \rightarrow 引入评估与回滚机制
```

**Image**: *(has image_base64)*


---

### Block 170: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 7
- **索引**: 7.001
- **bbox**: `BBox(x0=116, y0=383, x1=346, y1=396)`

**Content**:

```
- 系统性能瓶颈 \rightarrow 采用分布式部署与负载均衡
```

**Image**: *(has image_base64)*


---

### Block 171: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 7
- **索引**: 8.0
- **bbox**: `BBox(x0=74, y0=401, x1=174, y1=417)`
- **标题级别**: 3

**Content**:

```
4.3.2.业务风险

```

**Image**: *(has image_base64)*


---

### Block 172: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 7
- **索引**: 11.0
- **bbox**: `BBox(x0=116, y0=422, x1=347, y1=435)`

**Content**:

```
- 需求变更频繁 \rightarrow 采用模块化设计与灵活迭代
```

**Image**: *(has image_base64)*


---

### Block 173: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 7
- **索引**: 11.001
- **bbox**: `BBox(x0=116, y0=439, x1=336, y1=452)`

**Content**:

```
数据安全问题 \rightarrow 强化访问控制和日志审计
```

**Image**: *(has image_base64)*


---

### Block 174: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 7
- **索引**: -999.9878
- **bbox**: `BBox(x0=172, y0=122, x1=362, y1=138)`

**Content**:

```
TABLE_placeHOLDER_005
```

**Image**: *(no image)*


---

### Block 175: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 8
- **索引**: 0.0
- **bbox**: `BBox(x0=35, y0=116, x1=145, y1=133)`
- **标题级别**: 1

**Content**:

```
5. Attachment

```

**Image**: *(has image_base64)*


---

### Block 176: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 8
- **索引**: 11.0
- **bbox**: `BBox(x0=55, y0=137, x1=289, y1=154)`

**Content**:

```
5.1. Attachment1: Formate for xxxx1
```

**Image**: *(has image_base64)*


---

### Block 177: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 8
- **索引**: 11.001
- **bbox**: `BBox(x0=55, y0=155, x1=289, y1=173)`

**Content**:

```
5.2. Attachment1: Formate for xxxxxx2
```

**Image**: *(has image_base64)*


---

### Block 178: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 8
- **索引**: 11.002
- **bbox**: `BBox(x0=55, y0=174, x1=289, y1=192)`

**Content**:

```
5.3. Attachment1: Formate for xxxx3
```

**Image**: *(has image_base64)*


---

### Block 179: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 8
- **索引**: 11.003
- **bbox**: `BBox(x0=55, y0=194, x1=289, y1=211)`

**Content**:

```
5.4. Attachment1: Formate for xxxx4
```

**Image**: *(has image_base64)*


---

### Block 180: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 8
- **索引**: 11.004
- **bbox**: `BBox(x0=55, y0=213, x1=289, y1=231)`

**Content**:

```
5.5. Attachment1: Formate for xxxx5
```

**Image**: *(has image_base64)*


---

### Block 181: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 8
- **索引**: 11.005
- **bbox**: `BBox(x0=55, y0=232, x1=289, y1=250)`

**Content**:

```
5.6. Attachment1: Formate for xxxx6
```

**Image**: *(has image_base64)*


---

### Block 182: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 8
- **索引**: 11.006
- **bbox**: `BBox(x0=55, y0=252, x1=289, y1=270)`

**Content**:

```
5.7. Attachment1: Formate for xxxx7
```

**Image**: *(has image_base64)*


---

### Block 183: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 8
- **索引**: 11.007
- **bbox**: `BBox(x0=55, y0=272, x1=289, y1=289)`

**Content**:

```
5.8. Attachment1: Formate for xxxxxx8
```

**Image**: *(has image_base64)*


---

### Block 184: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 8
- **索引**: 11.008
- **bbox**: `BBox(x0=55, y0=290, x1=289, y1=309)`

**Content**:

```
5.9. Attachment1: Formate for xxxx9
```

**Image**: *(has image_base64)*


---

### Block 185: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 8
- **索引**: 11.009
- **bbox**: `BBox(x0=55, y0=311, x1=317, y1=329)`

**Content**:

```
5.10. Attachment1: Formate for xxxx10
```

**Image**: *(has image_base64)*


---

### Block 186: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 8
- **索引**: 12.0
- **bbox**: `BBox(x0=35, y0=348, x1=149, y1=368)`
- **标题级别**: 1

**Content**:

```
6. 总结与展望

```

**Image**: *(has image_base64)*


---

### Block 187: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 8
- **索引**: 13.0
- **bbox**: `BBox(x0=55, y0=379, x1=547, y1=408)`

**Content**:

```
本文档围绕AI应用落地这一核心目标，从项目背景、总体方案、核心功能模块以及实施计划等多个角度，对系统建设思路进行了系统性说明。

```

**Image**: *(has image_base64)*


---

### Block 188: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 8
- **索引**: 14.0
- **bbox**: `BBox(x0=55, y0=419, x1=553, y1=449)`

**Content**:

```
通过分层架构设计与模块化拆分，可以在保证系统稳定性的同时，提升整体的可扩展性与可维护性，使AI能力能够随着业务需求的变化持续演进。

```

**Image**: *(has image_base64)*


---

### Block 189: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 8
- **索引**: 18.0
- **bbox**: `BBox(x0=55, y0=460, x1=553, y1=488)`

**Content**:

```
- 在未来的优化方向上，可以重点考虑以下几个方面： - 引入多模态模型能力，支持图像、表格与文本的联合理解
```

**Image**: *(has image_base64)*


---

### Block 190: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 8
- **索引**: 18.001
- **bbox**: `BBox(x0=55, y0=491, x1=399, y1=505)`

**Content**:

```
□ 构建面向复杂任务的智能体（Agent）系统，实现任务自动拆解与执行
```

**Image**: *(has image_base64)*


---

### Block 191: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 8
- **索引**: 18.002
- **bbox**: `BBox(x0=55, y0=507, x1=364, y1=520)`

**Content**:

```
□ 加强模型效果评估与监控体系，形成数据驱动的持续优化闭环
```

**Image**: *(has image_base64)*


---

### Block 192: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 8
- **索引**: 19.0
- **bbox**: `BBox(x0=55, y0=531, x1=547, y1=560)`

**Content**:

```
综上所述，该方案不仅适用于当前阶段的AI应用建设，也为后续能力扩展和规模化部署预留了充足空间。At detachment

```

**Image**: *(has image_base64)*


---

### Block 193: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 8
- **索引**: 20.0
- **bbox**: `BBox(x0=35, y0=572, x1=553, y1=600)`

**Content**:

```
7. SMIC document security levels are categorized accounting to the security control level's defined in "CR-GWNL-01-1001 SMIC Classified Information Protection Policy (CIPP)" as follows

```

**Image**: *(has image_base64)*


---

### Block 194: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 8
- **索引**: 21.0
- **bbox**: `BBox(x0=231, y0=613, x1=357, y1=625)`

**Content**:

```
Security A-SMIC Top Secret

```

**Image**: *(has image_base64)*


---

### Block 195: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 8
- **索引**: 22.0
- **bbox**: `BBox(x0=231, y0=637, x1=362, y1=650)`

**Content**:

```
Security B-SMIC Confidential

```

**Image**: *(has image_base64)*


---

### Block 196: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 8
- **索引**: 23.0
- **bbox**: `BBox(x0=233, y0=661, x1=355, y1=674)`

**Content**:

```
Security C-SMIC Restricted

```

**Image**: *(has image_base64)*


---

### Block 197: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 8
- **索引**: 24.0
- **bbox**: `BBox(x0=238, y0=686, x1=351, y1=698)`

**Content**:

```
Security D-SMIC Internal

```

**Image**: *(has image_base64)*


---

### Block 198: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 8
- **索引**: 25.0
- **bbox**: `BBox(x0=35, y0=710, x1=354, y1=724)`

**Content**:

```
8. TECN: Temporary engineering changes can be requested as necessary

```

**Image**: *(has image_base64)*


---

### Block 199: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 8
- **索引**: 26.0
- **bbox**: `BBox(x0=55, y0=726, x1=190, y1=739)`

**Content**:

```
8.1. Effective period of TECN

```

**Image**: *(has image_base64)*


---

### Block 200: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 9
- **索引**: 0.0
- **bbox**: `BBox(x0=74, y0=116, x1=552, y1=144)`

**Content**:

```
8.1.1. The maximum effective period of a TECN is 14 working days. If in special situation, e.g. raw material or part specification evaluation, the maximum effective period is 6 months.

```

**Image**: *(has image_base64)*


---

### Block 201: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 9
- **索引**: 1.0
- **bbox**: `BBox(x0=74, y0=147, x1=552, y1=176)`

**Content**:

```
8.1.2. TECN renewal:TECN which are preferable, suitable, and necessary for advancing into permanent engineering changes can be renewed for three time at most.

```

**Image**: *(has image_base64)*


---
