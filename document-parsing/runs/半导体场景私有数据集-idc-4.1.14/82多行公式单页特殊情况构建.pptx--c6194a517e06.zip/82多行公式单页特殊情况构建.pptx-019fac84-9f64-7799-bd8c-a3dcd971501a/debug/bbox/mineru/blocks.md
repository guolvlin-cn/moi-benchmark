# MinerU Parser Debug Output

**生成时间**: 2026-07-29T14:16:49.778084

**Block 总数**: 9


---

## 类型统计

| 类型 | 数量 |
|------|------|
| list | 7 |
| text | 1 |
| title | 1 |

---

## Block 详情

### Block 0: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 0.0
- **bbox**: `BBox(x0=355, y0=48, x1=489, y1=81)`
- **标题级别**: 1

**Content**:

```
Analysis

```

**Image**: *(has image_base64)*


---

### Block 1: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 1.0
- **bbox**: `BBox(x0=111, y0=113, x1=229, y1=129)`

**Content**:

```
距离计算方法主要有：

```

**Image**: *(has image_base64)*


---

### Block 2: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 9.0
- **bbox**: `BBox(x0=120, y0=129, x1=462, y1=159)`

**Content**:

```
(1) 欧氏距离'euclidean': c = \sqrt{(x_1 - x_2)^2 + (y_1 - y_2)^2}
```

**Image**: *(has image_base64)*


---

### Block 3: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 9.001
- **bbox**: `BBox(x0=120, y0=164, x1=470, y1=193)`

**Content**:

```
(2）曼哈顿距离'manhattan'： c = |x_1 - x_2| + |y_1 - y_2|
```

**Image**: *(has image_base64)*


---

### Block 4: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 9.002
- **bbox**: `BBox(x0=120, y0=199, x1=573, y1=230)`

**Content**:

```
(3) 切比雪夫距离'chebyshev': D_{\mathrm{Chebyshev}}(p, q) \coloneqq \max_i (|p_i - q_i|) .
```

**Image**: *(has image_base64)*


---

### Block 5: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 9.003
- **bbox**: `BBox(x0=120, y0=228, x1=425, y1=264)`

**Content**:

```
(4) 闵可夫斯基距离‘minkowski’: d_{12} = \sqrt[p]{\sum_{k=1}^{n} |x_{1k} - x_{2k}|^p}
```

**Image**: *(has image_base64)*


---

### Block 6: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 9.004
- **bbox**: `BBox(x0=120, y0=265, x1=548, y1=300)`

**Content**:

```
(5) 带权重闭可夫斯基距离'wminkowski': d_{12} = \sqrt{\sum_{k=1}^{n}\left(x_{1k} - x_{2k}\right)^{2}} , 其中w为特征权重
```

**Image**: *(has image_base64)*


---

### Block 7: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 9.005
- **bbox**: `BBox(x0=120, y0=303, x1=775, y1=319)`

**Content**:

```
(6）标准化欧氏距离'seuclidean'：即对于各特征维度做了归一化以后的欧氏距离。此时个样本特征维度的均值为0，方差为1.
```

**Image**: *(has image_base64)*


---

### Block 8: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 9.006
- **bbox**: `BBox(x0=111, y0=334, x1=883, y1=382)`

**Content**:

```
(7) 马氏距离 'mahalanobis' : D_{M}(x) = \sqrt{(x - \mu)^{T} \Sigma^{-1}(x - \mu)} 为样本协方差矩阵的逆矩阵。当样本分布独立时，S为单位矩阵，此时马氏距离等同于欧氏距离。
```

**Image**: *(has image_base64)*


---
