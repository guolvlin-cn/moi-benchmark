# MinerU Parser Debug Output

**生成时间**: 2026-07-29T14:27:25.154175

**Block 总数**: 46


---

## 类型统计

| 类型 | 数量 |
|------|------|
| list | 17 |
| text | 23 |
| title | 6 |

---

## Block 详情

### Block 0: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 0.0
- **bbox**: `BBox(x0=88, y0=89, x1=269, y1=111)`
- **标题级别**: 1

**Content**:

```
Support coverage

```

**Image**: *(has image_base64)*


---

### Block 1: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 1.0
- **bbox**: `BBox(x0=182, y0=121, x1=505, y1=159)`

**Content**:

```
This section describes the support coverage provided with the release, including version obsolescence, how to access the distribution site, and how to contact software support.

```

**Image**: *(has image_base64)*


---

### Block 2: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 2.0
- **bbox**: `BBox(x0=87, y0=198, x1=305, y1=218)`
- **标题级别**: 1

**Content**:

```
Version obsolescence

```

**Image**: *(has image_base64)*


---

### Block 3: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 3.0
- **bbox**: `BBox(x0=182, y0=249, x1=496, y1=295)`

**Content**:

```
ISS-DDIS-DIAGS is not a generic industry standard term; it is an internal system/module identifier, commonly seen in semiconductor equipment software environments (e.g., Applied Materials systems).

```

**Image**: *(has image_base64)*


---

### Block 4: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 4.0
- **bbox**: `BBox(x0=181, y0=312, x1=470, y1=356)`

**Content**:

```
Defines the schema of the result set. Each entry describes a column, including column name, data type, unit (if applicable), and optional attributes such as precision or nullability.

```

**Image**: *(has image_base64)*


---

### Block 5: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 5.0
- **bbox**: `BBox(x0=181, y0=374, x1=495, y1=403)`

**Content**:

```
Contains the actual data records returned by the dispatch query. Each row corresponds to one result entry and follows the order defined in #columns

```

**Image**: *(has image_base64)*


---

### Block 6: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 1
- **索引**: 6.0
- **bbox**: `BBox(x0=201, y0=412, x1=391, y1=428)`

**Content**:

```
TABLE_placeHOLDER_001
```

**Image**: *(no image)*


---

### Block 7: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 7.0
- **bbox**: `BBox(x0=87, y0=560, x1=395, y1=585)`
- **标题级别**: 1

**Content**:

```
Accessing the distribution site

```

**Image**: *(has image_base64)*


---

### Block 8: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 8.0
- **bbox**: `BBox(x0=181, y0=597, x1=407, y1=609)`

**Content**:

```
Term Breakdown (typical engineering interpretation)

```

**Image**: *(has image_base64)*


---

### Block 9: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 9.0
- **bbox**: `BBox(x0=182, y0=628, x1=204, y1=638)`

**Content**:

```
1.ISS

```

**Image**: *(has image_base64)*


---

### Block 10: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 10.0
- **bbox**: `BBox(x0=181, y0=643, x1=358, y1=655)`

**Content**:

```
2.Integrated / Intelligent System Services

```

**Image**: *(has image_base64)*


---

### Block 11: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 11.0
- **bbox**: `BBox(x0=181, y0=659, x1=468, y1=671)`

**Content**:

```
Refers to the system-level service layer of the equipment software.

```

**Image**: *(has image_base64)*


---

### Block 12: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 12.0
- **bbox**: `BBox(x0=180, y0=690, x1=396, y1=702)`

**Content**:

```
Device Data / Diagnostic Data Information System

```

**Image**: *(has image_base64)*


---

### Block 13: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 13.0
- **bbox**: `BBox(x0=181, y0=706, x1=498, y1=733)`

**Content**:

```
Indicates a subsystem responsible for collecting, managing, or distributing device diagnostic data.

```

**Image**: *(has image_base64)*


---

### Block 14: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 2
- **索引**: 0.0
- **bbox**: `BBox(x0=88, y0=104, x1=292, y1=130)`
- **标题级别**: 1

**Content**:

```
Support coverage_1

```

**Image**: *(has image_base64)*


---

### Block 15: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 1.0
- **bbox**: `BBox(x0=182, y0=137, x1=509, y1=176)`

**Content**:

```
This section describes the support coverage provided with the release, including version obsolescence, how to access the distribution site, and how to contact software support.-1

```

**Image**: *(has image_base64)*


---

### Block 16: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 2
- **索引**: 2.0
- **bbox**: `BBox(x0=87, y0=214, x1=308, y1=235)`
- **标题级别**: 1

**Content**:

```
Version obsolescence

```

**Image**: *(has image_base64)*


---

### Block 17: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 3.0
- **bbox**: `BBox(x0=182, y0=265, x1=498, y1=311)`

**Content**:

```
ISS-DDIS-DIAGS is not a generic industry standard term; it is an internal system/module identifier, commonly seen in semiconductor equipment software environments (e.g., Applied Materials systems).-1

```

**Image**: *(has image_base64)*


---

### Block 18: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 4.0
- **bbox**: `BBox(x0=182, y0=327, x1=473, y1=373)`

**Content**:

```
Defines the schema of the result set. Each entry describes a column, including column name, data type, unit (if applicable), and optional attributes such as precision or nullability.-1

```

**Image**: *(has image_base64)*


---

### Block 19: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 5.0
- **bbox**: `BBox(x0=182, y0=390, x1=498, y1=419)`

**Content**:

```
Contains the actual data records returned by the dispatch query. Each row corresponds to one result entry and follows the order defined in #columns

```

**Image**: *(has image_base64)*


---

### Block 20: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 2
- **索引**: 6.0
- **bbox**: `BBox(x0=201, y0=428, x1=393, y1=445)`

**Content**:

```
TABLE_placeHOLDER_002
```

**Image**: *(no image)*


---

### Block 21: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 2
- **索引**: 7.0
- **bbox**: `BBox(x0=87, y0=576, x1=415, y1=601)`
- **标题级别**: 1

**Content**:

```
Accessing the distribution site-1

```

**Image**: *(has image_base64)*


---

### Block 22: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 8.0
- **bbox**: `BBox(x0=181, y0=613, x1=416, y1=624)`

**Content**:

```
Term Breakdown (typical engineering interpretation)-1

```

**Image**: *(has image_base64)*


---

### Block 23: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 9.0
- **bbox**: `BBox(x0=181, y0=644, x1=205, y1=654)`

**Content**:

```
1.ISS

```

**Image**: *(has image_base64)*


---

### Block 24: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 10.0
- **bbox**: `BBox(x0=181, y0=659, x1=366, y1=671)`

**Content**:

```
2.Integrated / Intelligent System Services-1

```

**Image**: *(has image_base64)*


---

### Block 25: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 11.0
- **bbox**: `BBox(x0=181, y0=674, x1=468, y1=687)`

**Content**:

```
Refers to the system-level service layer of the equipment software.

```

**Image**: *(has image_base64)*


---

### Block 26: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 12.0
- **bbox**: `BBox(x0=180, y0=706, x1=396, y1=718)`

**Content**:

```
Device Data / Diagnostic Data Information System

```

**Image**: *(has image_base64)*


---

### Block 27: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 13.0
- **bbox**: `BBox(x0=180, y0=721, x1=498, y1=749)`

**Content**:

```
Indicates a subsystem responsible for collecting, managing, or distributing device diagnostic data.-1

```

**Image**: *(has image_base64)*


---

### Block 28: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 0.0
- **bbox**: `BBox(x0=181, y0=108, x1=406, y1=121)`

**Content**:

```
Term Breakdown (typical engineering interpretation)

```

**Image**: *(has image_base64)*


---

### Block 29: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 18.0
- **bbox**: `BBox(x0=181, y0=139, x1=376, y1=151)`

**Content**:

```
- ISS,Integrated / Intelligent System Services
```

**Image**: *(has image_base64)*


---

### Block 30: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 18.001
- **bbox**: `BBox(x0=181, y0=155, x1=467, y1=167)`

**Content**:

```
Refers to the system-level service layer of the equipment software.
```

**Image**: *(has image_base64)*


---

### Block 31: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 18.002
- **bbox**: `BBox(x0=180, y0=186, x1=429, y1=198)`

**Content**:

```
- DDIS, Device Data / Diagnostic Data Information System
```

**Image**: *(has image_base64)*


---

### Block 32: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 18.003
- **bbox**: `BBox(x0=180, y0=201, x1=498, y1=229)`

**Content**:

```
Indicates a subsystem responsible for collecting, managing, or distributing device diagnostic data.
```

**Image**: *(has image_base64)*


---

### Block 33: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 18.004
- **bbox**: `BBox(x0=181, y0=248, x1=441, y1=275)`

**Content**:

```
- DIAGS, Diagnostics, Explicitly denotes diagnostic, health, or troubleshooting-related data and functions.
```

**Image**: *(has image_base64)*


---

### Block 34: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 18.005
- **bbox**: `BBox(x0=181, y0=295, x1=348, y1=306)`

**Content**:

```
Combined Meaning,ISS-DDIS-DIAGS
```

**Image**: *(has image_base64)*


---

### Block 35: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 18.006
- **bbox**: `BBox(x0=180, y0=311, x1=458, y1=322)`

**Content**:

```
- A system-level diagnostic data module or namespace used for
```

**Image**: *(has image_base64)*


---

### Block 36: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 18.007
- **bbox**: `BBox(x0=180, y0=327, x1=493, y1=354)`

**Content**:

```
equipment health monitoring, fault diagnosis, and maintenance analysis, rather than for process or recipe control.
```

**Image**: *(has image_base64)*


---

### Block 37: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 18.008
- **bbox**: `BBox(x0=181, y0=357, x1=452, y1=370)`

**Content**:

```
- Typical Usage Contexts,Dispatch or query result namespaces
```

**Image**: *(has image_base64)*


---

### Block 38: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 18.009
- **bbox**: `BBox(x0=181, y0=373, x1=365, y1=385)`

**Content**:

```
- Equipment diagnostic or service queries
```

**Image**: *(has image_base64)*


---

### Block 39: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 18.01
- **bbox**: `BBox(x0=181, y0=389, x1=291, y1=400)`

**Content**:

```
- System logs and traces
```

**Image**: *(has image_base64)*


---

### Block 40: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 18.011
- **bbox**: `BBox(x0=181, y0=404, x1=388, y1=416)`

**Content**:

```
- Maintenance / engineering mode data access
```

**Image**: *(has image_base64)*


---

### Block 41: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 18.012
- **bbox**: `BBox(x0=181, y0=420, x1=258, y1=431)`

**Content**:

```
Key Distinction
```

**Image**: *(has image_base64)*


---

### Block 42: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 18.013
- **bbox**: `BBox(x0=181, y0=435, x1=452, y1=447)`

**Content**:

```
- Process data \rightarrow used for wafer processing and recipe control
```

**Image**: *(has image_base64)*


---

### Block 43: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 18.014
- **bbox**: `BBox(x0=180, y0=451, x1=478, y1=478)`

**Content**:

```
- ISS-DDIS-DIAGS \rightarrow used for equipment diagnostics, debugging, and health monitoring,One-sentence summary
```

**Image**: *(has image_base64)*


---

### Block 44: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 18.015
- **bbox**: `BBox(x0=180, y0=482, x1=503, y1=524)`

**Content**:

```
- ISS-DDIS-DIAGS refers to a system-level diagnostics module that provides device health and troubleshooting data within the equipment software architecture.
```

**Image**: *(has image_base64)*


---

### Block 45: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 18.016
- **bbox**: `BBox(x0=180, y0=528, x1=498, y1=572)`

**Content**:

```
- If you can share the exact query output or field names where this appears, the meaning can be narrowed further (e.g., real-time diagnostics vs. historical logs).
```

**Image**: *(has image_base64)*


---
