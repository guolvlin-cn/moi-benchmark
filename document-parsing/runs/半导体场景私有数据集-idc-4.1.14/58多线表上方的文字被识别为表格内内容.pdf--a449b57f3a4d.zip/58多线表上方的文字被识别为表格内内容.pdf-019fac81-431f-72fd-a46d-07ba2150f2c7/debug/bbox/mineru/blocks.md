# MinerU Parser Debug Output

**生成时间**: 2026-07-29T14:13:06.712241

**Block 总数**: 2


---

## 类型统计

| 类型 | 数量 |
|------|------|
| text | 1 |
| title | 1 |

---

## Block 详情

### Block 0: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 0.0
- **bbox**: `BBox(x0=88, y0=97, x1=251, y1=121)`
- **标题级别**: 1

**Content**:

```
Support ending

```

**Image**: *(has image_base64)*


---

### Block 1: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 1
- **索引**: 1.0
- **bbox**: `BBox(x0=243, y0=153, x1=433, y1=169)`

**Content**:

```
TABLE_placeHOLDER_001
```

**Image**: *(no image)*


---
