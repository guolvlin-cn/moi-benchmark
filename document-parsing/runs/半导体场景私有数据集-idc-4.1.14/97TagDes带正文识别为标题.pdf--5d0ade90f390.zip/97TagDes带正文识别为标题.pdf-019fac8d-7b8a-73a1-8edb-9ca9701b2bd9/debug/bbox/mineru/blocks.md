# MinerU Parser Debug Output

**生成时间**: 2026-07-29T14:26:34.474002

**Block 总数**: 24


---

## 类型统计

| 类型 | 数量 |
|------|------|
| footer | 1 |
| header | 2 |
| text | 17 |
| title | 4 |

---

## Block 详情

### Block 0: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 2.0
- **bbox**: `BBox(x0=67, y0=72, x1=239, y1=92)`
- **标题级别**: 1

**Content**:

```
Dispatch list format

```

**Image**: *(has image_base64)*


---

### Block 1: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 3.0
- **bbox**: `BBox(x0=139, y0=105, x1=533, y1=149)`

**Content**:

```
Although the Dispatch API provides functions for parsing and accessing the dispatch result, you may want to handle the response yourself. In that case, this description of the returned dispatch list may be helpful.

```

**Image**: *(has image_base64)*


---

### Block 2: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 4.0
- **bbox**: `BBox(x0=139, y0=153, x1=533, y1=259)`

**Content**:

```
Designed for ZLink IoT Cloud (version 3.2+), enables gateways and edge devices to exchange batch control or data acquisition tasks using a compact and extensible TLV (Type-Length-Value) binary encoding. This approach ensures compatibility across vendors #rows, supports dynamic task type extensions, and performs reliably even under constrained network conditions. The following sections outline the technical specification and usage guidelines for this fictional API. Also, note that there is one key, #ISS_SLIS_DIAGS, which does not confirmed.

```

**Image**: *(has image_base64)*


---

### Block 3: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 5.0
- **bbox**: `BBox(x0=67, y0=286, x1=214, y1=307)`
- **标题级别**: 1

**Content**:

```
Tag descriptions

```

**Image**: *(has image_base64)*


---

### Block 4: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 6.0
- **bbox**: `BBox(x0=141, y0=320, x1=533, y1=348)`

**Content**:

```
The following table provides description for the tages used in a dispatch query result:

```

**Image**: *(has image_base64)*


---

### Block 5: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 7.0
- **bbox**: `BBox(x0=162, y0=352, x1=184, y1=365)`
- **标题级别**: 1

**Content**:

```
Tag

```

**Image**: *(has image_base64)*


---

### Block 6: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 8.0
- **bbox**: `BBox(x0=162, y0=367, x1=447, y1=380)`

**Content**:

```
Pre-defined headers for the dispatch list.

```

**Image**: *(has image_base64)*


---

### Block 7: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 9.0
- **bbox**: `BBox(x0=162, y0=383, x1=439, y1=395)`

**Content**:

```
columns The column heading names for the list.

```

**Image**: *(has image_base64)*


---

### Block 8: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 10.0
- **bbox**: `BBox(x0=162, y0=398, x1=518, y1=411)`

**Content**:

```
#widths The widths for each column, used in formatting the data.

```

**Image**: *(has image_base64)*


---

### Block 9: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 11.0
- **bbox**: `BBox(x0=162, y0=414, x1=532, y1=443)`

**Content**:

```
#types The data types for each column. Normally used to decide how to justify a column by default.

```

**Image**: *(has image_base64)*


---

### Block 10: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 12.0
- **bbox**: `BBox(x0=162, y0=445, x1=434, y1=457)`

**Content**:

```
#lotcol Which column contains the lot names.

```

**Image**: *(has image_base64)*


---

### Block 11: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 13.0
- **bbox**: `BBox(x0=162, y0=461, x1=442, y1=473)`

**Content**:

```
#rows The query data table in row-major form.

```

**Image**: *(has image_base64)*


---

### Block 12: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 14.0
- **bbox**: `BBox(x0=162, y0=476, x1=533, y1=521)`

**Content**:

```
#blocked A flag for each lot that indicates if it is blocked. The WorkStram dispatcher interface uses this flag to determine whether that lot is selectable by the operator.

```

**Image**: *(has image_base64)*


---

### Block 13: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 15.0
- **bbox**: `BBox(x0=162, y0=523, x1=532, y1=568)`

**Content**:

```
#ISS-DDIS- This is diagnostic information from the dispatcher, relating to the execution time of the rule. Note that it does not follow the same "#tag value" formats as the other tags.

```

**Image**: *(has image_base64)*


---

### Block 14: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 16.0
- **bbox**: `BBox(x0=67, y0=594, x1=280, y1=616)`
- **标题级别**: 1

**Content**:

```
Parding the dispatch list

```

**Image**: *(has image_base64)*


---

### Block 15: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 17.0
- **bbox**: `BBox(x0=139, y0=629, x1=533, y1=657)`

**Content**:

```
The following functions are available for parding and processing the dispatcher result:

```

**Image**: *(has image_base64)*


---

### Block 16: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 18.0
- **bbox**: `BBox(x0=77, y0=669, x1=108, y1=683)`

**Content**:

```
[C++]

```

**Image**: *(has image_base64)*


---

### Block 17: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 19.0
- **bbox**: `BBox(x0=77, y0=686, x1=255, y1=699)`

**Content**:

```
include "writerlibx/iss_schedmsg.h"

```

**Image**: *(has image_base64)*


---

### Block 18: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 20.0
- **bbox**: `BBox(x0=77, y0=701, x1=281, y1=714)`

**Content**:

```
include "writerlibx/iss_schedmsg_print.h"

```

**Image**: *(has image_base64)*


---

### Block 19: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 21.0
- **bbox**: `BBox(x0=77, y0=732, x1=247, y1=745)`

**Content**:

```
/* Parsing of raw dispatch results */

```

**Image**: *(has image_base64)*


---

### Block 20: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 22.0
- **bbox**: `BBox(x0=77, y0=748, x1=408, y1=761)`

**Content**:

```
schedmsg * issXEssSchedMsg(const char \*rawText, u_int text Size);

```

**Image**: *(has image_base64)*


---

### Block 21: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 1
- **索引**: -999.9978
- **bbox**: `BBox(x0=343, y0=22, x1=533, y1=34)`

**Content**:

```
Applied APF RTD 9.4.0 Dispatch API Guide

```

**Image**: *(has image_base64)*


---

### Block 22: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 1
- **索引**: -999.9966
- **bbox**: `BBox(x0=381, y0=34, x1=531, y1=46)`

**Content**:

```
Chapter 1. Using the Dispatch API

```

**Image**: *(has image_base64)*


---

### Block 23: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 1
- **索引**: 9999.0791
- **bbox**: `BBox(x0=384, y0=791, x1=511, y1=803)`

**Content**:

```
Applied Materials Confidential

```

**Image**: *(has image_base64)*


---
