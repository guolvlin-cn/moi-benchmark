# MinerU Parser Debug Output

**生成时间**: 2026-07-29T14:13:39.201587

**Block 总数**: 2


---

## 类型统计

| 类型 | 数量 |
|------|------|
| text | 2 |

---

## Block 详情

### Block 0: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 0.0
- **bbox**: `BBox(x0=86, y0=73, x1=506, y1=179)`

**Content**:

```
The rapid advancement of semiconductor technology has fundamentally transformed the landscape of modern embedded systems. In today's industrial environment, the integration of high-performance microcontrollers, such as the STM32 series or ARM-based processors, is no longer just about raw clock speed. Instead, the focus has shifted toward power efficiency, hardware-level security, and seamless peripheral integration. Systems must now handle complex tasks ranging from real-time sensor fusion to high-speed data transmission via encrypted network protocols.

```

**Image**: *(has image_base64)*


---

### Block 1: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 1
- **索引**: 1.0
- **bbox**: `BBox(x0=200, y0=190, x1=390, y1=206)`

**Content**:

```
TABLE_placeHOLDER_001
```

**Image**: *(no image)*


---
