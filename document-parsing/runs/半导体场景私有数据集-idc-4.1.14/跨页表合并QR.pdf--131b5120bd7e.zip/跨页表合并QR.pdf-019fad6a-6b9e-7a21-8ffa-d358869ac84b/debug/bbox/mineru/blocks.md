# MinerU Parser Debug Output

**生成时间**: 2026-07-29T18:28:05.670298

**Block 总数**: 250


---

## 类型统计

| 类型 | 数量 |
|------|------|
| footer | 22 |
| header | 17 |
| image | 1 |
| list | 118 |
| table | 1 |
| text | 50 |
| title | 41 |

---

## Block 详情

### Block 0: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 3.0
- **bbox**: `BBox(x0=229, y0=150, x1=359, y1=165)`
- **标题级别**: 1

**Content**:

```
AI 应用落地方案说明书

```

**Image**: *(has image_base64)*


---

### Block 1: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 4.0
- **bbox**: `BBox(x0=38, y0=191, x1=553, y1=205)`
- **标题级别**: 1

**Content**:

```
1. Project background and objectives 3

```

**Image**: *(has image_base64)*


---

### Block 2: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 9.0
- **bbox**: `BBox(x0=58, y0=206, x1=553, y1=221)`

**Content**:

```
1.1.DCC:Document Control Center 3
```

**Image**: *(has image_base64)*


---

### Block 3: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 9.001
- **bbox**: `BBox(x0=58, y0=222, x1=552, y1=237)`

**Content**:

```
1.2. DCN: Document Change Notice(for Company Rules and Regulations) 3
```

**Image**: *(has image_base64)*


---

### Block 4: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 9.002
- **bbox**: `BBox(x0=58, y0=238, x1=553, y1=252)`

**Content**:

```
1.3.DMS: Document Management System 3
```

**Image**: *(has image_base64)*


---

### Block 5: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 9.003
- **bbox**: `BBox(x0=58, y0=253, x1=553, y1=268)`

**Content**:

```
1.4. Background description 3
```

**Image**: *(has image_base64)*


---

### Block 6: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 16.0
- **bbox**: `BBox(x0=79, y0=269, x1=553, y1=283)`

**Content**:

```
1.4.1. Industry prospects 3
```

**Image**: *(has image_base64)*


---

### Block 7: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 16.001
- **bbox**: `BBox(x0=80, y0=285, x1=553, y1=299)`

**Content**:

```
1.4.2. Industry prospects2 3
```

**Image**: *(has image_base64)*


---

### Block 8: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 16.002
- **bbox**: `BBox(x0=80, y0=301, x1=552, y1=315)`

**Content**:

```
1.4.3. Industry prospects3 3
```

**Image**: *(has image_base64)*


---

### Block 9: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 16.003
- **bbox**: `BBox(x0=80, y0=317, x1=553, y1=330)`

**Content**:

```
1.4.4. Industry prospects4 3
```

**Image**: *(has image_base64)*


---

### Block 10: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 16.004
- **bbox**: `BBox(x0=80, y0=333, x1=553, y1=346)`

**Content**:

```
1.4.5. Industry prospects 3
```

**Image**: *(has image_base64)*


---

### Block 11: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 16.005
- **bbox**: `BBox(x0=80, y0=348, x1=553, y1=362)`

**Content**:

```
1.4.6. Main pain points 3
```

**Image**: *(has image_base64)*


---

### Block 12: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 17.0
- **bbox**: `BBox(x0=58, y0=364, x1=553, y1=376)`

**Content**:

```
1.5. Construction objectives 3

```

**Image**: *(has image_base64)*


---

### Block 13: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 18.0
- **bbox**: `BBox(x0=36, y0=379, x1=553, y1=392)`
- **标题级别**: 1

**Content**:

```
2. Overall scheme design 4

```

**Image**: *(has image_base64)*


---

### Block 14: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 21.0
- **bbox**: `BBox(x0=58, y0=394, x1=553, y1=408)`

**Content**:

```
2.1. Overview of system architecture 4
```

**Image**: *(has image_base64)*


---

### Block 15: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 21.001
- **bbox**: `BBox(x0=58, y0=409, x1=553, y1=423)`

**Content**:

```
2.2. 技术选型说明
```

**Image**: *(has image_base64)*


---

### Block 16: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 25.0
- **bbox**: `BBox(x0=79, y0=425, x1=553, y1=438)`

**Content**:

```
2.2.1.后端与基础设施 4
```

**Image**: *(has image_base64)*


---

### Block 17: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 25.001
- **bbox**: `BBox(x0=79, y0=440, x1=553, y1=454)`

**Content**:

```
2.2.2.模型相关 4
```

**Image**: *(has image_base64)*


---

### Block 18: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 25.002
- **bbox**: `BBox(x0=79, y0=456, x1=553, y1=470)`

**Content**:

```
2.2.3. 其他模型相关
```

**Image**: *(has image_base64)*


---

### Block 19: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 26.0
- **bbox**: `BBox(x0=58, y0=472, x1=553, y1=486)`
- **标题级别**: 2

**Content**:

```
2.3. Technical selection description 5

```

**Image**: *(has image_base64)*


---

### Block 20: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 35.0
- **bbox**: `BBox(x0=79, y0=488, x1=553, y1=501)`

**Content**:

```
2.3.1. Backend and Infrastructure 5
```

**Image**: *(has image_base64)*


---

### Block 21: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 35.001
- **bbox**: `BBox(x0=79, y0=503, x1=553, y1=517)`

**Content**:

```
2.3.2. Model-related 5
```

**Image**: *(has image_base64)*


---

### Block 22: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 35.002
- **bbox**: `BBox(x0=79, y0=519, x1=553, y1=532)`

**Content**:

```
2.3.3. Other model-related 5
```

**Image**: *(has image_base64)*


---

### Block 23: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 35.003
- **bbox**: `BBox(x0=79, y0=534, x1=553, y1=548)`

**Content**:

```
2.3.4. Backend and Infrastructure 5
```

**Image**: *(has image_base64)*


---

### Block 24: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 35.004
- **bbox**: `BBox(x0=79, y0=550, x1=553, y1=563)`

**Content**:

```
2.3.5. Model-related 5
```

**Image**: *(has image_base64)*


---

### Block 25: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 35.005
- **bbox**: `BBox(x0=79, y0=565, x1=553, y1=578)`

**Content**:

```
2.3.6. Other model-related 5
```

**Image**: *(has image_base64)*


---

### Block 26: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 35.006
- **bbox**: `BBox(x0=79, y0=581, x1=553, y1=595)`

**Content**:

```
2.3.7. RAG: Retrieval Augmented GenerationOther model-related 5
```

**Image**: *(has image_base64)*


---

### Block 27: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 35.007
- **bbox**: `BBox(x0=79, y0=597, x1=553, y1=610)`

**Content**:

```
2.3.8. Other model-related 5
```

**Image**: *(has image_base64)*


---

### Block 28: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 36.0
- **bbox**: `BBox(x0=36, y0=613, x1=553, y1=625)`
- **标题级别**: 1

**Content**:

```
3. Core functional modules 6

```

**Image**: *(has image_base64)*


---

### Block 29: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 37.0
- **bbox**: `BBox(x0=58, y0=628, x1=553, y1=657)`

**Content**:

```
3.1. All documents generated by function departments should be named according to the below-mentioned categories of documents. 6

```

**Image**: *(has image_base64)*


---

### Block 30: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 41.0
- **bbox**: `BBox(x0=79, y0=660, x1=553, y1=672)`

**Content**:

```
3.1.1.Data Source 6
```

**Image**: *(has image_base64)*


---

### Block 31: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 41.001
- **bbox**: `BBox(x0=79, y0=675, x1=553, y1=688)`

**Content**:

```
3.1.2. All documents generated by function de 6
```

**Image**: *(has image_base64)*


---

### Block 32: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 41.002
- **bbox**: `BBox(x0=79, y0=690, x1=553, y1=703)`

**Content**:

```
3.1.3. 数据处理模块包括以下流程
```

**Image**: *(has image_base64)*


---

### Block 33: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 42.0
- **bbox**: `BBox(x0=58, y0=705, x1=553, y1=719)`

**Content**:

```
3.2. 模型服务模块 6

```

**Image**: *(has image_base64)*


---

### Block 34: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 43.0
- **bbox**: `BBox(x0=79, y0=721, x1=553, y1=735)`

**Content**:

```
3.2.1. 推理服务 6

```

**Image**: *(has image_base64)*


---

### Block 35: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 1
- **索引**: -999.9952
- **bbox**: `BBox(x0=35, y0=48, x1=113, y1=94)`

**Content**:

```
SMIC

```

**Image**: *(has image_base64)*


---

### Block 36: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 1
- **索引**: -999.9921
- **bbox**: `BBox(x0=112, y0=79, x1=527, y1=100)`

**Content**:

```
Semiconfuctor Manufacturing International Corporation

```

**Image**: *(has image_base64)*


---

### Block 37: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 1
- **索引**: -999.9893
- **bbox**: `BBox(x0=202, y0=107, x1=391, y1=124)`

**Content**:

```
TABLE_placeHOLDER_001
```

**Image**: *(no image)*


---

### Block 38: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 1
- **索引**: 9999.0747
- **bbox**: `BBox(x0=36, y0=747, x1=553, y1=770)`

**Content**:

```
The information contained herein is exclusive property of SIMC, and shall not be distributed, reproduced, or disclosed in whole or in part without priornwrittn permission of SMIC

```

**Image**: *(has image_base64)*


---

### Block 39: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 1
- **索引**: 9999.078
- **bbox**: `BBox(x0=35, y0=780, x1=436, y1=792)`

**Content**:

```
According to :SMIC Document Control Procedure;Attachment No.: QR-QUSM-02-2001-002;Rev.:3

```

**Image**: *(has image_base64)*


---

### Block 40: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 1
- **索引**: 9999.078
- **bbox**: `BBox(x0=474, y0=780, x1=518, y1=790)`

**Content**:

```
2026-1-30

```

**Image**: *(has image_base64)*


---

### Block 41: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 2
- **索引**: 1.0
- **bbox**: `BBox(x0=112, y0=80, x1=527, y1=99)`
- **标题级别**: 1

**Content**:

```
Semiconfuctor Manufacturing International Corporation

```

**Image**: *(has image_base64)*


---

### Block 42: table

- **类型**: `table`
- **源类型**: `table`
- **页码**: 2
- **索引**: 2.0
- **bbox**: `BBox(x0=38, y0=99, x1=558, y1=128)`

**Content**:

```
<table><tr><td>DocNo.:QR-QUSM-02-2001</td><td>Doc.Title:SMIC Document Control Procedure</td><td>Rec.:1</td><td>Page No.:2/9</td></tr></table>
```

**Image**: *(has image_base64)*


---

### Block 43: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 3.0
- **bbox**: `BBox(x0=79, y0=142, x1=553, y1=156)`

**Content**:

```
3.2.2. 模型更新策略

```

**Image**: *(has image_base64)*


---

### Block 44: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 4.0
- **bbox**: `BBox(x0=57, y0=158, x1=553, y1=171)`

**Content**:

```
3.3.应用层模块 6

```

**Image**: *(has image_base64)*


---

### Block 45: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 7.0
- **bbox**: `BBox(x0=79, y0=173, x1=553, y1=186)`

**Content**:

```
3.3.1.典型应用场景 6
```

**Image**: *(has image_base64)*


---

### Block 46: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 7.001
- **bbox**: `BBox(x0=79, y0=189, x1=553, y1=202)`

**Content**:

```
3.3.2. 权限与安全
```

**Image**: *(has image_base64)*


---

### Block 47: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 8.0
- **bbox**: `BBox(x0=35, y0=205, x1=553, y1=218)`

**Content**:

```
4. 4. Implementation plan and milestones 7

```

**Image**: *(has image_base64)*


---

### Block 48: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 12.0
- **bbox**: `BBox(x0=57, y0=221, x1=553, y1=233)`

**Content**:

```
4.1. Categories and hierarchy of documents 7
```

**Image**: *(has image_base64)*


---

### Block 49: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 12.001
- **bbox**: `BBox(x0=57, y0=236, x1=553, y1=249)`

**Content**:

```
4.2. 实施阶段划分
```

**Image**: *(has image_base64)*


---

### Block 50: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 12.002
- **bbox**: `BBox(x0=57, y0=251, x1=553, y1=264)`

**Content**:

```
4.3.风险与应对
```

**Image**: *(has image_base64)*


---

### Block 51: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 15.0
- **bbox**: `BBox(x0=79, y0=267, x1=553, y1=280)`

**Content**:

```
4.3.1. 技术风险
```

**Image**: *(has image_base64)*


---

### Block 52: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 15.001
- **bbox**: `BBox(x0=79, y0=282, x1=553, y1=296)`

**Content**:

```
4.3.2. 业务风险
```

**Image**: *(has image_base64)*


---

### Block 53: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 16.0
- **bbox**: `BBox(x0=36, y0=299, x1=553, y1=312)`

**Content**:

```
5. Attachment 8

```

**Image**: *(has image_base64)*


---

### Block 54: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 27.0
- **bbox**: `BBox(x0=57, y0=314, x1=553, y1=326)`

**Content**:

```
5.1. Attachment1: Formate for xxxx1 8
```

**Image**: *(has image_base64)*


---

### Block 55: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 27.001
- **bbox**: `BBox(x0=57, y0=329, x1=553, y1=342)`

**Content**:

```
5.2. Attachment1: Formate for xxxx2 8
```

**Image**: *(has image_base64)*


---

### Block 56: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 27.002
- **bbox**: `BBox(x0=57, y0=345, x1=553, y1=358)`

**Content**:

```
5.3. Attachment1: Formate for xxxxx3 8
```

**Image**: *(has image_base64)*


---

### Block 57: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 27.003
- **bbox**: `BBox(x0=57, y0=360, x1=553, y1=373)`

**Content**:

```
5.4. Attachment1: Formate for xxxxx4 8
```

**Image**: *(has image_base64)*


---

### Block 58: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 27.004
- **bbox**: `BBox(x0=57, y0=376, x1=553, y1=389)`

**Content**:

```
5.5. Attachment1: Formate for xxxxx5 8
```

**Image**: *(has image_base64)*


---

### Block 59: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 27.005
- **bbox**: `BBox(x0=57, y0=391, x1=553, y1=405)`

**Content**:

```
5.6. Attachment1: Formate for xxxxx6 错误！未定义书签。
```

**Image**: *(has image_base64)*


---

### Block 60: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 27.006
- **bbox**: `BBox(x0=57, y0=407, x1=553, y1=420)`

**Content**:

```
5.7. Attachment1: Formate for xxxx7 错误！未定义书签。
```

**Image**: *(has image_base64)*


---

### Block 61: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 27.007
- **bbox**: `BBox(x0=57, y0=423, x1=553, y1=436)`

**Content**:

```
5.8. Attachment1: Formate for xxxxxx8 错误！未定义书签。
```

**Image**: *(has image_base64)*


---

### Block 62: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 27.008
- **bbox**: `BBox(x0=57, y0=439, x1=547, y1=451)`

**Content**:

```
5.9. Attachment1: Formate for xxxxxx9 错误！未定义书签。
```

**Image**: *(has image_base64)*


---

### Block 63: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 27.009
- **bbox**: `BBox(x0=57, y0=454, x1=547, y1=467)`

**Content**:

```
5.10. Attachment1: Formate for xxxx10 错误！未定义书签。
```

**Image**: *(has image_base64)*


---

### Block 64: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 28.0
- **bbox**: `BBox(x0=36, y0=470, x1=553, y1=483)`

**Content**:

```
6. 总结与展望 ..... 8

```

**Image**: *(has image_base64)*


---

### Block 65: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 2
- **索引**: -999.9952
- **bbox**: `BBox(x0=35, y0=48, x1=113, y1=95)`

**Content**:

```
SMIC

```

**Image**: *(has image_base64)*


---

### Block 66: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 2
- **索引**: 9999.0747
- **bbox**: `BBox(x0=34, y0=747, x1=553, y1=770)`

**Content**:

```
The information contained herein is exclusive property of SIMC, and shall not be distributed, reproduced, or disclosed in whole or in part without priorwritten permission of SMIC

```

**Image**: *(has image_base64)*


---

### Block 67: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 2
- **索引**: 9999.078
- **bbox**: `BBox(x0=35, y0=780, x1=436, y1=792)`

**Content**:

```
According to :SMIC Document Control Procedure;Attachment No.: QR-QUSM-02-2001-002;Rev.:3

```

**Image**: *(has image_base64)*


---

### Block 68: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 2
- **索引**: 9999.078
- **bbox**: `BBox(x0=474, y0=780, x1=518, y1=790)`

**Content**:

```
2026-1-30

```

**Image**: *(has image_base64)*


---

### Block 69: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 3
- **索引**: 2.0
- **bbox**: `BBox(x0=202, y0=108, x1=393, y1=124)`

**Content**:

```
TABLE_placeHOLDER_002
```

**Image**: *(no image)*


---

### Block 70: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 3.0
- **bbox**: `BBox(x0=35, y0=141, x1=226, y1=155)`

**Content**:

```
1. Project background and objectives

```

**Image**: *(has image_base64)*


---

### Block 71: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 8.0
- **bbox**: `BBox(x0=55, y0=156, x1=243, y1=168)`

**Content**:

```
1.1. DCC: Document Control Center
```

**Image**: *(has image_base64)*


---

### Block 72: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 8.001
- **bbox**: `BBox(x0=55, y0=171, x1=425, y1=185)`

**Content**:

```
1.2. DCN: Document Change Notice(for Company Rules and Regulations)
```

**Image**: *(has image_base64)*


---

### Block 73: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 8.002
- **bbox**: `BBox(x0=55, y0=187, x1=273, y1=200)`

**Content**:

```
1.3. DMS: Document Management System
```

**Image**: *(has image_base64)*


---

### Block 74: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 8.003
- **bbox**: `BBox(x0=55, y0=202, x1=196, y1=216)`

**Content**:

```
1.4. Background description
```

**Image**: *(has image_base64)*


---

### Block 75: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 9.0
- **bbox**: `BBox(x0=75, y0=216, x1=554, y1=339)`

**Content**:

```
With the continuous evolution of artificial intelligence technology, large language models (LLM) and multimodal models have demonstrated remarkable capabilities in comprehension, generation, and reasoning. An increasing number of enterprises are beginning to experiment with integrating AI technology into their actual business processes, aiming to enhance information processing efficiency, optimize decision-making quality, and reduce reliance on human experience. Against this backdrop, the focus of AI application has gradually shifted from "model effect demonstration" to "systematic implementation capability". How to embed model capabilities into existing business systems in a stable and controllable manner has become a common concern for both technical and business teams.

```

**Image**: *(has image_base64)*


---

### Block 76: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 15.0
- **bbox**: `BBox(x0=76, y0=340, x1=207, y1=354)`

**Content**:

```
1.4.1. Industry prospects
```

**Image**: *(has image_base64)*


---

### Block 77: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 15.001
- **bbox**: `BBox(x0=77, y0=354, x1=207, y1=367)`

**Content**:

```
1.4.2. Industry prospects2
```

**Image**: *(has image_base64)*


---

### Block 78: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 15.002
- **bbox**: `BBox(x0=77, y0=368, x1=207, y1=381)`

**Content**:

```
1.4.3. Industry prospects3
```

**Image**: *(has image_base64)*


---

### Block 79: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 15.003
- **bbox**: `BBox(x0=77, y0=382, x1=207, y1=396)`

**Content**:

```
1.4.4. Industry prospects4
```

**Image**: *(has image_base64)*


---

### Block 80: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 15.004
- **bbox**: `BBox(x0=77, y0=396, x1=202, y1=409)`

**Content**:

```
1.4.5. Industry prospects
```

**Image**: *(has image_base64)*


---

### Block 81: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 16.0
- **bbox**: `BBox(x0=119, y0=410, x1=456, y1=423)`

**Content**:

```
The current industry as a whole exhibits the following characteristics:

```

**Image**: *(has image_base64)*


---

### Block 82: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 20.0
- **bbox**: `BBox(x0=121, y0=425, x1=552, y1=453)`

**Content**:

```
- The capabilities of pre-trained models have rapidly improved, but there are still differences in scenario generalization
```

**Image**: *(has image_base64)*


---

### Block 83: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 20.001
- **bbox**: `BBox(x0=121, y0=454, x1=552, y1=481)`

**Content**:

```
- The scale of internal data within the enterprise continues to grow, leading to a strong demand for intelligent retrieval and analysis
```

**Image**: *(has image_base64)*


---

### Block 84: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 20.002
- **bbox**: `BBox(x0=121, y0=482, x1=552, y1=509)`

**Content**:

```
- AI systems are gradually evolving from single-point applications towards platformization and servitization
```

**Image**: *(has image_base64)*


---

### Block 85: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 21.0
- **bbox**: `BBox(x0=76, y0=510, x1=195, y1=523)`

**Content**:

```
1.4.6. Main pain points

```

**Image**: *(has image_base64)*


---

### Block 86: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 22.0
- **bbox**: `BBox(x0=118, y0=524, x1=523, y1=538)`

**Content**:

```
In the actual implementation process, common issues include but are not limited to:

```

**Image**: *(has image_base64)*


---

### Block 87: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 26.0
- **bbox**: `BBox(x0=121, y0=540, x1=552, y1=568)`

**Content**:

```
- The data sources are complex, with a coexistence of structured, semi-structured, and unstructured data
```

**Image**: *(has image_base64)*


---

### Block 88: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 26.001
- **bbox**: `BBox(x0=121, y0=571, x1=552, y1=601)`

**Content**:

```
- The coupling between model services and business logic is too high, resulting in poor system maintainability
```

**Image**: *(has image_base64)*


---

### Block 89: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 26.002
- **bbox**: `BBox(x0=121, y0=602, x1=552, y1=631)`

**Content**:

```
- Without a unified evaluation and monitoring mechanism, it is difficult to continuously ensure the effectiveness of the model
```

**Image**: *(has image_base64)*


---

### Block 90: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 27.0
- **bbox**: `BBox(x0=55, y0=633, x1=194, y1=646)`

**Content**:

```
1.5. Construction objectives

```

**Image**: *(has image_base64)*


---

### Block 91: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 31.0
- **bbox**: `BBox(x0=97, y0=647, x1=552, y1=677)`

**Content**:

```
A. The goal of this project is to build an AI application system that is scalable, maintainable, and implementable,
```

**Image**: *(has image_base64)*


---

### Block 92: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 31.001
- **bbox**: `BBox(x0=97, y0=678, x1=467, y1=692)`

**Content**:

```
B. Capable of supporting multiple business scenarios within the enterprise,
```

**Image**: *(has image_base64)*


---

### Block 93: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 3
- **索引**: 31.002
- **bbox**: `BBox(x0=97, y0=693, x1=394, y1=708)`

**Content**:

```
C. Provide a technical foundation for subsequent iterations.
```

**Image**: *(has image_base64)*


---

### Block 94: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 3
- **索引**: -999.9952
- **bbox**: `BBox(x0=35, y0=48, x1=113, y1=94)`

**Content**:

```
SMIC

```

**Image**: *(has image_base64)*


---

### Block 95: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 3
- **索引**: -999.9921
- **bbox**: `BBox(x0=112, y0=79, x1=527, y1=100)`

**Content**:

```
Semiconfuctor Manufacturing International Corporation

```

**Image**: *(has image_base64)*


---

### Block 96: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 3
- **索引**: 9999.0747
- **bbox**: `BBox(x0=34, y0=747, x1=553, y1=770)`

**Content**:

```
The information contained herein is exclusive property of SIMC, and shall not be distributed, reproduced, or disclosed in whole or in part without priorwritten permission of SMIC

```

**Image**: *(has image_base64)*


---

### Block 97: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 3
- **索引**: 9999.078
- **bbox**: `BBox(x0=35, y0=780, x1=436, y1=792)`

**Content**:

```
According to :SMIC Document Control Procedure;Attachment No.: QR-QUSM-02-2001-002;Rev.:3

```

**Image**: *(has image_base64)*


---

### Block 98: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 3
- **索引**: 9999.078
- **bbox**: `BBox(x0=474, y0=780, x1=518, y1=790)`

**Content**:

```
2026-1-30

```

**Image**: *(has image_base64)*


---

### Block 99: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 4
- **索引**: 3.0
- **bbox**: `BBox(x0=35, y0=142, x1=169, y1=155)`
- **标题级别**: 1

**Content**:

```
2. Overall scheme design

```

**Image**: *(has image_base64)*


---

### Block 100: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 4
- **索引**: 4.0
- **bbox**: `BBox(x0=54, y0=156, x1=238, y1=169)`
- **标题级别**: 2

**Content**:

```
2.1. Overview of system architecture

```

**Image**: *(has image_base64)*


---

### Block 101: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 4
- **索引**: 5.0
- **bbox**: `BBox(x0=76, y0=170, x1=554, y1=215)`

**Content**:

```
The system is designed with a layered architecture, encompassing a data layer, a model layer, and an application layer. This design ensures the independence between modules and facilitates the addition of new functional modules in the future.

```

**Image**: *(has image_base64)*


---

### Block 102: image

- **类型**: `image`
- **源类型**: `image`
- **页码**: 4
- **索引**: 6.0
- **bbox**: `BBox(x0=82, y0=219, x1=509, y1=443)`

**Content**:

*(empty)*

**Image**: *(has image_base64)*


---

### Block 103: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 4
- **索引**: 7.0
- **bbox**: `BBox(x0=54, y0=449, x1=153, y1=463)`
- **标题级别**: 2

**Content**:

```
2.2. 技术选型说明

```

**Image**: *(has image_base64)*


---

### Block 104: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 4
- **索引**: 8.0
- **bbox**: `BBox(x0=74, y0=465, x1=198, y1=479)`
- **标题级别**: 3

**Content**:

```
2.2.1. 后端与基础设施

```

**Image**: *(has image_base64)*


---

### Block 105: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 4
- **索引**: 13.0
- **bbox**: `BBox(x0=116, y0=489, x1=232, y1=504)`

**Content**:

```
编程语言：Python
```

**Image**: *(has image_base64)*


---

### Block 106: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 4
- **索引**: 13.001
- **bbox**: `BBox(x0=116, y0=520, x1=237, y1=534)`

**Content**:

```
- 服务框架：FastAPI
```

**Image**: *(has image_base64)*


---

### Block 107: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 4
- **索引**: 13.002
- **bbox**: `BBox(x0=116, y0=550, x1=268, y1=565)`

**Content**:

```
- 模型部署：vLLM/Triton
```

**Image**: *(has image_base64)*


---

### Block 108: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 4
- **索引**: 13.003
- **bbox**: `BBox(x0=116, y0=582, x1=312, y1=597)`

**Content**:

```
- 容器与编排：Docker + Kubernetes
```

**Image**: *(has image_base64)*


---

### Block 109: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 4
- **索引**: 14.0
- **bbox**: `BBox(x0=74, y0=605, x1=162, y1=619)`
- **标题级别**: 3

**Content**:

```
2.2.2. 模型相关

```

**Image**: *(has image_base64)*


---

### Block 110: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 4
- **索引**: 18.0
- **bbox**: `BBox(x0=116, y0=629, x1=239, y1=643)`

**Content**:

```
- 大语言模型 (LLM)
```

**Image**: *(has image_base64)*


---

### Block 111: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 4
- **索引**: 18.001
- **bbox**: `BBox(x0=116, y0=660, x1=256, y1=676)`

**Content**:

```
向量模型 (Embedding)
```

**Image**: *(has image_base64)*


---

### Block 112: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 4
- **索引**: 18.002
- **bbox**: `BBox(x0=116, y0=691, x1=240, y1=705)`

**Content**:

```
- RAG 检索增强生成
```

**Image**: *(has image_base64)*


---

### Block 113: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 4
- **索引**: -999.9952
- **bbox**: `BBox(x0=36, y0=48, x1=113, y1=94)`

**Content**:

```
SMIC

```

**Image**: *(has image_base64)*


---

### Block 114: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 4
- **索引**: -999.9921
- **bbox**: `BBox(x0=112, y0=79, x1=527, y1=100)`

**Content**:

```
Semiconfuctor Manufacturing International Corporation

```

**Image**: *(has image_base64)*


---

### Block 115: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 4
- **索引**: -999.9892
- **bbox**: `BBox(x0=202, y0=108, x1=392, y1=125)`

**Content**:

```
TABLE_placeHOLDER_003
```

**Image**: *(no image)*


---

### Block 116: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 4
- **索引**: 9999.0747
- **bbox**: `BBox(x0=34, y0=747, x1=553, y1=770)`

**Content**:

```
The information contained herein is exclusive property of SIMC, and shall not be distributed, reproduced, or disclosed in whole or in part without priorwritten permission of SMIC

```

**Image**: *(has image_base64)*


---

### Block 117: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 4
- **索引**: 9999.078
- **bbox**: `BBox(x0=35, y0=780, x1=436, y1=792)`

**Content**:

```
According to :SMIC Document Control Procedure;Attachment No.: QR-QUSM-02-2001-002;Rev.:3

```

**Image**: *(has image_base64)*


---

### Block 118: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 5
- **索引**: 3.0
- **bbox**: `BBox(x0=74, y0=141, x1=186, y1=156)`
- **标题级别**: 3

**Content**:

```
2.2.3. 其他模型相关

```

**Image**: *(has image_base64)*


---

### Block 119: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 7.0
- **bbox**: `BBox(x0=116, y0=164, x1=240, y1=179)`

**Content**:

```
- 视觉大模型 (VLM)
```

**Image**: *(has image_base64)*


---

### Block 120: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 7.001
- **bbox**: `BBox(x0=116, y0=196, x1=256, y1=211)`

**Content**:

```
向量模型 (Embedding)
```

**Image**: *(has image_base64)*


---

### Block 121: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 7.002
- **bbox**: `BBox(x0=116, y0=227, x1=240, y1=242)`

**Content**:

```
- RAG 检索增强生成
```

**Image**: *(has image_base64)*


---

### Block 122: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 5
- **索引**: 8.0
- **bbox**: `BBox(x0=54, y0=250, x1=230, y1=264)`
- **标题级别**: 2

**Content**:

```
2.3. Technical selection description

```

**Image**: *(has image_base64)*


---

### Block 123: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 5
- **索引**: 9.0
- **bbox**: `BBox(x0=74, y0=265, x1=244, y1=277)`
- **标题级别**: 3

**Content**:

```
2.3.1. Backend and Infrastructure

```

**Image**: *(has image_base64)*


---

### Block 124: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 14.0
- **bbox**: `BBox(x0=116, y0=280, x1=290, y1=294)`

**Content**:

```
- Programming language: Python
```

**Image**: *(has image_base64)*


---

### Block 125: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 14.001
- **bbox**: `BBox(x0=116, y0=295, x1=274, y1=308)`

**Content**:

```
Service framework: FastAPI
```

**Image**: *(has image_base64)*


---

### Block 126: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 14.002
- **bbox**: `BBox(x0=116, y0=310, x1=305, y1=324)`

**Content**:

```
- Model deployment: vLLM / Triton
```

**Image**: *(has image_base64)*


---

### Block 127: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 14.003
- **bbox**: `BBox(x0=116, y0=326, x1=383, y1=339)`

**Content**:

```
- Containers and orchestration: Docker + Kubernetes
```

**Image**: *(has image_base64)*


---

### Block 128: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 5
- **索引**: 15.0
- **bbox**: `BBox(x0=74, y0=340, x1=182, y1=353)`
- **标题级别**: 3

**Content**:

```
2.3.2. Model-related

```

**Image**: *(has image_base64)*


---

### Block 129: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 19.0
- **bbox**: `BBox(x0=116, y0=355, x1=286, y1=370)`

**Content**:

```
Large Language Model (LLM)
```

**Image**: *(has image_base64)*


---

### Block 130: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 19.001
- **bbox**: `BBox(x0=116, y0=371, x1=269, y1=386)`

**Content**:

```
- Vector model (Embedding)
```

**Image**: *(has image_base64)*


---

### Block 131: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 19.002
- **bbox**: `BBox(x0=116, y0=386, x1=327, y1=401)`

**Content**:

```
RAG: Retrieval Augmented Generation
```

**Image**: *(has image_base64)*


---

### Block 132: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 5
- **索引**: 20.0
- **bbox**: `BBox(x0=74, y0=401, x1=211, y1=413)`
- **标题级别**: 3

**Content**:

```
2.3.3. Other model-related

```

**Image**: *(has image_base64)*


---

### Block 133: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 24.0
- **bbox**: `BBox(x0=116, y0=416, x1=271, y1=430)`

**Content**:

```
Visual Large Model (VLM)
```

**Image**: *(has image_base64)*


---

### Block 134: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 24.001
- **bbox**: `BBox(x0=116, y0=432, x1=269, y1=446)`

**Content**:

```
- Vector model (Embedding)
```

**Image**: *(has image_base64)*


---

### Block 135: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 24.002
- **bbox**: `BBox(x0=116, y0=447, x1=327, y1=461)`

**Content**:

```
RAG: Retrieval Augmented Generation
```

**Image**: *(has image_base64)*


---

### Block 136: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 5
- **索引**: 25.0
- **bbox**: `BBox(x0=74, y0=462, x1=245, y1=474)`
- **标题级别**: 3

**Content**:

```
2.3.4. Backend and Infrastructure

```

**Image**: *(has image_base64)*


---

### Block 137: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 30.0
- **bbox**: `BBox(x0=116, y0=476, x1=289, y1=491)`

**Content**:

```
- Programming language: Python
```

**Image**: *(has image_base64)*


---

### Block 138: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 30.001
- **bbox**: `BBox(x0=116, y0=491, x1=274, y1=505)`

**Content**:

```
Service framework: FastAPI
```

**Image**: *(has image_base64)*


---

### Block 139: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 30.002
- **bbox**: `BBox(x0=116, y0=507, x1=305, y1=522)`

**Content**:

```
Model deployment: vLLM / Triton
```

**Image**: *(has image_base64)*


---

### Block 140: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 30.003
- **bbox**: `BBox(x0=116, y0=523, x1=383, y1=536)`

**Content**:

```
- Containers and orchestration: Docker + Kubernetes
```

**Image**: *(has image_base64)*


---

### Block 141: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 5
- **索引**: 31.0
- **bbox**: `BBox(x0=74, y0=538, x1=182, y1=550)`
- **标题级别**: 3

**Content**:

```
2.3.5. Model-related

```

**Image**: *(has image_base64)*


---

### Block 142: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 35.0
- **bbox**: `BBox(x0=116, y0=553, x1=286, y1=567)`

**Content**:

```
Large Language Model (LLM)
```

**Image**: *(has image_base64)*


---

### Block 143: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 35.001
- **bbox**: `BBox(x0=116, y0=568, x1=269, y1=582)`

**Content**:

```
- Vector model (Embedding)
```

**Image**: *(has image_base64)*


---

### Block 144: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 35.002
- **bbox**: `BBox(x0=116, y0=583, x1=327, y1=597)`

**Content**:

```
RAG: Retrieval Augmented Generation
```

**Image**: *(has image_base64)*


---

### Block 145: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 5
- **索引**: 36.0
- **bbox**: `BBox(x0=74, y0=598, x1=211, y1=611)`
- **标题级别**: 3

**Content**:

```
2.3.6. Other model-related

```

**Image**: *(has image_base64)*


---

### Block 146: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 39.0
- **bbox**: `BBox(x0=116, y0=613, x1=271, y1=627)`

**Content**:

```
Visual Large Model (VLM)
```

**Image**: *(has image_base64)*


---

### Block 147: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 39.001
- **bbox**: `BBox(x0=116, y0=629, x1=269, y1=643)`

**Content**:

```
- Vector model (Embedding)
```

**Image**: *(has image_base64)*


---

### Block 148: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 5
- **索引**: 40.0
- **bbox**: `BBox(x0=74, y0=644, x1=414, y1=657)`
- **标题级别**: 3

**Content**:

```
2.3.7. RAG: Retrieval Augmented GenerationOther model-related

```

**Image**: *(has image_base64)*


---

### Block 149: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 44.0
- **bbox**: `BBox(x0=116, y0=658, x1=271, y1=672)`

**Content**:

```
Visual Large Model (VLM)
```

**Image**: *(has image_base64)*


---

### Block 150: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 44.001
- **bbox**: `BBox(x0=116, y0=673, x1=269, y1=687)`

**Content**:

```
- Vector model (Embedding)
```

**Image**: *(has image_base64)*


---

### Block 151: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 44.002
- **bbox**: `BBox(x0=116, y0=689, x1=327, y1=703)`

**Content**:

```
RAG: Retrieval Augmented Generation
```

**Image**: *(has image_base64)*


---

### Block 152: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 5
- **索引**: 45.0
- **bbox**: `BBox(x0=74, y0=703, x1=211, y1=716)`
- **标题级别**: 3

**Content**:

```
2.3.8. Other model-related

```

**Image**: *(has image_base64)*


---

### Block 153: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 48.0
- **bbox**: `BBox(x0=116, y0=719, x1=271, y1=733)`

**Content**:

```
Visual Large Model (VLM)
```

**Image**: *(has image_base64)*


---

### Block 154: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 48.001
- **bbox**: `BBox(x0=116, y0=734, x1=269, y1=748)`

**Content**:

```
- Vector model (Embedding)
```

**Image**: *(has image_base64)*


---

### Block 155: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 5
- **索引**: 49.0
- **bbox**: `BBox(x0=34, y0=748, x1=553, y1=770)`

**Content**:

```
The information contained herein is exclusive property of SIMC, and shall not be distributed, reproduced, or disclosed in whole or in part without prior written permission of SMIC

```

**Image**: *(has image_base64)*


---

### Block 156: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 5
- **索引**: -999.9952
- **bbox**: `BBox(x0=35, y0=48, x1=113, y1=94)`

**Content**:

```
SMIC

```

**Image**: *(has image_base64)*


---

### Block 157: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 5
- **索引**: -999.9921
- **bbox**: `BBox(x0=112, y0=79, x1=528, y1=100)`

**Content**:

```
Semiconfuctor Manufacturing International Corporation

```

**Image**: *(has image_base64)*


---

### Block 158: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 5
- **索引**: -999.9892
- **bbox**: `BBox(x0=202, y0=108, x1=393, y1=125)`

**Content**:

```
TABLE_placeHOLDER_004
```

**Image**: *(no image)*


---

### Block 159: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 5
- **索引**: 9999.078
- **bbox**: `BBox(x0=35, y0=780, x1=436, y1=792)`

**Content**:

```
According to :SMIC Document Control Procedure;Attachment No.: QR-QUSM-02-2001-002;Rev.:3

```

**Image**: *(has image_base64)*


---

### Block 160: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 5
- **索引**: 9999.078
- **bbox**: `BBox(x0=474, y0=780, x1=518, y1=790)`

**Content**:

```
2026-1-30

```

**Image**: *(has image_base64)*


---

### Block 161: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 6
- **索引**: 5.0
- **bbox**: `BBox(x0=116, y0=142, x1=327, y1=157)`

**Content**:

```
RAG: Retrieval Augmented Generation
```

**Image**: *(has image_base64)*


---

### Block 162: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 6
- **索引**: 5.001
- **bbox**: `BBox(x0=116, y0=158, x1=275, y1=172)`

**Content**:

```
Service framework: FastAPI
```

**Image**: *(has image_base64)*


---

### Block 163: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 6
- **索引**: 6.0
- **bbox**: `BBox(x0=35, y0=190, x1=178, y1=202)`
- **标题级别**: 1

**Content**:

```
3. Core functional modules

```

**Image**: *(has image_base64)*


---

### Block 164: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 6
- **索引**: 7.0
- **bbox**: `BBox(x0=54, y0=205, x1=553, y1=235)`

**Content**:

```
3.1. All documents generated by function departments should be named according to the below-mentioned categories of documents.

```

**Image**: *(has image_base64)*


---

### Block 165: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 6
- **索引**: 8.0
- **bbox**: `BBox(x0=75, y0=236, x1=174, y1=248)`
- **标题级别**: 3

**Content**:

```
3.1.1. Data Source

```

**Image**: *(has image_base64)*


---

### Block 166: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 6
- **索引**: 9.0
- **bbox**: `BBox(x0=104, y0=252, x1=280, y1=265)`

**Content**:

```
A. Equipment pperation instruction

```

**Image**: *(has image_base64)*


---

### Block 167: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 6
- **索引**: 10.0
- **bbox**: `BBox(x0=213, y0=274, x1=403, y1=290)`

**Content**:

```
TABLE_placeHOLDER_006
```

**Image**: *(no image)*


---

### Block 168: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 6
- **索引**: 11.0
- **bbox**: `BBox(x0=104, y0=350, x1=207, y1=364)`

**Content**:

```
B. Other documents

```

**Image**: *(has image_base64)*


---

### Block 169: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 6
- **索引**: 12.0
- **bbox**: `BBox(x0=213, y0=372, x1=403, y1=390)`

**Content**:

```
TABLE_placeHOLDER_007
```

**Image**: *(no image)*


---

### Block 170: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 6
- **索引**: 13.0
- **bbox**: `BBox(x0=74, y0=449, x1=306, y1=463)`

**Content**:

```
3.1.2. All documents generated by function de

```

**Image**: *(has image_base64)*


---

### Block 171: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 6
- **索引**: 14.0
- **bbox**: `BBox(x0=75, y0=463, x1=258, y1=476)`

**Content**:

```
3.1.3. 数据处理模块包括以下流程

```

**Image**: *(has image_base64)*


---

### Block 172: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 6
- **索引**: 18.0
- **bbox**: `BBox(x0=97, y0=478, x1=303, y1=492)`

**Content**:

```
- 清洗无效数据，去除空值与重复数据
```

**Image**: *(has image_base64)*


---

### Block 173: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 6
- **索引**: 18.001
- **bbox**: `BBox(x0=98, y0=494, x1=246, y1=508)`

**Content**:

```
- 结构化与切分 (Chunking)
```

**Image**: *(has image_base64)*


---

### Block 174: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 6
- **索引**: 18.002
- **bbox**: `BBox(x0=97, y0=509, x1=327, y1=523)`

**Content**:

```
- 向量化与索引构建，用于快速检索和匹配
```

**Image**: *(has image_base64)*


---

### Block 175: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 6
- **索引**: 19.0
- **bbox**: `BBox(x0=54, y0=525, x1=153, y1=539)`
- **标题级别**: 2

**Content**:

```
3.2. 模型服务模块

```

**Image**: *(has image_base64)*


---

### Block 176: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 6
- **索引**: 20.0
- **bbox**: `BBox(x0=75, y0=540, x1=161, y1=554)`
- **标题级别**: 3

**Content**:

```
3.2.1. 推理服务

```

**Image**: *(has image_base64)*


---

### Block 177: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 6
- **索引**: 21.0
- **bbox**: `BBox(x0=97, y0=556, x1=553, y1=586)`

**Content**:

```
模型通过统一的API服务对外提供能力，支持高并发和流式输出，以满足业务实时性要求。

```

**Image**: *(has image_base64)*


---

### Block 178: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 6
- **索引**: 22.0
- **bbox**: `BBox(x0=74, y0=587, x1=185, y1=602)`
- **标题级别**: 3

**Content**:

```
3.2.2. 模型更新策略

```

**Image**: *(has image_base64)*


---

### Block 179: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 6
- **索引**: 25.0
- **bbox**: `BBox(x0=116, y0=613, x1=305, y1=628)`

**Content**:

```
- 支持模型热更新，避免服务中断
```

**Image**: *(has image_base64)*


---

### Block 180: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 6
- **索引**: 25.001
- **bbox**: `BBox(x0=116, y0=645, x1=373, y1=661)`

**Content**:

```
- 支持多版本并行部署，便于 A/B 测试和回滚
```

**Image**: *(has image_base64)*


---

### Block 181: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 6
- **索引**: 26.0
- **bbox**: `BBox(x0=54, y0=671, x1=141, y1=684)`
- **标题级别**: 2

**Content**:

```
3.3. 应用层模块

```

**Image**: *(has image_base64)*


---

### Block 182: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 6
- **索引**: 27.0
- **bbox**: `BBox(x0=74, y0=687, x1=185, y1=700)`
- **标题级别**: 3

**Content**:

```
3.3.1. 典型应用场景

```

**Image**: *(has image_base64)*


---

### Block 183: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 6
- **索引**: 28.0
- **bbox**: `BBox(x0=116, y0=711, x1=208, y1=726)`

**Content**:

```
- 智能问答助手

```

**Image**: *(has image_base64)*


---

### Block 184: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 6
- **索引**: -999.9952
- **bbox**: `BBox(x0=35, y0=48, x1=111, y1=92)`

**Content**:

```
SMIC

```

**Image**: *(has image_base64)*


---

### Block 185: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 6
- **索引**: -999.9921
- **bbox**: `BBox(x0=112, y0=79, x1=527, y1=100)`

**Content**:

```
Semiconfuctor Manufacturing International Corporation

```

**Image**: *(has image_base64)*


---

### Block 186: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 6
- **索引**: -999.9892
- **bbox**: `BBox(x0=202, y0=108, x1=393, y1=124)`

**Content**:

```
TABLE_placeHOLDER_005
```

**Image**: *(no image)*


---

### Block 187: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 6
- **索引**: 9999.0747
- **bbox**: `BBox(x0=34, y0=747, x1=553, y1=770)`

**Content**:

```
The information contained herein is exclusive property of SIMC, and shall not be distributed, reproduced, or disclosed in whole or in part without priorwritten permission of SMIC

```

**Image**: *(has image_base64)*


---

### Block 188: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 6
- **索引**: 9999.078
- **bbox**: `BBox(x0=35, y0=780, x1=436, y1=792)`

**Content**:

```
According to :SMIC Document Control Procedure;Attachment No.: QR-QUSM-02-2001-002;Rev.:3

```

**Image**: *(has image_base64)*


---

### Block 189: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 7
- **索引**: 5.0
- **bbox**: `BBox(x0=116, y0=149, x1=222, y1=163)`

**Content**:

```
文档检索与总结
```

**Image**: *(has image_base64)*


---

### Block 190: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 7
- **索引**: 5.001
- **bbox**: `BBox(x0=116, y0=182, x1=210, y1=196)`

**Content**:

```
业务辅助决策
```

**Image**: *(has image_base64)*


---

### Block 191: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 7
- **索引**: 6.0
- **bbox**: `BBox(x0=74, y0=207, x1=174, y1=222)`
- **标题级别**: 3

**Content**:

```
3.3.2. 权限与安全

```

**Image**: *(has image_base64)*


---

### Block 192: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 7
- **索引**: 10.0
- **bbox**: `BBox(x0=116, y0=232, x1=210, y1=247)`

**Content**:

```
用户身份鉴权
```

**Image**: *(has image_base64)*


---

### Block 193: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 7
- **索引**: 10.001
- **bbox**: `BBox(x0=116, y0=265, x1=245, y1=280)`

**Content**:

```
- 请求审计与日志记录
```

**Image**: *(has image_base64)*


---

### Block 194: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 7
- **索引**: 10.002
- **bbox**: `BBox(x0=116, y0=299, x1=208, y1=312)`

**Content**:

```
数据访问控制
```

**Image**: *(has image_base64)*


---

### Block 195: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 7
- **索引**: 11.0
- **bbox**: `BBox(x0=34, y0=350, x1=246, y1=364)`
- **标题级别**: 1

**Content**:

```
4. 4. Implementation plan and milestones

```

**Image**: *(has image_base64)*


---

### Block 196: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 7
- **索引**: 12.0
- **bbox**: `BBox(x0=54, y0=376, x1=269, y1=389)`
- **标题级别**: 2

**Content**:

```
4.1. Categories and hierarchy of documents

```

**Image**: *(has image_base64)*


---

### Block 197: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 7
- **索引**: 13.0
- **bbox**: `BBox(x0=174, y0=397, x1=365, y1=413)`

**Content**:

```
TABLE_placeHOLDER_009
```

**Image**: *(no image)*


---

### Block 198: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 7
- **索引**: 14.0
- **bbox**: `BBox(x0=54, y0=533, x1=152, y1=546)`
- **标题级别**: 2

**Content**:

```
4.2. 实施阶段划分

```

**Image**: *(has image_base64)*


---

### Block 199: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 7
- **索引**: 15.0
- **bbox**: `BBox(x0=174, y0=555, x1=365, y1=572)`

**Content**:

```
TABLE_placeHOLDER_010
```

**Image**: *(no image)*


---

### Block 200: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 7
- **索引**: 16.0
- **bbox**: `BBox(x0=54, y0=691, x1=141, y1=704)`
- **标题级别**: 2

**Content**:

```
4.3. 风险与应对

```

**Image**: *(has image_base64)*


---

### Block 201: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 7
- **索引**: 17.0
- **bbox**: `BBox(x0=74, y0=707, x1=161, y1=720)`
- **标题级别**: 3

**Content**:

```
4.3.1. 技术风险

```

**Image**: *(has image_base64)*


---

### Block 202: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 7
- **索引**: 18.0
- **bbox**: `BBox(x0=116, y0=732, x1=354, y1=745)`

**Content**:

```
- 模型效果不稳定 \rightarrow 引入评估与回滚机制

```

**Image**: *(has image_base64)*


---

### Block 203: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 7
- **索引**: 19.0
- **bbox**: `BBox(x0=34, y0=748, x1=553, y1=770)`

**Content**:

```
The information contained herein is exclusive property of SIMC, and shall not be distributed, reproduced, or disclosed in whole or in part without prior written permission of SMIC

```

**Image**: *(has image_base64)*


---

### Block 204: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 7
- **索引**: -999.9952
- **bbox**: `BBox(x0=35, y0=48, x1=113, y1=94)`

**Content**:

```
SMIC

```

**Image**: *(has image_base64)*


---

### Block 205: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 7
- **索引**: -999.9921
- **bbox**: `BBox(x0=112, y0=79, x1=528, y1=100)`

**Content**:

```
Semiconfuctor Manufacturing International Corporation

```

**Image**: *(has image_base64)*


---

### Block 206: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 7
- **索引**: -999.9892
- **bbox**: `BBox(x0=202, y0=108, x1=393, y1=125)`

**Content**:

```
TABLE_placeHOLDER_008
```

**Image**: *(no image)*


---

### Block 207: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 7
- **索引**: 9999.078
- **bbox**: `BBox(x0=35, y0=780, x1=436, y1=791)`

**Content**:

```
According to :SMIC Document Control Procedure;Attachment No.: QR-QUSM-02-2001-002;Rev.:3

```

**Image**: *(has image_base64)*


---

### Block 208: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 7
- **索引**: 9999.078
- **bbox**: `BBox(x0=474, y0=780, x1=518, y1=790)`

**Content**:

```
2026-1-30

```

**Image**: *(has image_base64)*


---

### Block 209: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 8
- **索引**: 3.0
- **bbox**: `BBox(x0=116, y0=149, x1=379, y1=163)`

**Content**:

```
- 系统性能瓶颈 \rightarrow 采用分布式部署与负载均衡

```

**Image**: *(has image_base64)*


---

### Block 210: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 8
- **索引**: 4.0
- **bbox**: `BBox(x0=74, y0=174, x1=163, y1=189)`
- **标题级别**: 3

**Content**:

```
4.3.2. 业务风险

```

**Image**: *(has image_base64)*


---

### Block 211: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 8
- **索引**: 7.0
- **bbox**: `BBox(x0=116, y0=200, x1=379, y1=214)`

**Content**:

```
- 需求变更频繁 \rightarrow 采用模块化设计与灵活迭代
```

**Image**: *(has image_base64)*


---

### Block 212: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 8
- **索引**: 7.001
- **bbox**: `BBox(x0=116, y0=232, x1=367, y1=247)`

**Content**:

```
数据安全问题 \rightarrow 强化访问控制和日志审计
```

**Image**: *(has image_base64)*


---

### Block 213: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 8
- **索引**: 8.0
- **bbox**: `BBox(x0=35, y0=274, x1=116, y1=285)`
- **标题级别**: 1

**Content**:

```
5. Attachment

```

**Image**: *(has image_base64)*


---

### Block 214: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 8
- **索引**: 14.0
- **bbox**: `BBox(x0=55, y0=287, x1=246, y1=301)`

**Content**:

```
5.1. Attachment1: Formate for xxxxxx1
```

**Image**: *(has image_base64)*


---

### Block 215: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 8
- **索引**: 14.001
- **bbox**: `BBox(x0=55, y0=302, x1=247, y1=316)`

**Content**:

```
5.2. Attachment1: Formate for xxxxxx2
```

**Image**: *(has image_base64)*


---

### Block 216: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 8
- **索引**: 14.002
- **bbox**: `BBox(x0=55, y0=318, x1=246, y1=332)`

**Content**:

```
5.3. Attachment1: Formate for xxxxxx3
```

**Image**: *(has image_base64)*


---

### Block 217: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 8
- **索引**: 14.003
- **bbox**: `BBox(x0=55, y0=334, x1=246, y1=347)`

**Content**:

```
5.4. Attachment1: Formate for xxxxxx4
```

**Image**: *(has image_base64)*


---

### Block 218: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 8
- **索引**: 14.004
- **bbox**: `BBox(x0=55, y0=349, x1=246, y1=363)`

**Content**:

```
5.5. Attachment1: Formate for xxxxxx5
```

**Image**: *(has image_base64)*


---

### Block 219: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 8
- **索引**: 15.0
- **bbox**: `BBox(x0=35, y0=381, x1=120, y1=395)`
- **标题级别**: 1

**Content**:

```
6. 总结与展望

```

**Image**: *(has image_base64)*


---

### Block 220: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 8
- **索引**: 16.0
- **bbox**: `BBox(x0=55, y0=398, x1=207, y1=412)`
- **标题级别**: 2

**Content**:

```
6.1. Effective period of TECN

```

**Image**: *(has image_base64)*


---

### Block 221: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 8
- **索引**: 17.0
- **bbox**: `BBox(x0=55, y0=423, x1=553, y1=453)`

**Content**:

```
SMIC document security levels are categorized accounting to the security control level's defined in "CR-GWNL-01-1001 SMIC Classified Information Protection Policy (CIPP)" as follows

```

**Image**: *(has image_base64)*


---

### Block 222: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 8
- **索引**: 18.0
- **bbox**: `BBox(x0=221, y0=462, x1=373, y1=477)`

**Content**:

```
Security B-SMIC Confidential

```

**Image**: *(has image_base64)*


---

### Block 223: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 8
- **索引**: 19.0
- **bbox**: `BBox(x0=224, y0=487, x1=365, y1=502)`

**Content**:

```
Security C-SMIC Restricted

```

**Image**: *(has image_base64)*


---

### Block 224: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 8
- **索引**: 20.0
- **bbox**: `BBox(x0=55, y0=512, x1=207, y1=526)`
- **标题级别**: 2

**Content**:

```
6.2. Effective period of TECN

```

**Image**: *(has image_base64)*


---

### Block 225: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 8
- **索引**: 25.0
- **bbox**: `BBox(x0=75, y0=528, x1=376, y1=542)`

**Content**:

```
A. Document format should follow the requirements sign-off
```

**Image**: *(has image_base64)*


---

### Block 226: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 8
- **索引**: 25.001
- **bbox**: `BBox(x0=75, y0=544, x1=391, y1=557)`

**Content**:

```
B. Document sign-off should follow the requirements in item 20
```

**Image**: *(has image_base64)*


---

### Block 227: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 8
- **索引**: 25.002
- **bbox**: `BBox(x0=75, y0=559, x1=439, y1=573)`

**Content**:

```
C. Document access authority should follow the requirements in item 18.2
```

**Image**: *(has image_base64)*


---

### Block 228: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 8
- **索引**: 25.003
- **bbox**: `BBox(x0=76, y0=575, x1=431, y1=589)`

**Content**:

```
D. Document effectiveness cycle time should be within 14 working days
```

**Image**: *(has image_base64)*


---

### Block 229: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 8
- **索引**: 26.0
- **bbox**: `BBox(x0=54, y0=590, x1=553, y1=635)`

**Content**:

```
6.3. All documents generated by function departments should be named according to the below-mentioned categories of documents for example,"SMIC Document Control Procedure" Document title naming rules are follows:

```

**Image**: *(has image_base64)*


---

### Block 230: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 8
- **索引**: 27.0
- **bbox**: `BBox(x0=74, y0=637, x1=192, y1=650)`
- **标题级别**: 3

**Content**:

```
6.3.1. FAB documents

```

**Image**: *(has image_base64)*


---

### Block 231: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 8
- **索引**: 28.0
- **bbox**: `BBox(x0=98, y0=652, x1=279, y1=666)`

**Content**:

```
A. Equipment operation instruction

```

**Image**: *(has image_base64)*


---

### Block 232: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 8
- **索引**: 29.0
- **bbox**: `BBox(x0=202, y0=675, x1=394, y1=692)`

**Content**:

```
TABLE_placeHOLDER_012
```

**Image**: *(no image)*


---

### Block 233: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 8
- **索引**: -999.9952
- **bbox**: `BBox(x0=35, y0=48, x1=113, y1=94)`

**Content**:

```
SMIC

```

**Image**: *(has image_base64)*


---

### Block 234: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 8
- **索引**: -999.9921
- **bbox**: `BBox(x0=112, y0=79, x1=527, y1=100)`

**Content**:

```
Semiconfuctor Manufacturing International Corporation

```

**Image**: *(has image_base64)*


---

### Block 235: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 8
- **索引**: -999.9892
- **bbox**: `BBox(x0=202, y0=108, x1=392, y1=125)`

**Content**:

```
TABLE_placeHOLDER_011
```

**Image**: *(no image)*


---

### Block 236: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 8
- **索引**: 9999.0747
- **bbox**: `BBox(x0=34, y0=747, x1=553, y1=770)`

**Content**:

```
The information contained herein is exclusive property of SIMC, and shall not be distributed, reproduced, or disclosed in whole or in part without priorwritten permission of SMIC

```

**Image**: *(has image_base64)*


---

### Block 237: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 8
- **索引**: 9999.078
- **bbox**: `BBox(x0=35, y0=780, x1=436, y1=792)`

**Content**:

```
According to :SMIC Document Control Procedure;Attachment No.: QR-QUSM-02-2001-002;Rev.:3

```

**Image**: *(has image_base64)*


---

### Block 238: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 9
- **索引**: 3.0
- **bbox**: `BBox(x0=98, y0=190, x1=205, y1=203)`

**Content**:

```
B. Other documents

```

**Image**: *(has image_base64)*


---

### Block 239: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 9
- **索引**: 4.0
- **bbox**: `BBox(x0=203, y0=212, x1=393, y1=229)`

**Content**:

```
TABLE_placeHOLDER_014
```

**Image**: *(no image)*


---

### Block 240: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 9
- **索引**: 5.0
- **bbox**: `BBox(x0=74, y0=364, x1=246, y1=377)`
- **标题级别**: 3

**Content**:

```
6.3.2. Non-FAB documents/DCN

```

**Image**: *(has image_base64)*


---

### Block 241: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 9
- **索引**: 6.0
- **bbox**: `BBox(x0=96, y0=380, x1=299, y1=394)`

**Content**:

```
(E.g. Mask Operation, RE lab, Facility, etc)

```

**Image**: *(has image_base64)*


---

### Block 242: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 9
- **索引**: 7.0
- **bbox**: `BBox(x0=204, y0=402, x1=395, y1=419)`

**Content**:

```
TABLE_placeHOLDER_015
```

**Image**: *(no image)*


---

### Block 243: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 9
- **索引**: 8.0
- **bbox**: `BBox(x0=74, y0=537, x1=530, y1=583)`

**Content**:

```
6.3.3. Technology development related documents naming rule is defined in "TD-GENL-01-2047 SMIC Design Rules Template" and "TD-GENL-01-2064 SMIC PDK Document Title and Attached File Naming Rule"

```

**Image**: *(has image_base64)*


---

### Block 244: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 9
- **索引**: -999.9952
- **bbox**: `BBox(x0=35, y0=48, x1=113, y1=94)`

**Content**:

```
SMIC

```

**Image**: *(has image_base64)*


---

### Block 245: header

- **类型**: `header`
- **源类型**: `header`
- **页码**: 9
- **索引**: -999.9921
- **bbox**: `BBox(x0=112, y0=79, x1=528, y1=100)`

**Content**:

```
Semiconfuctor Manufacturing International Corporation

```

**Image**: *(has image_base64)*


---

### Block 246: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 9
- **索引**: -999.9893
- **bbox**: `BBox(x0=203, y0=107, x1=395, y1=124)`

**Content**:

```
TABLE_placeHOLDER_013
```

**Image**: *(no image)*


---

### Block 247: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 9
- **索引**: 9999.0747
- **bbox**: `BBox(x0=34, y0=747, x1=553, y1=770)`

**Content**:

```
The information contained herein is exclusive property of SIMC, and shall not be distributed, reproduced, or disclosed in whole or in part without priorwritten permission of SMIC

```

**Image**: *(has image_base64)*


---

### Block 248: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 9
- **索引**: 9999.078
- **bbox**: `BBox(x0=35, y0=780, x1=436, y1=792)`

**Content**:

```
According to :SMIC Document Control Procedure;Attachment No.: QR-QUSM-02-2001-002;Rev.:3

```

**Image**: *(has image_base64)*


---

### Block 249: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 9
- **索引**: 9999.078
- **bbox**: `BBox(x0=474, y0=780, x1=518, y1=790)`

**Content**:

```
2026-1-30

```

**Image**: *(has image_base64)*


---
