# MinerU Parser Debug Output

**生成时间**: 2026-07-29T18:25:04.021412

**Block 总数**: 26


---

## 类型统计

| 类型 | 数量 |
|------|------|
| list | 15 |
| text | 9 |
| title | 2 |

---

## Block 详情

### Block 0: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 2.0
- **bbox**: `BBox(x0=42, y0=139, x1=310, y1=154)`

**Content**:

```
1. Title: SMIC Raw Material Abnormal Handing O.I.
```

**Image**: *(has image_base64)*


---

### Block 1: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 2.001
- **bbox**: `BBox(x0=42, y0=167, x1=109, y1=181)`

**Content**:

```
2. Purpose:
```

**Image**: *(has image_base64)*


---

### Block 2: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 5.0
- **bbox**: `BBox(x0=63, y0=183, x1=549, y1=211)`

**Content**:

```
2.1. To establish SMIC internal procedure for periodic performance evaluation and communication on with Class-I
```

**Image**: *(has image_base64)*


---

### Block 3: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 5.001
- **bbox**: `BBox(x0=63, y0=214, x1=547, y1=258)`

**Content**:

```
2.2. This document defines QCDESE evaluation procedures including scoring rules, internal review process, approval of final report, publication, and communication post-publication for SMIC Class-I
```

**Image**: *(has image_base64)*


---

### Block 4: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 6.0
- **bbox**: `BBox(x0=42, y0=272, x1=506, y1=288)`

**Content**:

```
3. Scope: Applies to all SMIC group company and all SMIC Class-I Suppliers(Raw Material).

```

**Image**: *(has image_base64)*


---

### Block 5: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 1
- **索引**: 7.0
- **bbox**: `BBox(x0=104, y0=296, x1=293, y1=312)`

**Content**:

```
TABLE_placeHOLDER_001
```

**Image**: *(no image)*


---

### Block 6: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 8.0
- **bbox**: `BBox(x0=42, y0=574, x1=138, y1=587)`

**Content**:

```
4. Nomenclature:

```

**Image**: *(has image_base64)*


---

### Block 7: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 17.0
- **bbox**: `BBox(x0=63, y0=590, x1=226, y1=603)`

**Content**:

```
4.1. CSL: Chemical Safety Label.
```

**Image**: *(has image_base64)*


---

### Block 8: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 17.001
- **bbox**: `BBox(x0=63, y0=605, x1=258, y1=619)`

**Content**:

```
4.2. MSDS: Meterial Safety Data Sheet.
```

**Image**: *(has image_base64)*


---

### Block 9: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 17.002
- **bbox**: `BBox(x0=63, y0=621, x1=226, y1=634)`

**Content**:

```
4.3. CSL: Chemical Safety Label.
```

**Image**: *(has image_base64)*


---

### Block 10: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 17.003
- **bbox**: `BBox(x0=63, y0=636, x1=258, y1=650)`

**Content**:

```
4.4. MSDS: Meterial Safety Data Sheet.
```

**Image**: *(has image_base64)*


---

### Block 11: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 17.004
- **bbox**: `BBox(x0=63, y0=652, x1=226, y1=666)`

**Content**:

```
4.5. CSL: Chemical Safety Label.
```

**Image**: *(has image_base64)*


---

### Block 12: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 17.005
- **bbox**: `BBox(x0=63, y0=667, x1=258, y1=681)`

**Content**:

```
4.6. MSDS: Meterial Safety Data Sheet.
```

**Image**: *(has image_base64)*


---

### Block 13: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 17.006
- **bbox**: `BBox(x0=63, y0=683, x1=226, y1=697)`

**Content**:

```
4.7. CSL: Chemical Safety Label.
```

**Image**: *(has image_base64)*


---

### Block 14: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 1
- **索引**: 17.007
- **bbox**: `BBox(x0=63, y0=698, x1=258, y1=713)`

**Content**:

```
4.8. MSDS: Meterial Safety Data Sheet.
```

**Image**: *(has image_base64)*


---

### Block 15: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 0.0
- **bbox**: `BBox(x0=42, y0=126, x1=167, y1=140)`

**Content**:

```
5. 异常事件处理流程：

```

**Image**: *(has image_base64)*


---

### Block 16: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 1.0
- **bbox**: `BBox(x0=63, y0=142, x1=369, y1=157)`

**Content**:

```
5.1. 原材料检验过程中出发 OOS 或其他检验异常处理流程

```

**Image**: *(has image_base64)*


---

### Block 17: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 2
- **索引**: 2.0
- **bbox**: `BBox(x0=198, y0=166, x1=390, y1=183)`

**Content**:

```
TABLE_placeHOLDER_002
```

**Image**: *(no image)*


---

### Block 18: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 3
- **索引**: 0.0
- **bbox**: `BBox(x0=63, y0=126, x1=149, y1=142)`
- **标题级别**: 2

**Content**:

```
5.2. IQND流程：

```

**Image**: *(has image_base64)*


---

### Block 19: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 3
- **索引**: 1.0
- **bbox**: `BBox(x0=199, y0=150, x1=390, y1=167)`

**Content**:

```
TABLE_placeHOLDER_003
```

**Image**: *(no image)*


---

### Block 20: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 4
- **索引**: 0.0
- **bbox**: `BBox(x0=63, y0=126, x1=148, y1=141)`
- **标题级别**: 2

**Content**:

```
5.3. IQND流程：

```

**Image**: *(has image_base64)*


---

### Block 21: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 4
- **索引**: 1.0
- **bbox**: `BBox(x0=198, y0=150, x1=390, y1=167)`

**Content**:

```
TABLE_placeHOLDER_004
```

**Image**: *(no image)*


---

### Block 22: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 5
- **索引**: 0.0
- **bbox**: `BBox(x0=42, y0=127, x1=155, y1=142)`

**Content**:

```
6. Project background

```

**Image**: *(has image_base64)*


---

### Block 23: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 4.0
- **bbox**: `BBox(x0=63, y0=146, x1=249, y1=159)`

**Content**:

```
6.1. DCC: Document Control Center
```

**Image**: *(has image_base64)*


---

### Block 24: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 4.001
- **bbox**: `BBox(x0=62, y0=177, x1=431, y1=191)`

**Content**:

```
6.2. DCN: Document Change Notice(for Company Rules and Regulations)
```

**Image**: *(has image_base64)*


---

### Block 25: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 5
- **索引**: 4.002
- **bbox**: `BBox(x0=63, y0=193, x1=279, y1=206)`

**Content**:

```
6.3. DMS: Document Management System
```

**Image**: *(has image_base64)*


---
