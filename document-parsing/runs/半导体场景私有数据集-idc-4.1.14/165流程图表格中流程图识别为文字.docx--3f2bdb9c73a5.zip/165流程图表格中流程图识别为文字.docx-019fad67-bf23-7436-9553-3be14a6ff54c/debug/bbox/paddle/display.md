# PADDLE BBox Visualization

## Page 1

![Page 1](./pages/page-1.webp)

## Page 2

![Page 2](./pages/page-2.webp)

## Page 3

![Page 3](./pages/page-3.webp)

## Page 4

![Page 4](./pages/page-4.webp)
