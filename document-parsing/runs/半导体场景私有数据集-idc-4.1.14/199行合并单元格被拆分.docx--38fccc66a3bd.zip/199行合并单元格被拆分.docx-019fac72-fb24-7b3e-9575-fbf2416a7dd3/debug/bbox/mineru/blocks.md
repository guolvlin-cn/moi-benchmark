# MinerU Parser Debug Output

**生成时间**: 2026-07-29T13:57:50.237625

**Block 总数**: 45


---

## 类型统计

| 类型 | 数量 |
|------|------|
| footer | 1 |
| list | 16 |
| text | 19 |
| title | 9 |

---

## Block 详情

### Block 0: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 0.0
- **bbox**: `BBox(x0=57, y0=61, x1=214, y1=86)`
- **标题级别**: 1

**Content**:

```
1. 检测结果总结

```

**Image**: *(has image_base64)*


---

### Block 1: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 1.0
- **bbox**: `BBox(x0=215, y0=98, x1=373, y1=123)`
- **标题级别**: 1

**Content**:

```
检测结果报告单

```

**Image**: *(has image_base64)*


---

### Block 2: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 1
- **索引**: 2.0
- **bbox**: `BBox(x0=198, y0=133, x1=388, y1=151)`

**Content**:

```
TABLE_placeHOLDER_001
```

**Image**: *(no image)*


---

### Block 3: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 3.0
- **bbox**: `BBox(x0=255, y0=361, x1=333, y1=375)`

**Content**:

```
（本页以下空白）

```

**Image**: *(has image_base64)*


---

### Block 4: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 4.0
- **bbox**: `BBox(x0=372, y0=642, x1=521, y1=655)`

**Content**:

```
利诚检测认证集团股份有限公司

```

**Image**: *(has image_base64)*


---

### Block 5: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 5.0
- **bbox**: `BBox(x0=433, y0=657, x1=521, y1=670)`

**Content**:

```
2025年07月15日

```

**Image**: *(has image_base64)*


---

### Block 6: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 6.0
- **bbox**: `BBox(x0=56, y0=686, x1=124, y1=699)`

**Content**:

```
编制人：陈某

```

**Image**: *(has image_base64)*


---

### Block 7: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 7.0
- **bbox**: `BBox(x0=189, y0=686, x1=265, y1=699)`

**Content**:

```
审核人：曾某某

```

**Image**: *(has image_base64)*


---

### Block 8: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 8.0
- **bbox**: `BBox(x0=309, y0=686, x1=444, y1=699)`

**Content**:

```
签发（授权签字人）：成某某

```

**Image**: *(has image_base64)*


---

### Block 9: footer

- **类型**: `footer`
- **源类型**: `footer`
- **页码**: 1
- **索引**: 9999.0755
- **bbox**: `BBox(x0=56, y0=755, x1=180, y1=772)`

**Content**:

```
1. 采样及检测数据

```

**Image**: *(has image_base64)*


---

### Block 10: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 8.0
- **bbox**: `BBox(x0=79, y0=56, x1=212, y1=69)`

**Content**:

```
(1) 《工作场所空气中xxxx》
```

**Image**: *(has image_base64)*


---

### Block 11: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 8.001
- **bbox**: `BBox(x0=79, y0=72, x1=211, y1=84)`

**Content**:

```
(2) 《工作场所空气中xxxx》
```

**Image**: *(has image_base64)*


---

### Block 12: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 8.002
- **bbox**: `BBox(x0=79, y0=88, x1=211, y1=100)`

**Content**:

```
(3) 《工作场所空气中xxxx》
```

**Image**: *(has image_base64)*


---

### Block 13: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 8.003
- **bbox**: `BBox(x0=79, y0=103, x1=211, y1=116)`

**Content**:

```
(4) 《工作场所空气中xxxx》
```

**Image**: *(has image_base64)*


---

### Block 14: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 8.004
- **bbox**: `BBox(x0=79, y0=119, x1=211, y1=132)`

**Content**:

```
(5) 《工作场所空气中xxxx》
```

**Image**: *(has image_base64)*


---

### Block 15: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 8.005
- **bbox**: `BBox(x0=79, y0=134, x1=211, y1=147)`

**Content**:

```
(6) 《工作场所空气中xxxx》
```

**Image**: *(has image_base64)*


---

### Block 16: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 8.006
- **bbox**: `BBox(x0=79, y0=150, x1=211, y1=163)`

**Content**:

```
(7) 《工作场所空气中xxxx》
```

**Image**: *(has image_base64)*


---

### Block 17: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 8.007
- **bbox**: `BBox(x0=79, y0=165, x1=211, y1=178)`

**Content**:

```
(8) 《工作场所空气中xxxx》
```

**Image**: *(has image_base64)*


---

### Block 18: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 2
- **索引**: 9.0
- **bbox**: `BBox(x0=56, y0=187, x1=178, y1=204)`
- **标题级别**: 1

**Content**:

```
2. 仪器名称及编号

```

**Image**: *(has image_base64)*


---

### Block 19: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 2
- **索引**: 10.0
- **bbox**: `BBox(x0=56, y0=213, x1=178, y1=226)`
- **标题级别**: 2

**Content**:

```
2.1. 采样仪器名称及编号：

```

**Image**: *(has image_base64)*


---

### Block 20: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 16.0
- **bbox**: `BBox(x0=79, y0=229, x1=220, y1=242)`

**Content**:

```
(1) EM-1500气体采样器xxxxx
```

**Image**: *(has image_base64)*


---

### Block 21: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 16.001
- **bbox**: `BBox(x0=79, y0=244, x1=220, y1=257)`

**Content**:

```
(2) EM-1500气体采样器xxxxx
```

**Image**: *(has image_base64)*


---

### Block 22: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 16.002
- **bbox**: `BBox(x0=79, y0=260, x1=220, y1=272)`

**Content**:

```
(3) EM-1500气体采样器xxxxx
```

**Image**: *(has image_base64)*


---

### Block 23: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 16.003
- **bbox**: `BBox(x0=79, y0=275, x1=220, y1=288)`

**Content**:

```
(4) EM-1500气体采样器xxxxx
```

**Image**: *(has image_base64)*


---

### Block 24: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 16.004
- **bbox**: `BBox(x0=79, y0=291, x1=220, y1=304)`

**Content**:

```
(5) EM-1500 气体采样器 xxxxx
```

**Image**: *(has image_base64)*


---

### Block 25: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 2
- **索引**: 17.0
- **bbox**: `BBox(x0=56, y0=307, x1=178, y1=320)`
- **标题级别**: 2

**Content**:

```
2.2. 检测一起名称及编号：

```

**Image**: *(has image_base64)*


---

### Block 26: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 21.0
- **bbox**: `BBox(x0=79, y0=323, x1=173, y1=335)`

**Content**:

```
(1) UV-1900IXXXXXXX
```

**Image**: *(has image_base64)*


---

### Block 27: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 21.001
- **bbox**: `BBox(x0=79, y0=338, x1=167, y1=350)`

**Content**:

```
(2) PF-1-01XXXXXX
```

**Image**: *(has image_base64)*


---

### Block 28: list

- **类型**: `list`
- **源类型**: `list_item`
- **页码**: 2
- **索引**: 21.002
- **bbox**: `BBox(x0=79, y0=354, x1=182, y1=366)`

**Content**:

```
(3) GXH-2010XXXXXX
```

**Image**: *(has image_base64)*


---

### Block 29: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 2
- **索引**: 22.0
- **bbox**: `BBox(x0=56, y0=377, x1=193, y1=394)`
- **标题级别**: 1

**Content**:

```
3. 最低定量浓度情况

```

**Image**: *(has image_base64)*


---

### Block 30: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 2
- **索引**: 23.0
- **bbox**: `BBox(x0=198, y0=410, x1=389, y1=428)`

**Content**:

```
TABLE_placeHOLDER_002
```

**Image**: *(no image)*


---

### Block 31: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 3
- **索引**: 0.0
- **bbox**: `BBox(x0=57, y0=56, x1=168, y1=80)`
- **标题级别**: 1

**Content**:

```
2. 检测结果

```

**Image**: *(has image_base64)*


---

### Block 32: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 3
- **索引**: 1.0
- **bbox**: `BBox(x0=57, y0=89, x1=215, y1=109)`
- **标题级别**: 2

**Content**:

```
2.1.化学因素检测结果

```

**Image**: *(has image_base64)*


---

### Block 33: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 3
- **索引**: 2.0
- **bbox**: `BBox(x0=112, y0=116, x1=473, y1=136)`

**Content**:

```
工作场所空气中读物浓度检测结果 单位： \mathrm{mg / m^3}

```

**Image**: *(has image_base64)*


---

### Block 34: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 3
- **索引**: 3.0
- **bbox**: `BBox(x0=199, y0=143, x1=390, y1=161)`

**Content**:

```
TABLE_placeHOLDER_003
```

**Image**: *(no image)*


---

### Block 35: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 4
- **索引**: 0.0
- **bbox**: `BBox(x0=200, y0=77, x1=390, y1=92)`

**Content**:

```
TABLE_placeHOLDER_004
```

**Image**: *(no image)*


---

### Block 36: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 5
- **索引**: 0.0
- **bbox**: `BBox(x0=199, y0=92, x1=390, y1=109)`

**Content**:

```
TABLE_placeHOLDER_005
```

**Image**: *(no image)*


---

### Block 37: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 6
- **索引**: 1.0
- **bbox**: `BBox(x0=199, y0=125, x1=392, y1=142)`

**Content**:

```
TABLE_placeHOLDER_007
```

**Image**: *(no image)*


---

### Block 38: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 6
- **索引**: -999.994
- **bbox**: `BBox(x0=199, y0=60, x1=390, y1=78)`

**Content**:

```
TABLE_placeHOLDER_006
```

**Image**: *(no image)*


---

### Block 39: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 7
- **索引**: 0.0
- **bbox**: `BBox(x0=199, y0=60, x1=390, y1=78)`

**Content**:

```
TABLE_placeHOLDER_008
```

**Image**: *(no image)*


---

### Block 40: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 7
- **索引**: 1.0
- **bbox**: `BBox(x0=57, y0=232, x1=102, y1=246)`

**Content**:

```
以下空白

```

**Image**: *(has image_base64)*


---

### Block 41: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 8
- **索引**: 0.0
- **bbox**: `BBox(x0=56, y0=56, x1=389, y1=80)`
- **标题级别**: 1

**Content**:

```
3. 工作场所有害因素职业接触限制

```

**Image**: *(has image_base64)*


---

### Block 42: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 8
- **索引**: 1.0
- **bbox**: `BBox(x0=57, y0=84, x1=164, y1=98)`

**Content**:

```
化学因素职业接触限值

```

**Image**: *(has image_base64)*


---

### Block 43: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 8
- **索引**: 2.0
- **bbox**: `BBox(x0=192, y0=108, x1=383, y1=125)`

**Content**:

```
TABLE_placeHOLDER_009
```

**Image**: *(no image)*


---

### Block 44: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 8
- **索引**: 3.0
- **bbox**: `BBox(x0=243, y0=465, x1=344, y1=481)`

**Content**:

```
***报告结束***

```

**Image**: *(has image_base64)*


---
