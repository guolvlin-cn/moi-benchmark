# MinerU Parser Debug Output

**生成时间**: 2026-07-29T13:52:35.057715

**Block 总数**: 10


---

## 类型统计

| 类型 | 数量 |
|------|------|
| text | 10 |

---

## Block 详情

### Block 0: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 0.0
- **bbox**: `BBox(x0=87, y0=143, x1=161, y1=155)`

**Content**:

```
阿斯蒂芬阿萨德

```

**Image**: *(has image_base64)*


---

### Block 1: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 1.0
- **bbox**: `BBox(x0=88, y0=158, x1=160, y1=171)`

**Content**:

```
阿第三方阿萨德

```

**Image**: *(has image_base64)*


---

### Block 2: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 2.0
- **bbox**: `BBox(x0=88, y0=174, x1=253, y1=186)`

**Content**:

```
奥德赛发斯蒂芬阿斯蒂芬阿斯顿发 sd

```

**Image**: *(has image_base64)*


---

### Block 3: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 3.0
- **bbox**: `BBox(x0=89, y0=190, x1=123, y1=202)`

**Content**:

```
表格一：

```

**Image**: *(has image_base64)*


---

### Block 4: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 1
- **索引**: 4.0
- **bbox**: `BBox(x0=196, y0=227, x1=384, y1=244)`

**Content**:

```
TABLE_placeHOLDER_001
```

**Image**: *(no image)*


---

### Block 5: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 5.0
- **bbox**: `BBox(x0=87, y0=596, x1=215, y1=608)`

**Content**:

```
阿第三方阿斯蒂芬阿斯蒂芬

```

**Image**: *(has image_base64)*


---

### Block 6: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 6.0
- **bbox**: `BBox(x0=88, y0=613, x1=153, y1=624)`

**Content**:

```
阿第三方asdf

```

**Image**: *(has image_base64)*


---

### Block 7: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 7.0
- **bbox**: `BBox(x0=89, y0=627, x1=431, y1=640)`

**Content**:

```
多发点发生的 阿斯顿发生的发阿斯蒂芬阿斯蒂芬水电费阿第三方阿是放大

```

**Image**: *(has image_base64)*


---

### Block 8: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 2
- **索引**: 0.0
- **bbox**: `BBox(x0=88, y0=158, x1=120, y1=171)`

**Content**:

```
表格3

```

**Image**: *(has image_base64)*


---

### Block 9: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 2
- **索引**: 1.0
- **bbox**: `BBox(x0=201, y0=210, x1=391, y1=227)`

**Content**:

```
TABLE_placeHOLDER_002
```

**Image**: *(no image)*


---
