# MinerU Parser Debug Output

**生成时间**: 2026-07-29T14:17:46.524835

**Block 总数**: 2


---

## 类型统计

| 类型 | 数量 |
|------|------|
| text | 2 |

---

## Block 详情

### Block 0: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 0.0
- **bbox**: `BBox(x0=45, y0=73, x1=289, y1=87)`

**Content**:

```
9.4 TECN process flow(Create/ Renew/ Abolish))

```

**Image**: *(has image_base64)*


---

### Block 1: text

- **类型**: `text`
- **源类型**: `table_placeholder`
- **页码**: 1
- **索引**: 1.0
- **bbox**: `BBox(x0=196, y0=95, x1=386, y1=111)`

**Content**:

```
TABLE_placeHOLDER_001
```

**Image**: *(no image)*


---
