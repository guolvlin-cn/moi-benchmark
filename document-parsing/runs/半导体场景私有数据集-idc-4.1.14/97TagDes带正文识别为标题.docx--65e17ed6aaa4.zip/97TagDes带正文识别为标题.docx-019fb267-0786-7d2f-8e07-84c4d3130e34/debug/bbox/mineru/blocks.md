# MinerU Parser Debug Output

**生成时间**: 2026-07-30T17:43:22.485623

**Block 总数**: 32


---

## 类型统计

| 类型 | 数量 |
|------|------|
| text | 27 |
| title | 5 |

---

## Block 详情

### Block 0: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 0.0
- **bbox**: `BBox(x0=67, y0=73, x1=239, y1=92)`
- **标题级别**: 1

**Content**:

```
Dispatch list format

```

**Image**: *(has image_base64)*


---

### Block 1: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 1.0
- **bbox**: `BBox(x0=139, y0=106, x1=532, y1=166)`

**Content**:

```
Although the Dispatch API provides functions for parsing and accessing the dispatch result, you may want to handle the response yourself. In that case, this description of the returned dispatch list may be helpful. Pre-defined headers for the dispatch list

```

**Image**: *(has image_base64)*


---

### Block 2: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 2.0
- **bbox**: `BBox(x0=139, y0=169, x1=533, y1=275)`

**Content**:

```
Designed for ZLink IoT Cloud (version 3.2+), enables gateways and edge devices to exchange batch control or data acquisition tasks using a compact and extensible TLV (Type-Length-Value) binary encoding. This approach ensures compatibility across vendors #rows, supports dynamic task type extensions, and performs reliably even under constrained network conditions. The following sections outline the technical specification and usage guidelines for this fictional API. Also, note that there is one key, #ISS_SLIS_DIAGS, which does not confirmed.

```

**Image**: *(has image_base64)*


---

### Block 3: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 3.0
- **bbox**: `BBox(x0=67, y0=303, x1=214, y1=323)`
- **标题级别**: 1

**Content**:

```
Tag descriptions

```

**Image**: *(has image_base64)*


---

### Block 4: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 4.0
- **bbox**: `BBox(x0=141, y0=337, x1=533, y1=364)`

**Content**:

```
The following table provides description for the tages used in a dispatch query result:

```

**Image**: *(has image_base64)*


---

### Block 5: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 5.0
- **bbox**: `BBox(x0=142, y0=368, x1=163, y1=380)`
- **标题级别**: 1

**Content**:

```
Tag

```

**Image**: *(has image_base64)*


---

### Block 6: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 6.0
- **bbox**: `BBox(x0=236, y0=368, x1=296, y1=380)`
- **标题级别**: 1

**Content**:

```
Description

```

**Image**: *(has image_base64)*


---

### Block 7: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 7.0
- **bbox**: `BBox(x0=141, y0=383, x1=194, y1=395)`

**Content**:

```
#headers

```

**Image**: *(has image_base64)*


---

### Block 8: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 8.0
- **bbox**: `BBox(x0=236, y0=383, x1=426, y1=395)`

**Content**:

```
Pre-defined headers for the dispatch list.

```

**Image**: *(has image_base64)*


---

### Block 9: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 9.0
- **bbox**: `BBox(x0=141, y0=399, x1=193, y1=411)`

**Content**:

```
columns

```

**Image**: *(has image_base64)*


---

### Block 10: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 10.0
- **bbox**: `BBox(x0=236, y0=398, x1=418, y1=411)`

**Content**:

```
The column heading names for the list.

```

**Image**: *(has image_base64)*


---

### Block 11: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 11.0
- **bbox**: `BBox(x0=141, y0=414, x1=187, y1=426)`

**Content**:

```
#widths

```

**Image**: *(has image_base64)*


---

### Block 12: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 12.0
- **bbox**: `BBox(x0=236, y0=414, x1=496, y1=427)`

**Content**:

```
The widths for each column, used in formatting the data.

```

**Image**: *(has image_base64)*


---

### Block 13: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 13.0
- **bbox**: `BBox(x0=141, y0=430, x1=180, y1=443)`

**Content**:

```
types

```

**Image**: *(has image_base64)*


---

### Block 14: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 14.0
- **bbox**: `BBox(x0=235, y0=430, x1=533, y1=459)`

**Content**:

```
The data types for each column. Normally used to decide how to justify a column by default.

```

**Image**: *(has image_base64)*


---

### Block 15: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 15.0
- **bbox**: `BBox(x0=141, y0=461, x1=186, y1=473)`

**Content**:

```
lotcol

```

**Image**: *(has image_base64)*


---

### Block 16: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 16.0
- **bbox**: `BBox(x0=236, y0=461, x1=414, y1=473)`

**Content**:

```
Which column contains the lot names.

```

**Image**: *(has image_base64)*


---

### Block 17: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 17.0
- **bbox**: `BBox(x0=141, y0=477, x1=174, y1=488)`

**Content**:

```
#rows

```

**Image**: *(has image_base64)*


---

### Block 18: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 18.0
- **bbox**: `BBox(x0=236, y0=476, x1=421, y1=489)`

**Content**:

```
The query data table in row-major form.

```

**Image**: *(has image_base64)*


---

### Block 19: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 19.0
- **bbox**: `BBox(x0=141, y0=492, x1=193, y1=504)`

**Content**:

```
blocked

```

**Image**: *(has image_base64)*


---

### Block 20: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 20.0
- **bbox**: `BBox(x0=235, y0=491, x1=533, y1=536)`

**Content**:

```
A flag for each lot that indicates if it is blocked. The WorkStram dispatcher interface uses this flag to determine whether that lot is selectable by the operator.

```

**Image**: *(has image_base64)*


---

### Block 21: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 21.0
- **bbox**: `BBox(x0=141, y0=539, x1=206, y1=551)`

**Content**:

```
#ISS-DDIS-

```

**Image**: *(has image_base64)*


---

### Block 22: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 22.0
- **bbox**: `BBox(x0=235, y0=539, x1=506, y1=552)`

**Content**:

```
This is diagnostic information from the dispatcher, relating

```

**Image**: *(has image_base64)*


---

### Block 23: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 23.0
- **bbox**: `BBox(x0=141, y0=555, x1=174, y1=566)`

**Content**:

```
DIAGS

```

**Image**: *(has image_base64)*


---

### Block 24: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 24.0
- **bbox**: `BBox(x0=235, y0=555, x1=514, y1=584)`

**Content**:

```
to the execution time of the rule. Note that it does not follow the same "#tag value" formats as the other tags.

```

**Image**: *(has image_base64)*


---

### Block 25: title

- **类型**: `title`
- **源类型**: `title`
- **页码**: 1
- **索引**: 25.0
- **bbox**: `BBox(x0=67, y0=611, x1=280, y1=631)`
- **标题级别**: 1

**Content**:

```
Parding the dispatch list

```

**Image**: *(has image_base64)*


---

### Block 26: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 26.0
- **bbox**: `BBox(x0=139, y0=645, x1=533, y1=673)`

**Content**:

```
The following functions are available for parding and processing the dispatcher result:

```

**Image**: *(has image_base64)*


---

### Block 27: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 27.0
- **bbox**: `BBox(x0=79, y0=686, x1=104, y1=698)`

**Content**:

```
[C++]

```

**Image**: *(has image_base64)*


---

### Block 28: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 28.0
- **bbox**: `BBox(x0=79, y0=701, x1=240, y1=714)`

**Content**:

```
include "writerlibx/iss_schedmsg.h"

```

**Image**: *(has image_base64)*


---

### Block 29: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 29.0
- **bbox**: `BBox(x0=79, y0=716, x1=265, y1=730)`

**Content**:

```
include "writerlibx/iss_schedmsg_print.h"

```

**Image**: *(has image_base64)*


---

### Block 30: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 30.0
- **bbox**: `BBox(x0=79, y0=748, x1=235, y1=761)`

**Content**:

```
/* Parsing of raw dispatch results */

```

**Image**: *(has image_base64)*


---

### Block 31: text

- **类型**: `text`
- **源类型**: `text`
- **页码**: 1
- **索引**: 31.0
- **bbox**: `BBox(x0=79, y0=763, x1=375, y1=777)`

**Content**:

```
schedmsg * iss_parserSchedMsg(const char *rawText, u_int text Size);

```

**Image**: *(has image_base64)*


---
