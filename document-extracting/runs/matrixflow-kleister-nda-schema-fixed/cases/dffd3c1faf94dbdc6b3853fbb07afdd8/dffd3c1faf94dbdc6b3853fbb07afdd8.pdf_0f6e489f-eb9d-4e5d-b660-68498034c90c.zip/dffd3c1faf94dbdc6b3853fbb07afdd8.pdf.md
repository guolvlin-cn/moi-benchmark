# NONDISCLOSURE AGREEMENT

This Nondisclosure Agreement (“Agreement”) is entered into as of March 29, 2011, by and between the undersigned and Newgistics, Inc. (the “Company”), with reference to the following:

# RECITALS

WHEREAS, I have been elected to serve on the Company’s Board of Directors (the “Board”); and

WHEREAS, in my capacity as a member of the Board, I will receive the Company’s confidential and Proprietary Information (as defined below) and, subject to the Board’s discretion and approval, the Company will grant me a present right to purchase shares of the Company’s common stock, in each case as further provided in the offer letter by and between me and the Company (the “Board Offer Letter”); and

WHEREAS, this Agreement is necessary to protect and prevent any unauthorized, improper or unlawful disclosure of the Company’s Proprietary Information.

# AGREEMENT

NOW THEREFORE, in exchange for the consideration provided to me in connection with my membership on the Board, including but not limited to the Company’s promise to provide me with immediate access to its Proprietary Information and, subject to the Board of Directors’ discretion and approval, the promise to grant me a present right to purchase shares of the Company’s common stock, and for other valuable consideration, the receipt and sufficiency of which is hereby acknowledged, I agree as follows:

# 1. Recognition of Company’s Rights; Nondisclosure.

At all times that I am a member of the Board (hereinafter referred to as my “Membership”) and for two years thereafter, I will hold in strictest confidence and will not disclose, use, lecture upon, or publish any of the Company’s confidential or Proprietary Information (defined below), except as such disclosure, use, or publication may be required in connection with my Membership, or unless the President or the Board expressly authorizes such in writing. I hereby assign to the Company any rights I may have or acquire in such confidential or Proprietary Information and recognize that all confidential and Proprietary Information shall be the sole property of the Company and its assigns and that the Company and its assigns shall be the sole owner of all patent rights, copyrights, trade secret rights, and all other rights throughout the world (collectively, “Proprietary Rights”) in connection therewith. I further recognize that any suggestions, comments or contributions I make at any meeting of the Board or in connection with my duties during the term of my Membership is the Company’s confidential and Proprietary Information.

The term “Proprietary Information” shall mean trade secrets, confidential knowledge, data, or any other proprietary information of the Company and each of its subsidiaries or affiliated companies. By way of illustration but not limitation, “Proprietary Information” includes (a) inventions, trade secrets, ideas, processes, formulas, data, lists, programs, other works of authorship, know-how, improvements, discoveries, developments, designs, and techniques relating to the business or proposed business of the Company and that were learned or discovered by me during the term of my Membership with the Company; (b) information regarding plans for research, development, new products and services, marketing and selling, business plans, budgets and unpublished financial statements, licenses, prices and costs, suppliers, customer lists and customers that were learned or discovered by me during my Membership; and (c) information regarding the skills and compensation of employees of the Company. Proprietary Information shall not include information (i) already in my possession and not subject to confidentiality requirements at the time of disclosure, (ii) obtained by me from another source without the duty of confidentiality, or (iii) readily available or generally known to the general public or to persons in the industry.

# 2. Third Party Information.

I understand, in addition, that the Company may from time to time receive from third parties confidential or proprietary information (“Third Party Information”) subject to a duty on the Company’s part to maintain the confidentiality of such information and to use it only for certain limited purposes. During the term of my Membership and thereafter, I will hold Third Party Information in the strictest confidence and will not disclose (to anyone other than Company personnel who need to know such information in connection with their work for the Company) or use, except in connection with my Membership, Third Party Information unless expressly authorized in writing by an executive officer of the Company or the Board.

# 3. No Improper Use of Materials.

I understand and agree that, in connection with my Membership, I shall not use or disclose the proprietary or confidential information or trade secrets of any employer, former employer, company for which I served on the Board of Directors, company for which I served on the advisory board, or any other person or entity. During my Membership, I will not bring onto the premises of the Company any unpublished documents or any property belonging to any employer, former employer or any other person or entity to whom I have an obligation of confidentiality unless consented to in writing by that employer, former employer, person, or entity.

# 4. No Conflicting Obligation.

I represent that my performance of all the duties in connection with my Membership does not and will not breach any agreement between me and any other company, person or entity. I have not entered into, and I agree I will not enter into, any agreement either written or oral in conflict herewith.

# 5. Legal and Equitable Remedies.

Because my services are personal and unique and because I may have access to and become acquainted with the confidential and Proprietary Information of the Company, the Company shall have the right to enforce this Agreement and any of its provisions by injunction, specific performance, or other equitable relief, without bond and without prejudice to any other rights and remedies that the Company may have for a breach of this Agreement.

# 6. Notices.

Any notices required or permitted hereunder shall be given to the appropriate party at the party’s last known address. Such notice shall be deemed given upon personal delivery to the last known address or if sent by certified or registered mail, three days after the date of mailing.

# 7. General Provisions.

7.1 Governing Law. This Agreement will be governed by and construed according to the laws of the State of Texas without regard to conflicts of law principles.   
7.2 Exclusive Forum. I hereby irrevocably agree that the exclusive forum for any suit, action, or other proceeding arising out of or in any way related to this Agreement shall be in the state or federal courts in Texas, and I agree to the exclusive personal jurisdiction and venue of any court in Travis County, Texas.   
7.3 Entire Agreement. This Agreement, together with the terms of the Board Offer Letter, set forth the entire agreement and understanding between the Company and myself relating to the subject matter hereof and supersedes and merges all prior discussions between us. No modification of or amendment to this Agreement, nor any waiver of any rights under this Agreement, will be effective unless in writing signed by the party to be charged. Any subsequent change or changes in my duties, or compensation will not affect the validity or scope of this Agreement. As used in this Agreement, the period of my Membership includes any time during which I may be retained by the Company as a consultant.

7.4 Severability. I acknowledge and agree that each agreement and covenant set forth herein constitutes a separate agreement independently supported by good and adequate consideration and that each such agreement shall be severable from the other provisions of this Agreement and shall survive this Agreement.   
7.5 Survival. The provisions of this Agreement shall survive the termination of my Membership for any reason and the assignment of this Agreement by the Company to any successor in interest or other assignee.   
7.6 Waiver. No waiver by the Company of any breach of this Agreement shall be a waiver of any preceding or succeeding breach. No waiver by the Company of any right under this Agreement shall be construed as a waiver of any other right. The Company shall not be required to give notice to enforce strict adherence to all terms of this Agreement.   
7.7 Headings. The headings to each section or paragraph of this Agreement are provided for convenience of reference only and shall have no legal effect in the interpretation of the terms hereof.   
7.8 Attorney’s Fees. In the event of litigation between me and the Company, the non-prevailing party (as determined at the time the court renders final non-appealable judgment on the litigation as a whole) shall pay to the prevailing party, in addition to any other amounts awarded, all reasonable legal and other related costs and expenses, including for example but not limited to attorneys’ fees, expert witness fees, court costs, costs of appeal, and all other reasonable out-of-pocket expenses incurred by the prevailing party in connection with such litigation.

[Signature Page Follows]

This Agreement shall be effective as of the first day of my Membership on the Company’s Board of Directors.

I UNDERSTAND THAT THIS AGREEMENT RESTRICTS MY RIGHT TO DISCLOSE OR USE THE COMPANY’S CONFIDENTIAL AND PROPRIETARY INFORMATION DURING OR SUBSEQUENT TO MY POSITION ON THE NEWGISTICS, INC. BOARD OF DIRECTORS.

/s/ Stephen M. Mattessich

Stephen M. Mattessich

ACCEPTED AND AGREED TO:

NEWGISTICS, INC.

By: /s/ William J. Razzouk

William J. Razzouk

President and Chief Executive Officer