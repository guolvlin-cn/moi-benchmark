# NON-COMPETITION AND NONDISCLOSURE AGREEMENT

This Non-Competition and Nondisclosure Agreement is entered into as of April 30, 2007 (the “Agreement Date”) among Accurel Systems International Corporation, a California corporation (the “Seller”), Implant Sciences Corporation, a Massachusetts corporation (the “Guarantor”) and Evans Analytical Group LLC, a Delaware limited liability company (the “Buyer”).

# WITNESSETH:

WHEREAS, the Buyer, Seller and Guarantor have entered into an Asset Purchase Agreement, dated as of the Agreement Date, pursuant to which, among other things, the Buyer is acquiring substantially all of the assets of Seller (the “Purchase Agreement”);

WHEREAS, in order to protect the value of the business of the Seller being acquired by the Buyer pursuant to the Purchase Agreement (the “Purchased Business”), Seller and Guarantor shall not compete with the Buyer and its respective Affiliates (as defined in the Purchase Agreement) in accordance with the terms and conditions hereof; and

WHEREAS, the agreement of Seller and Guarantor not to compete with the Buyer and its Affiliates as provided herein is an integral part of the transactions contemplated by the Purchase Agreement, and without such agreements, Buyer would not have entered into the Purchase Agreement.

NOW, THEREFORE, in consideration of the covenants and agreements contained herein, the payment of the purchase price under the Purchase Agreement and for other good and valuable consideration, the receipt and sufficiency of which are hereby acknowledged, the parties hereto, intending to be legally bound hereby, agree as follows:

1. Certain Definitions. Capitalized terms used herein and not otherwise defined shall have the meanings ascribed to them in the Purchase Agreement; provided, however, that the following terms shall have the meanings set forth below irrespective of the meanings such terms may have in the Purchase Agreement:

(a) "Confidential Information" means all information heretofore developed or used by the Seller or any of its Affiliates relating to the Restricted Business (as defined below) operations, employees, customers and clients of the Seller, including, but not limited to, customer and client lists, customer or client orders, financial data, pricing information and price lists, business plans and market strategies and arrangements, all books, records, manuals, advertising materials, catalogues, correspondence, mailing lists, production data, sales materials and records, purchasing materials and records, personnel records, quality control records and procedures included in or relating to the Restricted Business or any of the assets of the Seller, and all trademarks, copyrights and patents and applications therefor, all trade secrets, inventions, processes, procedures, research records, market surveys and marketing know-how and other technical papers. The term "Confidential Information" also includes any other information heretofore or hereafter acquired by the Seller and deemed by it to be confidential.   
(b) The term "control", with respect to any person, means the power to direct the management and policies of such person, directly or indirectly, by or through stock ownership, agency or otherwise, or pursuant to or in connection with an agreement, arrangement or understanding (written or oral) with one or more other persons by or through stock ownership, agency or otherwise; and the terms "controlling" and "controlled" have meanings correlative to the foregoing.   
(c) The term "person" means an individual, corporation, partnership, joint venture, limited liability company, association, trust, unincorporated organization or other entity, including a government or political subdivision or an agency or instrumentality thereof.   
(d) "Restricted Business" means the Business of the Seller, including all services performed by or on behalf of the Seller for its customers.   
(e) "Restricted Period" means the period commencing on the date of this Agreement and ending on the date which is five (5) years from the date hereof.

2. Non-competition. At all times from and after the date of this Agreement and until the expiration of the Restricted Period, Seller and Guarantor shall not:

(a) directly or indirectly engage in, be employed by, own, manage, operate, provide financing to, control or participate in the ownership, management or control of, or otherwise have an interest (whether, subject to Section 5, as a stockholder, director, officer, employee, representative, subcontractor, partner, consultant, proprietor, agent or otherwise) in, or cause, authorize, aid or assist any other person to own, manage, operate, provide financing to, control or otherwise have an interest in, any business or any person who is engaged in any business that directly or indirectly competes or intends to compete with the Restricted Business anywhere in the world, unless Seller or Guarantor purchase or own less than five percent $( 5 \% )$ of capital stock in a publicly held company; or   
(b) directly, indirectly or otherwise by letters, circulars or advertisements, and whether for itself or on behalf of any other person, canvass or solicit or, directly or indirectly, cause or authorize to be solicited, or enter into or effect, or, directly or indirectly, cause or authorize to be entered

into or effected, any business or orders for businesses competing with the Restricted Business from any person who (i) at the time of the Agreement or within two years prior to the date of the Agreement, has been, a customer or client, or (ii) is an active prospect to be a customer or client, in each case, of the Seller at the time of the Agreement.

3. Non-Disclosure of Confidential Information. Seller and Guarantor acknowledge that it is the policy of the Buyer to maintain as secret and confidential all Confidential Information, and the parties hereto recognize that Seller and Guarantor have acquired Confidential Information. Seller and Guarantor recognize that all such Confidential Information is and shall remain the sole property of the Buyer, free of any rights of Seller or Guarantor, and acknowledges that the Buyer and its Affiliates have a vested interest in assuring that all such Confidential Information remains secret and confidential. Therefore, the Seller and Guarantor agree that at all times from after the date hereof, they will not, directly or indirectly, without the prior written consent of the Buyer, disclose to any person, firm, company or other entity (other than the Buyer or any of its Affiliates) any Confidential Information, except to the extent that (i) any such Confidential Information becomes generally available to the public or trade, other than as a result of a breach by the Seller or Guarantor of this Section 3, or (ii) any such Confidential Information becomes available to the Seller or Guarantor on a non-confidential basis from a source other than the Seller, Guarantor, Buyer or any of their Affiliates or advisors; provided, that such source is not known by the Seller or Guarantor to be bound by a confidentiality agreement with, or other obligation of secrecy to, the Seller, Guarantor, Buyer or another party. In addition, it shall not be a breach of the confidentiality obligations hereof if the Seller or Guarantor is required by law or legal process to disclose any Confidential Information; provided, that in such case, the Seller or Guarantor shall (a) give the Buyer prompt notice that such disclosure is or may be required, and (b) cooperate with the Buyer, at the Buyer's expense, in protecting, to the maximum extent legally permitted, the confidential or proprietary nature of the Confidential Information which must be so disclosed. The obligations of the Seller and Guarantor under this Section 3 shall survive any termination of this Agreement.

4. Non-Solicitation. At all times from and after the date of this Agreement and until the expiration of the Restricted Period, Seller and Guarantor shall not, directly, indirectly or otherwise by letters, circulars or advertisements, and whether for themselves or on behalf of any other person:

(a) solicit or, directly or indirectly, cause to be solicited for employment, any persons who (i) are, at the time of solicitation of employment, employees of the Seller, Buyer or any of their respective Affiliates, or (ii) are, at the time of solicitation of employment, sales representatives or employees thereof, retained by the Buyer or any of its Affiliates; or   
(b) employ or, directly or indirectly, cause to be employed, any persons who (i) are, at the time of such action, employees of the Buyer or any of its Affiliates, or (ii) are, at the time of such action, sales representatives or employees thereof, retained by the Buyer or any of its Affiliates;

provided, however, that this Section 4 shall not prohibit Seller or Guarantor from employing or soliciting the employment any person who (A) is an employee of Seller as of the Agreement Date and (B) is not offered employment by Buyer as of the Agreement Date.

5. Right to Injunctive Relief. Seller and Guarantor acknowledge that any breach or threatened breach by it of any of the covenants or provisions contained herein will result in irreparable and continuing harm to the Buyer for which the Buyer would not have adequate remedy at law. Therefore, Seller and Guarantor acknowledges and agrees that, in addition to any other remedy which the Buyer may have at law or in equity, the Buyer shall be entitled to injunctive relief or other equitable remedies in the event of any such breach or threatened breach. Seller and Guarantor further acknowledges and agrees that monetary damages would be insufficient to compensate the Buyer in the event of a breach by Seller or Guarantor of any of the covenants or provisions contained herein, and that in the event of a breach thereof, the Buyer shall be entitled to specific performance of the obligations hereunder.

6. Enforceability; Severability. If any provision of this Agreement shall be adjudicated to be invalid or unenforceable, then such provision shall be deemed modified, as to duration, territory or otherwise, so as to be enforceable as similar as possible to the provision at issue, in order to render the remainder of this Agreement valid and enforceable. The invalidity or unenforceability of any provision of this Agreement shall not affect the other provisions hereof, and this Agreement shall be construed in all respects as if such invalid or unenforceable provision were omitted.

7. Successors and Assigns. This Agreement shall be binding upon and shall inure to the benefit of Seller and its successors and assigns, and shall be binding and inure to the benefit of the Buyer and its successors and assigns.

8. Entire Agreement. This Agreement, together with the Purchase Agreement and the Transaction Documents, contains the entire understanding among the parties hereto with respect to the subject matter hereof and supersedes all prior negotiations and understandings among the Buyer and Seller with respect hereto. This Agreement may not be amended or modified except by a written instrument signed by the parties hereto.

# 9. Governing Law; Venue.

(a) This Agreement shall be construed in accordance with, and governed in all respects by, the internal laws of the State of Massachusetts, without giving effect to principles of conflicts of laws.   
(b) Unless otherwise explicitly provided in this Agreement, any Proceeding relating to this Agreement or the enforcement of any provision of this Agreement may be brought or otherwise commenced in any state or federal court located in the County of Middlesex, Massachusetts. Each of Seller, Guarantor and Buyer:

(i) expressly and irrevocably consents and submits to the jurisdiction of each state and federal court located in the County of Middlesex, Massachusetts and each appellate court located in the State of Massachusetts, in connection with any such Proceeding;

(ii) agrees that each state and federal court located in the County of Santa Clara, California or Massachusetts shall be deemed to be a convenient forum;   
(iii) agrees not to assert, by way of motion, as a defense or otherwise, in any such Proceeding commenced in any state or federal court located in the County of Santa Clara, California or Massachusetts any claim that such Party is not subject personally to the jurisdiction of such court, that such Proceeding has been brought in an inconvenient forum, that the venue of such Proceeding is improper or that this Agreement or the subject matter of this Agreement may not be enforced in or by such court; and   
(iv) agrees that service in any action may be made by giving notice in accordance with Section 10.

10. Notices. Any notice or other communication required or permitted to be delivered to any party shall be in writing and shall be deemed properly delivered, given and received when delivered, by hand, by registered mail, by courier or express delivery service, by facsimile, or by email to the address or facsimile number set forth beneath the name of such party below, or to such other address or facsimile number as such party shall have specified in a written notice given to the other parties:

if to the Seller or the Guarantor:

Implant Sciences Corporation

107 Audubon Road, #5

Wakefield, MA 01880-1246

Attention:

Facsimile: (781) 246-3561

Email: @implantsciences.com

with a copy to:

Ellenoff Grossman & Schole LLP

370 Lexington Avenue

New York, NY 10017-6503

Attention: Barry I. Grossman

Facsimile: (212) 370-7889

Email: bigrossman@egsllp.com

if to the Buyer:

E vans Analytical Group LLC

810 Kifer Road

Sunnyvale, CA 94086

Attention: Thomas B. Pfeil

Facsimile: (408) 530-3899

E-mail: tpfeil@eaglabs.com

11. Headings. The headings of sections and subsections of this Agreement are for convenience of reference only and are not to be considered in construing this Agreement.

12. Execution in Counterparts. This Agreement may be executed in any number of counterparts, each of which shall be deemed to be an original, but all of which, when taken together, shall constitute one and the same instrument.

IN WITNESS WHEREOF, the parties hereto have caused this Non-Competition and Nondisclosure Agreement to be executed as of the day and year first above written.

ACCUREL SYSTEMS INTERNATIONAL CORPORATION

EVANS ANALYTICAL GROUP LLC

By: By:

Name: Name:

Title: Title:

Name:

Title: