# LED UNITED STATES DEPARTMENT OF JUSTICE

1953

WASHINGTON, D. C.

Form FA-10

REGISTRATION No. 16/9

# AMENDMENT

TO REGISTRATION [ ] EXEMPTION [ ] STATEMENT (Indicate which)

NUMBER 1619

Pursuant to the Foreign Agents Registration Act of 1938 as Amended

Name of registrant (or agent) Korea Trade Promotion Center

Name of foreign principal Korea Trade Promotion Corporation

The answers to the items of the above-mentioned statement listed below are hereby amended to read as follows:

(Insert proper item numbers)   

<table><tr><td colspan="5">Item No. 10</td></tr><tr><td></td><td>Jan.</td><td>Feb.</td><td>Mar.</td><td>Apr.</td></tr><tr><td>Salary</td><td>$3,999.00</td><td>$4,054.50</td><td>$4,111.50</td><td>$4,081.50</td></tr><tr><td>Off. Supply</td><td>$753.64</td><td>$571.65</td><td>$548.52</td><td>$771.61</td></tr><tr><td>Off. Rent</td><td>$2,250.50</td><td>$2,319.50</td><td>$2,519.50</td><td>$2,113.73</td></tr><tr><td>Transportation</td><td>$244.20</td><td>$200.00</td><td>$173.57</td><td>$186.86</td></tr><tr><td>Research</td><td>$57.40</td><td>---</td><td>---</td><td>---</td></tr><tr><td>Off. Equipment</td><td>$1,252.50</td><td>$140.20</td><td>$90.20</td><td>$192.42</td></tr><tr><td>Advertisement</td><td>$681.49</td><td>$415.62</td><td>$504.16</td><td>$435.18</td></tr><tr><td>Communications</td><td>$765.82</td><td>$873.63</td><td>$601.02</td><td>$652.26</td></tr><tr><td>Utopi No.</td><td>$173.44</td><td>$10.83</td><td>$208.78</td><td>$31.41</td></tr><tr><td>Maintenance</td><td>$112.00</td><td>$260.72</td><td>$50.02</td><td>$346.07</td></tr><tr><td>Duty &amp; Cartage</td><td>$120.91</td><td>$91.18</td><td>$102.43</td><td>$135.97</td></tr><tr><td>Miscellaneous</td><td>$202.92</td><td>$191.44</td><td>$308.59</td><td>$232.44</td></tr></table>

Total: 610,449.38 69,129.93 59,108.29 59,179.45

Item No.

Item No.

Item No.

(If additional items are to be amended, insert additional pages as needed)

#

f.

![](images/b4e68c2b-5a7b-4500-9fb9-c67c440b5f7d.jpg)

![](images/1095aa8c-878d-4541-a297-2c1b779c3a82.jpg)

Exhibits.--The following additional or amended exhibits are attached hereto as a part of this amendment (list exhibits attached)

NOTE. --The amendment will not be accepted for filing unless both copies are signed and sworn to as required below.

The undersigned swear (s) or affirm (s) that he has (they have) read the information set forth in this amendment to the statement mentioned above and the attached exhibits, that he is (they are) familiar with the contents thereof and that such contents are in their entirety true and accurate to the best of his (their) knowledge and belief, except that the undersigned make (s) no representation as to the truth or accuracy of information contained in any Exhibit A filed herewith insofar as such information is not within his (their) personal knowledge.

(If the agent is a partnership, corporation, association, or other combination of individuals, this amendment shall be signed and sworn to before a notary public or other officer authorized to administer oaths, by a majority of those partners, officers, directors, or persons performing similar functions who are in the United States. If no such person is in the United States, the amendment shall be signed and sworn to by the duly authorized representative of the agent.)

(Type or print name under each signature)

![](images/e06b3162-3996-4b5f-bbd7-cde5fe5921b8.jpg)  
(81nature)

(signature)

(6ignature)

(61gnature)

Subscribed and sworn to before me at. this day of ydy, 1963.

JOHN Y. LEE  
Notary Public, State of New York  
No. 31-2292175  
Qualified in New York County  
Commission Expires March 30, 196

yde (Notary or other officer)

My commission expires 30 , 1965