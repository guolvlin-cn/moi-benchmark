INSTRUCTIONS: Report must be submitted in duplicate to the Registration Unit, Internal Security Section, Criminal Division, Department of Justice, Washington, D.C. 20530. The original must be signed by or on behalf of the registrant. All items in this form must be answered, unless the answer is "none" or "not applicable," in which case such an entry shall be made in the appropriate space. If additional space is needed for any item, attach supplemental sheet identifying each item.

Privacy Act Statement. Every registration statement, short form registration statement, supplemental statement, exhibit, amendment, dissemination report, copy of political propaganda or other document or information filed with the Attorney General under this act is a public record open to public examination, inspection and copying during the posted business hours of the Registration Unit in Washington, D.C. One copy of every such document is automatically provided to the Secretary of State pursuant to Section 6(b) of the Act, and copies of such documents are routinely made available to other agencies, departments and Congress pursuant to Section 6(c) of the Act. Finally, the Attorney General transmits an annual report to the Congress on the Administration of the Act which lists the names of all agents registered under the Act, the foreign principals they represent, and the nature, sources and content of the political propaganda disseminated or distributed by them. This report is available to the public.

Public Reporting Burden. Public reporting burden for this collection of information is estimated to average .5 hours per response, including the time for reviewing instructions, searching existing data sources, gathering and maintaining the data needed, and completing and reviewing the collection of information. Send comments regarding this burden estimate or any other aspect of this collection of information, including suggestions for reducing this burden to Chief, Registration Unit, Criminal Division, U.S. Department of Justice, Washington, D.C. 20530; and to the Office of Information and Regulatory Affairs, Office of Management and Budget, Washington, D.C. 20503.

<table><tr><td colspan="3">1. Name of registrant
Far East Trade Service, Inc.</td><td>2. Registration No.
2985</td></tr><tr><td colspan="4">3. Nature of material (A concise account of the nature of the propaganda material filed)
Trade promotion for Taiwan, R.O.C.</td></tr><tr><td colspan="2">4. Title of material, if any
1. What You Can Sell to Taiwan
2. Doing Business with Taiwan</td><td colspan="2">5. Name of foreign principal on whose behalf this material was
transmitted.
Far East Trade Service, Inc.
Taipei, Taiwan, R.O.C.</td></tr><tr><td>6. Means of transmission
By mail/in person</td><td>7. Dates of transmission
January 4,
5, 12, 15, 19 &amp; 20, 1993</td><td colspan="2">8. Total copies transmitted
1. - 1; 2. - 7; Total: 8</td></tr><tr><td colspan="2">9. List addresses from which material was transmitted:
Far East Trade Service, Inc.
555 Montgomery Street, Suite 603
San Francisco, CA 94111-2564</td><td colspan="2">10. List states and territories of the United States to which
material was transmitted:
California &amp; Colorado</td></tr><tr><td colspan="2">11. Types of recipients (Give number of organizations
in each group)
Libraries
Public officials
Newspapers
Press services of
associations
Educational
institutions
Civic groups
Other (specify) Import/Export</td><td colspan="2">12. List names and addresses of persons or organizations
receiving 100 copies or more:
REGISTRATION UNIT
FEB-8
33
N/A</td></tr></table>

13. If the material transmitted was a film or radio or television script, furnish the following information:

Name of station, organization, or theater using (including city and state)

Date or dates broadcast shown

Estimated attendance (for film(s))

N/A

14. Have two copies of this material been filed with the Department of Justice? Yes No   
15. Has this material been labeled as required by the act? Yes No

<table><tr><td>Date of report
2-1-93
(Jan. Report)</td><td>Name and title
Robert Y. Wang, Director</td><td>Signature
pywong</td></tr></table>