1. Name of Registrant

JAPAN TRADE CENTER San Francisco

2. Registration No.

#1813

3. This amendment is filed to accomplish the following indicated purpose or purposes:

To correct a deficiency in

To give a 10-day notice of a change in information as required by Section 2(b) of the Act.

Initial Statement

□ Other purpose (specify)

Supplemental Statement for March 31, 1967

To give notice of change in an exhibit previously filed.

4. If this amendment requires the filing of a document or documents, please list -

# None

5. Each item checked above must be explained below in full detail together with, where appropriate, specific reference to and identity of the item in the registration statement to which it pertains. If more space is needed, full size insert sheets may be used.

Item 10 Japan External Trade Organization, Tokyo

Item 11 Market Research Activities

1. Ball Point Pen research   
2. Heater, Oven, Gas Range research   
3. California Business Conditions research

Information Service

All trade inquiries averaging 1,0752 yearly is referred to our office in Tokyo.

Publication, publicity, etc.

The public relations section has been transferred to

The undersigned swear(s) or affirm(s) that he has (they have) read the information set forth in this amendment and that he is (they are) familiar with the contents thereof and that such contents are in their entirety true and accurate to the best of his (their) knowledge and belief.

(Both copies of this amendment shall be signed and sworn to before a notary public or other person authorized to administer oaths by the agent, if the registrant is an individual, or by a majority of those partners, officers, directors or persons performing similar functions who are in the United States, if the registrant is an organization.)

![](images/2334751c-8f39-412b-9fe6-404d35e8a45c.jpg)

Subscribed and sworn to before me at Dan Financia

this 4 day of aueol ,1967

My commission expireMy Commission Expires Nov. 28, 1968

![](images/d8a5d8f5-551e-4879-b2b8-733295c824b1.jpg)

our Japan Trade Center, Los Angeles Office, and all publications, publicity, etc. is taken care of by them.

Item 14 (a) The receipt of numerous remittance from our foreign principal is sent in a total sum and they later notify us as to the use at various trade exhibits and market research.