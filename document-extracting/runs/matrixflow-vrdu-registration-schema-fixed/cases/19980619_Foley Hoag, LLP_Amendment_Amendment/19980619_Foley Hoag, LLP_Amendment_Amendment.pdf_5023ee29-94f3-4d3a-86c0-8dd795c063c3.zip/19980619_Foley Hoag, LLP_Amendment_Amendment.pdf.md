Privacy Act Statement. Every registration statement, short form registration statement, supplemental statement, exhibit, amendment, copy of informational materials or other document or information filed with the Attorney General under this Act is a public record open to public examination, inspection and copying during the posted business hours of the Registration Unit in Washington, D.C. One copy of every such document, other than informational materials, is automatically provided to the Secretary of State pursuant to Section 6(b) of the Act, and copies of any and all documents are routinely made available to other agencies, departments and Congress pursuant to Section 6(c) of the Act. The Attorney General also transmits a semi-annual report to Congress on the Administration of the Act which lists the names of all agents registered under the Act and the foreign principals they represent. This report is available to the public. Finally, the Attorney General intends, at the earliest possible opportunity, to make these public documents available on the Internet on the Department of Justice World Wide Web site.

Public Reporting Burden. Public reporting burden for this collection of information is estimated to average 1.5 hours per response, including the time for reviewing instructions, searching existing data sources, gathering and maintaining the data needed, and completing and reviewing the collection of information. Send comments regarding this burden estimate or any other aspect of this collection of information, including suggestions for reducing this burden to Chief, Registration Unit, Criminal Division, U.S. Department of Justice, Washington, DC 20530; and to the Office of Information and Regulatory Affairs, Office of Management and Budget, Washington, DC 20503.

<table><tr><td>1. Name of Registrant
Foley, Hoag &amp; Eliot LLP
1747 Pennsylvania Ave., N.W.
Suite 1200
Washington, D.C. 20006</td><td>2. Registration No.
4776</td></tr></table>

3. This amendment is filed to accomplish the following indicated purpose or purposes:

To correct a deficiency in

To give a 10-day notice of change in information as required by Section 2(b) of the Act.

□ Initial Statement   
□ Supplemental Statement for the period ending   
Other purpose (specify) Name change, formerly Reichler, Milton & Medel

026873

To give notice of change in an exhibit previously filed.

4. If this amendment requires the filing of a document or documents, please list-

CRM/ISS/RESSESSATIONUNIT

98JUNI

5. Each item checked above must be explained below in full detail together with, where appropriate, specific reference to and identity of the item in the registration statement to which it pertains. (If space is insufficient, a full insert page must be used.)

110:16

# EXECUTION

In accordance with 28 U.S.C. § 1746, the undersigned swear(s) or affirm(s) under penalty of perjury that he/she has (they have) read the information set forth in this registration statement and the attached exhibits and that he/she is (they are) familiar with the contents thereof and that such contents are in their entirety true and accurate to the best of his/her (their) knowledge and belief, except that the undersigned make(s) no representation as to the truth or accuracy of the information contained in the attached Short Form Registration Statement(s), if any, insofar as such information is not within his/her (their) personal knowledge.

(Date of signature)

6/16/98

![](images/2fda8365-95b7-46b1-8556-6c13e88bc68a.jpg)