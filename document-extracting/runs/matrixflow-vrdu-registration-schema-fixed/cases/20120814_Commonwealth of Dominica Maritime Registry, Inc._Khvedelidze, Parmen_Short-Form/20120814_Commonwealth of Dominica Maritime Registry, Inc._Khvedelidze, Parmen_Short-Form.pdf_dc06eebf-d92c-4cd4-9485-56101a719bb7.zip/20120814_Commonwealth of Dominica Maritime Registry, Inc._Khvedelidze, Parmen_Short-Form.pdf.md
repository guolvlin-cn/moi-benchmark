1

1.5. Department of Justice

Washington, DC 20510

Short Form Régistration Statement

Pursuant to the Foreign Agents Registration Act of 1938, as amended

TNT, THT, TMS. Each partner, officer, director, executive, employee and any part of a registrant is required to be an short form registration statement unless the registrant is no activity in furtherance of the interests of the registrant's operations or principal or unless the registrant is intended to the registrant are in secretariat, electrical, or is referred to as regular capacity. The registrant is required to fill an electronic short form registration statement at any time.

Prive: Act Statement. The filg of this document is required for the Foreign Agents Regisration Act of 1938, as amendred. 2 L.S.C. §61 of 1938, for the purposes of registration under the Act and public disclosure. Provision of the information requested is mamnary, and failure to provide the inormation is subject to the penalty and enforcement provisions established in Section 8 of the Act. Ex. in regatioration, short form astrustors stated supplemental statement, exchel, amendment, copy of information materials or other documents in information filed with the Attorney General under this Act is a public record open to public examination, inspection and copying during the period business hours of the. Registration Unit on W. stree; [C] Streets, any can be available online at the Regisration Unit a website htp:/www.faregar. One copy of every such document, other than information material, will be automatically provided in the Secretary of State pursuant to Section 80 of the Act and copies of any and all documents are not only made available to other agencies, departments and Congress pursuant to Section 80 of the Act. The Attorney General also immursms a semi-annual report to Congress on the administration of the Act which lists the names of all agents registered under the Act and the foreign principal they represent. This report is available to the public and published in: http://www.faregar.com

Public Reparting Burden. Public reporting burden for this collection of information is estimated to average 120 hours per response, including the time for reviewing instructions, searching existing data sources, gathering and maintaining the data needed, and completing and reviewing the collection of information. Annual estimates regarding this burden estimate are only an estimate of the collection of information, not representing the total reduction in burden to Chief, Registration Staff, Country/Respondent Section, National Security Division, U.S. Department of Justice, Washington, DC 20530, and to the Office of Information and Regulations Affairs, Office of Management and Budget, Washington, DC 20548.

<table><tr><td>1. Nature
Parmen Khwetdilize</td><td>2. Registration No.
9714</td></tr><tr><td>3. Residence Address
74/10 King Farnavaz str, Batumi, Georgia</td><td>4. Business Address
26 Tallin HW, Mabirajau Batumi, Georgia</td></tr><tr><td>5. Year of Birth 1950
Nationality: Georgian
Present Citizenship: Georgian</td><td>6. If present citizenship was not acquired by birth, indicate when and how acquired.
N/A</td></tr></table>

7. Ogegulim Baturi

8. What is the name and address of the primary registrant?

Name Commonwealth of Dominica Maritime Registry

32 Washington Street

Address Fairhaven MA 02719 USA

9. To indicate your connection with the primary registrant:

□本报记者

□ director

□cnpoyce

Coneh

□·雨

1358061.124

图

sakcnoae

other property

10. List every foreign principal to whom you will render services or support of the primary regimen: Commonwealth of Dominica

11. Describe separately and in detail all services which you will render to the foreign principal, listed in Item 10 either directly, or through the primary segment listed in Item 8, and the date of such service. If space is insufficient, a full master page must be used.

Vesical registration sales and certification: Mariner certification

12. (No answer of the above described services) Is he/ she political act(s) as defined in Section 10(a) of the Act and in the Iomnant helms?

No

If yes, describe separately and in detail what political activity is.

12. The services described in Items 11 and 12 are to be rendered as a

□ All time basis

□partlinebasis:

spesial basis

14. What is an approximation or something of value have you reached to date or will you ever be for the above series?

Salary: Arnunr.

30/5 services/sold

Salary: Not based solely on services rendered to the foreign principal.

□ See Amount 1

Other thing of value

15. During the period beginning of 0 days a prior to the date of your obligation to register to the time of filling this statement, did you make any contributions of money or other things of value from your own funds or p. vations and end our own behind in connection with any election to political office . In connection with any primary mission, convention, or act, held to select candidates for any political office? Yes No

It was worth the following information:

Date

Amount or Thing of Value

Political Organization or Candidate

Location of Event

# EXECUTION

In accordance with 28 U.S.C. § 1746, the undersigned swears or affirms under pretnulty (of) puroity that he/she has read the information on his/ her birth in this registration statement and that he/she is familiar with the contents. There is no reason that such contents are in their entirety true and accurate to the best of his/her knowledge and belief.

13.08 2012

(Other or signa

![](images/cbc295ff-d8d8-45ad-8352-e3e9791ef6bf.jpg)

(6)

F