Each partner, officer, director, associate, employee, and agent of a registrant is required to file a short form registration statement unless he engages in no activities in furtherance of the interests of the registrant's foreign principal or unless the services he renders to the registrant are in a secretarial, clerical, or in a related or similar capacity.

Privacy Act Statement. The filing of this document is required by the Foreign Agents Registration Act of 1938, as amended, 22 U.S.C. § 611 et seq., for the purposes of registration under the Act and public disclosure. Provision of the information requested is mandatory, and failure to provide this information is subject to the penalty and enforcement provisions established in Section 8 of the Act. Every registration statement, short form registration statement, exhibit, amendment, copy of informational materials or other document or information filed with the Attorney General under this Act is a public record open to public examination, inspection and copying during the posted business hours of the Registration Unit in Washington, DC. Statements are also available online at the Registration Unit's webpage: http://www.fara.gov/. One copy of every such document, other than informational materials, is automatically provided to the Secretary of State pursuant to Section 6(b) of the Act, and copies of any and all documents are routinely made available to other agencies, departments and Congress pursuant to Section 6(c) of the Act. The Attorney General also transmits a semi-annual report to Congress on the Administration of the Act which lists the names of all agents registered under the Act and the foreign principals they represent. This report is available to the public in print and online at: http://www.fara.gov/.

Public Reporting Burden. Public reporting burden for this collection of information is estimated to average .429 hours per response, including the time for reviewing instructions, searching existing data sources, gathering and maintaining the data needed, and completing and reviewing the collection of information. Send comments regarding this burden estimate or any other aspect of this collection of information, including suggestions for reducing this burden to Chief, Registration Unit, Counterspionage Section, National Security Division, U.S. Department of Justice, Washington, DC 20530; and to the Office of Information and Regulatory Affairs, Office of Management and Budget, Washington, DC 20503.

<table><tr><td>1. Name
Nicole Young</td><td>2. Registration No.
5926</td></tr><tr><td>3. Residence Address(es)
326 35th Street NE
Washington, DC 20019</td><td>4. Business Address(es)
1001 G Street NW, Suite 900 East</td></tr><tr><td>5. Year of Birth          , 1981
Nationality USA
Present Citizenship USA</td><td>6. If present citizenship was not acquired by birth, indicate when, and how acquired.</td></tr></table>

7. Occupation

Consultant

8. What is the name and address of the primary registrant?

Name

Podestagroup，Inc.

Address

1001 G Street NW, Suite 900 East

Washington, DC 20001

9. Indicate your connection with the primary registrant:

partner

□ officer

other (specify)

□ director

□ associate

$\boxtimes$ employee

agent

□ consultant

subcontractor

209 25附4

11. Describe separately and in detail all services which you will render to the foreign principal(s) listed in Item 10 either directly, or through the primary registrant listed in Item 8, and the date(s) of such services. (If space is insufficient, a full page insert must be used.)

Provide strategic counsel to the principal to enhance principal's overall image and reputation among relevant U.S. audiences, increase understanding of Swiss related issues, optimize perceptions of Switzerland's positions and issues among relevant U.S. audiences, and increase awareness of Switzerland's positive attributes and closed economic, political, and cultural relationship with the United States.

12. Do any of the above described services include political activity as defined in Section 1(o) of the Act and in the footnote below?

Yes No

If yes, describe separately and in detail such political activity.

All of the activities listed above in Item 11 will be undertaken in order to communicate information to the principal, as well as to communicate information about the principal and its policies to relevant public policy audiences.

13. The services described in Items 11 and 12 are to be rendered on a

$\boxed{\times}$ full time basis

part time basis

special basis

14. What compensation or thing of value have you received to date or will you receive for the above services?

Salary:

Amount $

per

Commission at

% of

$\boxed{\mathbf{x}}$ Salary:

Not bas

1 solel

1

1

.

.

（）

15. During the period beginning 60 days prior to the date of your obligation to register to the time of filing this statement, did you make any contributions of money or other things of value from your own funds or possessions and on your own behalf in connection with any election to political office or in connection with any primary election, convention, or caucus held to select candidates for any political office? Yes No

If yes, furnish the following information:

Date

Amount of

thing of value

Name of political organization

Name of

candidate

SEE

ATTACHED

# EXECUTION

In accordance with 28 U.S.C. § 1746, the undersigned swears or affirm(s) under penalty of perjury that he/she has read the information set forth in this registration statement and that he/she is familiar with the contents thereof and that such contents are in their entirety true and

accurate to the best of his/her knowledge and belief.

09/25/09

(Date of signature)

![](images/902d14d5-b19d-42a4-83d3-ba9273532ab4.jpg)

JINNOLVAISIDU/SSI/HQ

8S :n Hd S 2 dEs 60Z

# ATTACHMENT

15. During the period beginning 60 days prior to the date of your obligation to register to the time of filing this statement, did you make any contributions of money or other things of value from your own funds or possessions and on your own behalf in connection with any election to political office or in connection with any primary election, convention or caucus held to select candidates for any political office?

<table><tr><td colspan="4">Ms. Baker</td></tr><tr><td>9/16/09</td><td>$500</td><td>PAC to the Future</td><td>Rep. Nancy Pelosi (CA)</td></tr><tr><td colspan="4">Mr. Kauders</td></tr><tr><td>7/22/09</td><td>$250</td><td>Friends of Patrick Kennedy</td><td>Rep. Patrick Kennedy (RI)</td></tr><tr><td>7/23/09</td><td>$1,000</td><td>PAC to the Future</td><td>Rep. Nancy Pelosi (CA)</td></tr><tr><td>7/31/09</td><td>$250</td><td>Gillibrand for Senate</td><td>Sen. Kirsten Gillibrand (NY)</td></tr><tr><td>7/31/09</td><td>$500</td><td>Maloney for Congress</td><td>Rep. Carolyn Maloney (NY)</td></tr><tr><td>9/14/09</td><td>$500</td><td>Jim Moran for Congress</td><td>Rep. Jim Moran (VA)</td></tr><tr><td>9/21/09</td><td>$250</td><td>Charlie Melancon Campaign Committee</td><td>Rep. Charlie Melancon (LA)</td></tr><tr><td colspan="4">Mr. Lewin</td></tr><tr><td>9/1/09</td><td>$500</td><td>PAC to the Future</td><td>Rep. Nancy Pelosi (CA)</td></tr><tr><td colspan="4">Mr. Podesta</td></tr><tr><td>7/24/09</td><td>$500</td><td>Friends of Patrick J. Kennedy</td><td>Rep. Patrick Murphy (RI)</td></tr><tr><td colspan="4">Ms. Young</td></tr><tr><td>7/23/09</td><td>$1000</td><td>PAC to the Future</td><td>Rep. Nancy Pelosi (CA)</td></tr><tr><td>7/28/09</td><td>$1000</td><td>Barbara Lee for Congress</td><td>Rep Barbara Lee (CA)</td></tr><tr><td>7/29/09</td><td>$500</td><td>Clarke for Congress</td><td>Rep Yvette Clarke (NY)</td></tr></table>

LNNNOIYLSIS/SSI/BNO   
85:Hd 92 dS 60z