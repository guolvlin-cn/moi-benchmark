<table><tr><td>1. Name of Registrant</td><td>2. Registration No.</td></tr><tr><td>SCOTTISH DEVELOPMENT AGENCY</td><td>3013</td></tr></table>

3. This amendment is filed to accomplish the following indicated purpose or purposes:

To correct a deficiency in   
□ Initial Statement   
Supplemental Statement for March 31, 1985

To give a 10-day notice of a change in information as required by Section 2(b) of the Act.   
□ Other purpose (specify)

To give notice of change in an exhibit previously filed.

4. If this amendment requires the filing of a document or documents, please list-  
5. Each item checked above must be explained below in full detail together with, where appropriate, specific reference to and identity of the item in the registration statement to which it pertains. If more space is needed, full size insert sheets may be used.

Amendment in reference to item 24 of the Supplemental of March 31, 1985. Did you file with the Registration Section, U.S. Department of Justice, a Dissemination Report for each item of political propaganda as required by Rule 401 of the Act?

Information regarding political propaganda is filed regularly with the Criminal Division of the Justice Department by Homer & Durham who handles all advertising for Scottish Development Agency. The most recent report was filed in July, 1985.

![](images/5f90d4e7-415e-4e5d-8daa-513dc21423c5.jpg)

The undersigned swear(s) or affirm(s) that he has (they have) read the information set forth in this amendment and that he is (they are) familiar with the contents thereof and that such contents are in their entirety true and accurate to the best of his (their) knowledge and belief.

(Both copies of this amendment shall be signed and sworn to before a notary public or other person authorized to administer oaths by the agent, if the registrant is an individual, or by a majority of those partners, officers, directors or persons performing similar functions who are in the United States, if the registrant is an organization.)

Subscribed and sworn to before me at Connecticut National Park. this 29th day of October , 19 85

Notary or other officer)

My Commission Expires March 31, 1988

My commission expires