(File two complete copies)

JUL 30 3 12 PM ECE

REGISTRACTION UNITED STATES DEPARTMENT OF JUSTICE

WASHINGTON, D.C.

Form FA-11

AMENDMENT

TO SUPPLEMENTAL REGISTRATION [ ] EXEMPTION [ ] STATEMENT (Indicate which)

NUMBER 579 FILED 3/31/64

Pursuant to the Foreign Agents Registration Act of 1938 as Amended

Name of registrant (or agent) British Travel Association

Name of foreign principal British Travel and Holidays Association

The answers to the items of the above-mentioned statement listed below are hereby amended to read as follows:

(Insert proper item numbers)

Item No. 10(c). Public Relations expenditure

Travelling & Entertainment § 2,160.

General Office, Stationery

& Printing, etc. 13,199.

Distribution 11,737.

Special Projects $(\ast)$ 12,141.

§39,237.

Item No. $(\ast)$ i.e. Expenses in connection with

(a) Shakespeare Year Quatercentenary $\S 4,544$   
(b) Visit of Scottish Tourist Board official & Salute to Scotland 1,792.   
(c) Visit of B.T.H.A. General Manager 1,549.   
(d) A.S.T.A. Convention, Mexico City 1,309.   
(e) Purchase of copies of January 1964 issue of Travel Trade Magazine 1,489.   
(f) Insertion in Women's Club Magazine 850.   
(g) Miscellaneous British travel visitors to office 608.

![](images/335c864e-a652-44d8-ac53-8dfdc9e1e185.jpg)

Item No.

Item No.

Item No.

(If additional items are to be amended, insert additional pages as needed)

Exhibits. -- The following additional or amended exhibits are attached hereto as a part of this amendment (list exhibits attached)

NOTE. -- The amendment will not be accepted for filing unless both copies are signed and sworn to as required below.

The undersigned swear (s) or affirm (s) that he has (they have) read the information set forth in this amendment to the supplemental statement mentioned above and the attached exhibits, that he is (they are) familiar with the contents thereof and that such contents are in their entirety true and accurate to the best of his (their) knowledge and belief, except that the undersigned make(s) no representation as to the truth or accuracy of information contained in any Exhibit A filed here-with insofar as such information is not within his (their) personal knowledge.

(If the agent is a partnership, corporation, association, or other combination of individuals, this amendment shall be signed and sworn to before a notary public, or other officer authorized to administer oaths, by a majority of those partners, officers, directors, or persons performing similar functions who are in the United States. If no such person is in the United States, the amendment shall be signed and sworn to by the duly authorized representative of the agent.)

![](images/20cbb44e-bb61-4cd4-b41d-6616f53a5d0a.jpg)  
(Signature)   
(Signature)   
(Signature)   
(Signature)

Subscribed and sworn to before me at. this 29 day of , 164

![](images/6a262ca2-05d9-4e76-9918-9e12e0152c3e.jpg)

FRANK E. MARRA
NOTARY PUBLIC, State of New York
No. 60-7728350
My commission expires
Quallied in Westchester County
Commission expires March 30, 1966

GPO 866-416