Form OBD-68

(Rev 10-14-76)

Formerly DJ-307

for

# AMENDMENT TO REGISTRATION STATEMENT

Pursuant to the Foreign Agents

Registration Act of 1938, as amended.

1. Name of Registrant

BRITISH VIRGIN ISLANDS TOURIST BOARD

2. Registration No.

3354

3. This amendment is filed to accomplish the following indicated purpose or purposes:

To correct a deficiency in

Initial Statement

X Supplemental Statement for Item 15A

To give notice of change in an exhibit previously filed.

To give a 10-day notice of a change in information as required by Section 2(b) of the Act.

Other purpose (specify)

![](images/ee4fa037-dc8c-408d-ae7f-dac67a961199.jpg)

4. If this amendment requires the filing of a document or documents, please list -

Disbursements for office operations as of June 30, 1983

5. Each item checked above must be explained below in full detail together with, where appropriate, specific reference to and identity of the item in the registration statement to which it pertains. If

more space is needed, full size insert sheets may be used.

<table><tr><td>OFFICE SUPPLIES</td></tr><tr><td>Travel Allowances</td></tr><tr><td>Salaries</td></tr><tr><td>Rent</td></tr><tr><td>Postage</td></tr><tr><td>Telephone</td></tr><tr><td>Equip./Furniture</td></tr><tr><td>Subscriptions</td></tr><tr><td>Freight</td></tr><tr><td>Clipping Service</td></tr><tr><td>Telex</td></tr><tr><td>Misc.</td></tr></table>

1364.77

700.00

25153.96

9581.78

3974.90

4036.15

2368.05

434.95

1399.58

252.76

662.25

13094.10

![](images/695687fd-0a4e-4392-9b8f-e4ab50d772ec.jpg)

The undersigned swear(s) or affirm(s) that he has (they have) read the information set forth in this amendment and that he is (they are) familiar with the contents thereof and that such contents are in their entirety true and accurate to the best of his (their) knowledge and belief.

（）

(Both copies of this amendment shall be signed and sworn to before a notary public or other person authorized to administer oaths by the agent, if the registrant is an individual, or by a majority of those partners, officers, directors or persons performing similar functions who are in the United States, if the registrant is an organization.)

![](images/d18609b9-2933-4211-98c2-44bf5cd8fcaa.jpg)

Subscribed and sworn to before me at NEW YORK, N.Y.  
this 104th day of August , 1983

My commission expires MARCH 30 1985

![](images/5f099c75-a030-4c72-b49f-d6211fc2568e.jpg)

Notary Public, State of New York
No. 41-4704120
Qualified in Queens County
Commission Expres March 30, 18