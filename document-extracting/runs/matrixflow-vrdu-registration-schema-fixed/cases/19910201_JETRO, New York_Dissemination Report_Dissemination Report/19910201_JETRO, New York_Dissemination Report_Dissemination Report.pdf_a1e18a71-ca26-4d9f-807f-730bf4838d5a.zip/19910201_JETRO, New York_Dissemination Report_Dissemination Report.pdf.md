INSTRUCTIONS: Report must be submitted in duplicate to the Registration Unit, Internal Security Section, Criminal Division, Department of Justice, Washington, D.C. 20530. The original must be signed by or on behalf of the registrant. All items in this form must be answered, unless the answer is "none" or "not applicable," in which case such an entry shall be made in the appropriate space. If additional space is needed for any item, attach supplemental sheet identifying each item.

Privacy Act Statement. Every registration statement, short form registration statement, supplemental statement, exhibit, amendment, dissemination report, copy of political propaganda or other document or information filed with the Attorney General under this act is a public record open to public examination, inspection and copying during the posted business hours of the Registration Unit in Washington, D.C. One copy of every such document is automatically provided to the Secretary of State pursuant to Section 6(b) of the Act, and copies of such documents are routinely made available to other agencies, departments and Congress pursuant to Section 6(c) of the Act. Finally, the Attorney General transmits an annual report to the Congress on the Administration of the Act which lists the names of all agents registered under the Act, the foreign principals they represent, and the nature, sources and content of the political propaganda disseminated or distributed by them. This report is available to the public.

Public Reporting Burden. Public reporting burden for this collection of information is estimated to average .5 hours per response, including the time for reviewing instructions, searching existing data sources, gathering and maintaining the data needed, and completing and reviewing the collection of information. Send comments regarding this burden estimate or any other aspect of this collection of information, including suggestions for reducing this burden to Chief, Registration Unit, Criminal Division, U.S. Department of Justice, Washington, D.C. 20530; and to the Office of Information and Regulatory Affairs, Office of Management and Budget, Washington, D.C. 20503.

<table><tr><td>1. Name of registrant
JETRO, New York</td><td>2. Registration No.
1643</td></tr></table>

3. Nature of material (A concise account of the nature of the propaganda material filed)

News magazine for Japanese technology.

<table><tr><td colspan="2">4. Title of material, if any
NEW TECHNOLOGY JAPAN (October 1990)</td><td colspan="2">5. Name of foreign principal on whose behalf this material was transmitted.
Japan External Trade Organization</td></tr><tr><td>6. Means of transmission
Mail</td><td colspan="2">7. Dates of transmission
January 31, 1991</td><td>8. Total copies transmitted
26</td></tr></table>

<table><tr><td>9. List addresses from which material was transmitted:</td><td colspan="2">10. List states and territories of the United States to which material was transmitted:</td></tr><tr><td>JETRO, New York</td><td>Connecticut</td><td>New York</td></tr><tr><td>1221 Ave. of the Americas</td><td>Maryland</td><td>Pennsylvania</td></tr><tr><td>New York, NY 10020</td><td>Virginia</td><td>New Jersey Washington, DC</td></tr></table>

11. Types of recipients (Give number of organizations in each group)

<table><tr><td>Libraries 7</td></tr><tr><td>Public officials</td></tr><tr><td>Newspapers /magazines 9</td></tr><tr><td>Press services of
associations 2</td></tr><tr><td>Educational
institutions</td></tr><tr><td>Civic groups.</td></tr><tr><td>Other (specify) govt. agencies 4
private cos. 4</td></tr></table>

12. List names and addresses of persons or organizations receiving 100 copies or more:

![](images/d69bf601-320b-4908-bf04-6ca615420abc.jpg)

13. If the material transmitted was a film or radio or television script, furnish the following information:

Name of station, organization, or theater using (including city and state)

Date or dates broadcast shown

Estimated attendance (for film(s))

14. Have two copies of this material been filed with the Department of Justice? Yes No

15. Has this material been labeled as required by the act? Yes No

<table><tr><td>Date of report
Feb. 4, 1991</td><td>Name and title
Kunio Ito
Director, Public Affairs</td><td>Signature</td></tr></table>