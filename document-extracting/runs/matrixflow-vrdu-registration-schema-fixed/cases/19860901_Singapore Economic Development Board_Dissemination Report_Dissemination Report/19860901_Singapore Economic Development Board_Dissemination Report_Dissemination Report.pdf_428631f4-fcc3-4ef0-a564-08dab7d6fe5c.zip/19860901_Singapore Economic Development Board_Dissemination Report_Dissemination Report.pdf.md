INSTRUCTIONS: Report must be submitted in duplicate to the Registration Unit, Internal Security Section, Criminal Division, Department of Justice, Washington, D.C. 20530. The original must be signed by or on behalf of the registrant. All items in this form must be answered, unless the answer is "none" or "not applicable," in which case such an entry shall be made in the appropriate space. If additional space is needed for any item, attach supplemental sheet identifying each item.

<table><tr><td colspan="3">1. Name of registrant
Singapore Economic Development Board</td><td>2. Registration No.
2003</td></tr><tr><td colspan="4">3. Nature of material (A concise account of the nature of the propaganda material filed)
&quot;Economic Development Board Annual Report 1984/1985&quot;</td></tr><tr><td colspan="2">4. Title of material, if any
Economic Development Board Annual Report
1984/1985</td><td colspan="2">5. Name of foreign principal on whose behalf this material was transmitted.
Singapore Economic Development Board</td></tr><tr><td>6. Means of transmission
U.S. Mail</td><td colspan="2">7. Dates of transmission
January/February 1986</td><td>8. Total copies transmitted
30</td></tr><tr><td colspan="2">9. List addresses from which this material was transmitted:
New York Ctr, 745 5th Ave., NY NY 10151
L.A. Ctr, 911 Wilshire Blvd., LA, CA 90017
Chicago Ctr, 233 Nr Michigan Ave., Chicago
IL 60611</td><td colspan="2">10. List states and territories of the United States to which material was transmitted:
A11 States</td></tr><tr><td colspan="2">11. Types of recipients (Give number of organizations in each group)</td><td colspan="2">12. List names and addresses of persons or organizations receiving 100 copies or more:</td></tr><tr><td colspan="4">Libraries</td></tr><tr><td colspan="4">Public officials</td></tr><tr><td colspan="4">Newspapers</td></tr><tr><td colspan="4">Press services of associations</td></tr><tr><td colspan="4">Educational institutions</td></tr><tr><td colspan="4">Civic groups</td></tr><tr><td colspan="4">Other (specify) business corporations</td></tr></table>

13. If the material transmitted was a film or radio or television script, furnish the following information:

Name of station, organization, or theater using (including city and state)

Date or dates broadcast or shown

Estimated attendance (for film(s))

NOT APPLICABLE

14. Have two copies of this material been filed with the Department of Justice? Yes No

15. Has this material been labeled as required by the act? Yes No

<table><tr><td>Date of report
09/15/86</td><td>Name and title
Jonathan Yuen, Staff Director</td><td>Signature
wetha yue</td></tr></table>