UNITED STATES DEPARTMENT OF JUSTICE  
WASHINGTON, D.C. 20530

# AMENDMENT TO REGISTRATION STATEMENT

Pursuant to the Foreign Agents Registration Act of 1938, as amended.

AUG 477475

RESECTS,UNITS INTERVALSECURITY SECHON CRITICALDISHON

1. Name of Registrant NETHERLANDS NATIONAL TOURIST OFFICE

2. Registration No. 619

3. This amendment is filed to accomplish the following indicated purpose or purposes:

X To correct a deficiency in

$\pmb{x}$ Initial Statement

Supplemental Statement for Item 12 and 13

To give notice of change in an exhibit previously filed.

To give a 10-day notice of a change in information as required by Section 2(b) of the Act.

□ Other purpose (specify)

4. If this amendment requires the filing of a document or documents, please list -

5. Each item checked above must be explained below in full detail together with, where appropriate, specific reference to and identity of the item in the registration statement to which it pertains. If more space is needed, full size insert sheets may be used.

The answer to Items 12 and 13 in Initial Statement of course is No.

"THE NETHERLANDS NATIONAL TOURIST OFFICE" is not engaged in and political activity.

The undersigned swear(s) or affirm(s) that he has (they have) read the information set forth in this amendment and that he is (they are) familiar with the contents thereof and that such contents are in their entirety true and accurate to the best of his (their) knowledge and belief.

(Both copies of this amendment shall be signed and sworn to before a notary public or other person authorized to administer oaths by the agent, if the registrant is an individual, or by a majority of those partners, officers, directors or persons performing similar functions who are in the United States, if the registrant is an organization.)

Subscribed and sworn to before me at this day of , 19

My commission expires

Henry Fisher, Deputy Director

A. (1) (2) (3) (4) (5) (6) (7) (8) (9) (10) (11) (12) (13) (14) (15) (16) (17) (18) (19) (20) (21) (22) (23) (24) (25) (26) (27) (28) (29) (30) (31) (32) (33) (34) (35) (36) (37) (38) (39) (40) (41) (42) (43) (44) (45) (46) (47) (48) (49) (50) (51) (52) (53) (54) (55)

Netherlands/National Tourist Office 576 FIFTH AVENUE NEW YORK, N. Y. 10036