# UNITED STATES DEPARTMENT OF JUSTICE  
WASHINGTON, D.C. 20530

Form OBD-68

(Rev 10-14-76)

Formerly DJ-307

for

OM8 No.41-B226

Approval Expires Oct. 31, 1981

# AMENDMENT TO REGISTRATION STATEMENT

Pursuant to the Foreign Agents

Registration Act of 1938, as amended.

1. Name of Registrant

ARNOLD & PORTER

2. Registration No.

1750

3. This amendment is filed to accomplish the following indicated purpose or purposes:

To correct a deficiency in

Initial Statement

Supplemental Statement for June 4, 1980

To give notice of change in an exhibit previously filed.

To give a 10-day notice of a change in information as required by Section 2(b) of the Act.

□ Other purpose (specify)

4. If this amendment requires the filing of a document or documents, please list -

N/A

5. Each item checked above must be explained below in full detail together with, where appropriate, specific reference to and identity of the item in the registration statement to which it pertains. If more space is needed, full size insert sheets may be used.

See Attachment A

![](images/87dd0752-59fc-461a-b264-0e0a86b3e470.jpg)

The undersigned swear(s) or affirm(s) that he has (they have) read the information set forth in this amendment and that he is (they are) familiar with the contents thereof and that such contents are in their entirety true and accurate to the best of his (their) knowledge and belief.

(Both copies of this amendment shall be signed and sworn to before a notary public or other person authorized to administer oaths by the agent, if the registrant is an individual, or by a majority of those partners, officers, directors or persons performing similar functions who are in the United States, if the registrant is an organization.)

![](images/a6b35cbe-cfee-4079-b9e2-f5903b691726.jpg)

Subscribed and sworn to before me at Washington, DC this/2 day of October 198 Dusay Waselewke (Notary or other officer)

My commission expires My Commission Expres March 14, 1985

# ATTACHMENT A

5. Each item checked above must be explained below in full detail together with, where appropriate, specific reference to and identity of the item in the registration statement to which it pertains. If more space is needed, full size insert sheets may be used.

With respect to item 15(a):

Sati Rikhy rendered services as a legal assistant in connection with an antidumping proceeding conducted by the Commerce and Treasury departments, and in connection with the compilations of import statistics for the Ambassador of the Swiss Confederation and the Federation Suisse des Associations de Fabricants d'Horlogerie.

James Edmondson rendered services as an economic development consultant in connection with the financing of housing to be built in the State of Israel.

Charles R. Mann, Associates rendered computer services in connection with an antidumping proceeding conducted by the Commerce and Treasury departments.

Wendar, Murare & White rendered services as legal consultants in connection with an antidumping proceeding conducted by the Commerce and Treasury departments.

Richard L. Simmons, Jimmy E. Hillman, Robert S. Firch, Richard King, and H. S. Houtakker rendered services as economic consultants in connection with an antidumping proceeding conducted by the Commerce and Treasury departments.

John H. Jackson rendered services as a legal consultant in connection with an antidumping proceeding conducted by the Commerce and Treasury departments.