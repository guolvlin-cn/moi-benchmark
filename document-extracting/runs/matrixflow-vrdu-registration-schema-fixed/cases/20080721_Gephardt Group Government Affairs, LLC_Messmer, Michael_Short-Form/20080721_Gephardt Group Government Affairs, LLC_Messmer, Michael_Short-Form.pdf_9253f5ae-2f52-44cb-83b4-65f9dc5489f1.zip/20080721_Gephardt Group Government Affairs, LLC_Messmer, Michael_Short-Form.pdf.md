Each partner, officer, director, associate, employee, and agent of a registrant is required to file a short form registration statement unless he engages in no activities in furtherance of the interests of the registrant's foreign principal or unless the services he renders to the registrant are in a secretarial, clerical, or in a related or similar capacity.

Privacy Act Statement. The filing of this document is required by the Foreign Agents Registration Act of 1938, as amended, 22 U.S.C. § 611 et seq., for the purposes of registration under the Act and public disclosure. Provision of the information requested is mandatory, and failure to provide this information is subject to the penalty and enforcement provisions established in Section 8 of the Act. Every registration statement, short form registration statement, exhibit, amendment, copy of informational materials or other document or information filed with the Attorney General under this Act is a public record open to public examination, inspection and copying during the posted business hours of the Registration Unit in Washington, DC. Statements are also available online at the Registration Unit's webpage: http://www.fara.gov/. One copy of every such document, other than informational materials, is automatically provided to the Secretary of State pursuant to Section 6(b) of the Act, and copies of any and all documents are routinely made available to other agencies, departments and Congress pursuant to Section 6(c) of the Act. The Attorney General also transmits a semi-annual report to Congress on the Administration of the Act which lists the names of all agents registered under the Act and the foreign principals they represent. This report is available to the public in print and online at: http://www.fara.gov/.

Public Reporting Burden. Public reporting burden for this collection of information is estimated to average .429 hours per response, including the time for reviewing instructions, searching existing data sources, gathering and maintaining the data needed, and completing and reviewing the collection of information. Send comments regarding this burden estimate or any other aspect of this collection of information, including suggestions for reducing this burden to Chief, Registration Unit, Counterspionage Section, National Security Division, U.S. Department of Justice, Washington, DC 20530; and to the Office of Information and Regulatory Affairs, Office of Management and Budget, Washington, DC 20503.

<table><tr><td>1. Name
Michael Messmer</td><td>2. Registration No.</td><td>5874</td></tr><tr><td>3. Residence Address(es)
1833 New Hampshire Ave, NW
Apt. 503
Washington, DC 20009</td><td>4. Business Address(es)
1101 K Street, NW
8th Floor
Washington, DC 20005</td><td>2008
Jul
2</td></tr><tr><td>5. Year of Birth     1973
Nationality American
Present Citizenship US</td><td>6. If present citizenship was not acquired by birth,
indicate when, and how acquired</td><td>PM
2:59</td></tr><tr><td colspan="3">7. Occupation
Consultant/Lobbyist</td></tr></table>

5. What is the name and address of the primary registrant?

Name

Gephardt Group, LLC

Address

1101 K Street, NW 8th Floor

Washington, DC 20005

9. Indicate your connection with the primary registrant:

□

partner

#

officer

□

other (specify)

□ director

□ associate

employee

agent

□ consultant

□ subcontractor

10. List every foreign principal to whom you will render services in support of the primary registrant.

Republic of Turkey

11. Describe separately and in detail all services which you will render to the foreign principal(s) listed in Item 10 either directly, or through the primary registrant listed in Item 8, and the date(s) of such services. (If space is insufficient, a full page insert must be used.)

*see attachment

12. Do any of the above described services include political activity as defined in Section 1(o) of the Act and in the footnote below?

Yes No

If yes, describe separately and in detail such political activity.

*see question 11 above

13. The services described in Items 11 and 12 are to be rendered on a

□ full time basis

part time basis

special basis

14. What compensation or thing of value have you received to date or will you receive for the above services?

Salary:

Amount $

$\frac{1}{2}x - 1 > 0$

per

□

Commission at

% of

$\boxtimes$ Salary: Not based solely on services rendered to the foreign principal(s).

![](images/6349a5a0-f643-4df1-9e0d-507caeb45ea5.jpg)

Fee: Amount $

__________

![](images/e8ed846b-7b9b-4d32-b8e2-0db3f39884ca.jpg)

Other thing of value

__________

15. During the period beginning 60 days prior to the date of your obligation to register to the time of filing this statement, did you make any contributions of money or other things of value from your own funds or possessions and on your own behalf in connection with any election to political office or in connection with any primary election, convention, or caucus held to select candidates for any political office? Yes No

If yes, furnish the following information:

Date

Amount of thing of value

3/15/08

$2,000

3/10/08

$10,000

5/20/08

$2,000

Name of political organization

Russ Carnahan in Congress

Democratic Congressional Campaign Committee

Rob Andrews for Congress Committee

Name of

candidate

Russ Carnahan

Rob Andrews

# EXECUTION

In accordance with 28 U.S.C. § 1746, the undersigned swears or affirm(s) under penalty of perjury that he/she has read the information set forth in this registration statement and that he/she is familiar with the contents thereof and that such contents are in their entirety true and accurate to the best of his/her knowledge and belief.

712108

(Date of signature)

Rahala. Layla

(Signature)

# FARA Registration

# Short Form

11. Describe separately and in detail all services which you will render to the foreign principal(s) listed in Item 10 either directly, or through the primary registrant listed in Item 8, and the date(s) of such services. (If space is insufficient, a full page insert must be used)

a) Proposing and pursuing passage of legislation and other U.S. government actions that promote Turkey's interests and provide a positive image of Turks, Turkey and the U.S.-Turkey relationship,   
b) Preserving and enlarging the Congressional Caucus on Turkey and Turkish Americans,   
c) Identifying and educating members of Congress who will speak in Turkey's favor on matters of critical importance to Turkey, including its most controversial issues,   
d) Educating members of Congress and the Administration on issues of importance to Turkey,   
e) Promptly notifying Turkey of any action in Congress or the Executive Branch on issues of importance to Turkey,   
f) Preparing brief analyses of developments in Congress and the Executive Branch on particular issues of concern to Turkey,   
g) Identifying official gatherings and social events to which Embassy personnel ought, in Gephardt Group's opinion, attend, including to the extent possible, obtaining the necessary invitations,   
h) Identifying and/or arranging speaking engagements locally and nationally for Embassy personnel or their appointed or suggested proxies in fora that will improve Turkey's image and advance its causes on Capitol Hill. Such would be, if directed by Turkey, coordinated with Turkey's existing public relations services provider[s],   
i) Informally advising Turkish-American organizations as requested from time to time by Turkey,   
j) Maintaining and forging alliances with other interest groups whose goals are similar to or shared by Turkey.