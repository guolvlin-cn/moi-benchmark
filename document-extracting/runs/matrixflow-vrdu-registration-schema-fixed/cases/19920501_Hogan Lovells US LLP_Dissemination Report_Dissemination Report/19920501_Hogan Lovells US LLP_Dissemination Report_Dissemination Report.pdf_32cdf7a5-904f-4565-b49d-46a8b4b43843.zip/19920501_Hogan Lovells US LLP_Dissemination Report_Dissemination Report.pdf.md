INSTRUCTIONS: Report must be submitted in duplicate to the Registration Unit, Internal Security Section, Criminal Division, Department of Justice, Washington, D.C. 20530. The original must be signed by or on behalf of the registrant. All items in this form must be answered, unless the answer is "none" or "not applicable," in which case such an entry shall be made in the appropriate space. If additional space is needed for any item, attach supplemental sheet identifying each item.

Privacy Act Statement. Every registration statement, short form registration statement, supplemental statement, exhibit, amendment, dissemination report, copy of political propaganda or other document or information filed with the Attorney General under this act is a public record open to public examination, inspection and copying during the posted business hours of the Registration Unit in Washington, D.C. One copy of every such document is automatically provided to the Secretary of State pursuant to Section 6(b) of the Act, and copies of such documents are routinely made available to other agencies, departments and Congress pursuant to Section 6(c) of the Act. Finally, the Attorney General transmits an annual report to the Congress on the Administration of the Act which lists the names of all agents registered under the Act, the foreign principals they represent, and the nature, sources and content of the political propaganda disseminated or distributed by them. This report is available to the public.

Public Reporting Burden. Public reporting burden for this collection of information is estimated to average .5 hours per response, including the time for reviewing instructions, searching existing data sources, gathering and maintaining the data needed, and completing and reviewing the collection of information. Send comments regarding this burden estimate or any other aspect of this collection of information, including suggestions for reducing this burden to Chief, Registration Unit, Criminal Division, U.S. Department of Justice, Washington, D.C. 20530; and to the Office of Information and Regulatory Affairs, Office of Management and Budget, Washington, D.C. 20503.

<table><tr><td colspan="3">1. Name of registrant 555 13th St., N.W.Hogan &amp; Hartson Washington, D.C. 20004</td><td>2. Registration No.2244</td></tr><tr><td colspan="4">3. Nature of material (A concise account of the nature of the propaganda material filed)Memorandum outlining responses of United Microelectronics Corporation (&quot;UMC&quot;) tocopyright infringement charges by Nintendo</td></tr><tr><td colspan="2">4. Title of material, if anyNone</td><td colspan="2">5. Name of foreign principal on whose behalf this material wastransmitted.UMC</td></tr><tr><td>6. Means of transmissionHand delivery</td><td colspan="2">7. Dates of transmission5/20/92-6/1/92</td><td>&amp; Total copies transmitted15</td></tr><tr><td colspan="2">9. List addresses from which material was transmitted:Hogan &amp; Hartson555 13th St., N.W.Washington, D.C. 20004Wilson, Sonsini, Goodrich &amp; RosatiTwo Palo Alto Square, Suite 900Palo Alto, CA 94306</td><td colspan="2">10. List states and territories of the United States to whichmaterial was transmitted:Washington, D.C.</td></tr><tr><td colspan="2">11. Types of recipients (Give number of organizationsin each group)Libraries—Congressional and Administration staffPublic officials (approx. 10 Congressional; 5 Adminisstration)Newspapers—Press services of associationsEducational institutionsCivic groupsOther (specify)</td><td colspan="2">12. List names and addresses of persons or organizationsreceiving 100 copies or more:Newspapers</td></tr></table>

13. If the material transmitted was a film or radio or television script, furnish the following information:

Name of station, organization, or theater using (including city and state)

Date or dates broadcast shown

Estimated attendance (for film(s))

Not applicable

14. Have two copies of this material been filed with the Department of Justice? Yes No See attached   
15. Has this material been labeled as required by the act? Yes No

<table><tr><td>Date of report
5/20/92</td><td>Name and title
Mark S. McConnell
Partner</td><td>Signature
a/b/c/df/hj</td></tr></table>