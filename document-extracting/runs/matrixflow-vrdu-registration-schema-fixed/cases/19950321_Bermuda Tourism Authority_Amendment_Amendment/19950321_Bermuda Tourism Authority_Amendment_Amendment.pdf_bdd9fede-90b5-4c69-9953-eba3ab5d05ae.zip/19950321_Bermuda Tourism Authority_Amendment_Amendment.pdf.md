Privacy Act Statement. Every registration statement, short form registration statement, supplemental statement, exhibit, amendment, dissemination report, copy of political propaganda or other document or information filed with the Attorney General under this act is a public record open to public examination, inspection and copying during the posted business hours of the Registration Unit in Washington, D.C. One copy is automatically provided to the Secretary of State pursuant to Section 6(b) of the Act, and copies of such documents are routinely made available to other agencies, departments and Congress pursuant to Section 6(c) of the Act. Finally, the Attorney General transmits an annual report to the Congress on the Administration of the Act which lists the names of all agents and the nature, sources and content of the political propaganda disseminated or distributed by them. This report is available to the public.

Public Reporting Burden. Public reporting burden for this collection of information is estimated to average 1.5 hours per response, including the time for reviewing instructions, searching existing data sources, gathering and maintaining the data needed, and completing and reviewing the collection of information. Send comments regarding this burden estimate or any other aspect of this collection of information, including suggestions for reducing this burden to Chief, Registration Unit, Criminal Division, U.S. Department of Justice, Washington, D.C. 20530; and to the Office of Information and Regulatory Affairs, Office of Management and Budget, Washington, D.C. 20503.

<table><tr><td>Ⅰ. Name of Registrant
Bermuda Department of Tourism</td><td>2. Registration No.
# 430</td></tr></table>

3. This amendment is filed to accomplish the following indicated purpose or purposes:

To correct a deficiency in

To give a 10-day notice of a change in information as required by Section 2(b) of the Act.

□ Initial Statement

□ Supplemental Statement for

Other purpose (specify) Explanation

To give notice of change in an exhibit previously filed.

4. If this amendment requires the filing of a document or documents, please list

N/A

5. Each item checked above must be explained below in full detail together with, where appropriate, specific reference to and identity of the item in the registration statement to which it pertains. If more space is needed, full size insert sheets may be used.

This amendment is filed in order to report that Darlene Ming is no longer an employee of the registrant. She is no longer residing in the United States, and therefore, is unable to complete a short-form registration.

![](images/9de8faff-3e27-4067-ae49-ec11aeaa86fc.jpg)

The undersigned swear(s) or affirm(s) that he has (they have) read the information set forth in this amendment and that he is (they are) familiar with the contents thereof and that such contents are in their entirety true and accurate to the best of his (their) knowledge and belief.

Paral 3a1

Paul Zar, Director of Sales, NA

(All copies of this amendment shall be signed and sworn to before a notary public or other person authorized to administer oaths by the agent, if the registrant is an individual, or by a majority of those partners, officers, directors or persons performing similar functions who are in the United States, if the registrant is an organization.)

Subscribed and sworn to before me at 310 Madison Ave, N.Y., N.Y. 10017 this $20 ^ { \text{一} }$ day of March ,19 95 fide/ (Notary or other officer)

My commission expires

M

LINDA MOTTELER

Notary Public, State of New York

No. 01MO4930099

Qualified in Kings County

Quanrned in Kings County 60 Commission Expres May 9,197

![](images/968890c7-3218-4bff-bd80-b35a760715c7.jpg)