INSTRUCTIONS: Report must be submitted in duplicate to the Registration Unit, Internal Security Section, Criminal Division, Department of Justice, Washington, D.C.

13. If the material transmitted was a film or radio or television script, furnish the following information:

Name of station, organization, or theater using (including city and state)

Date or dates broadcast shown

Estimated attendance (for film(s))

# Not Applicable

14. Have two copies of this material been filed with the Department of Justice? Yes X No []   
15. Has this material been labeled as required by the act? Yes X No []

Date of report

October 16, '92

Name and title

Eiichi Nagata

Executive Director

Signature

![](images/bbc56cd3-6553-47b5-97d5-c57edf2acd2c.jpg)