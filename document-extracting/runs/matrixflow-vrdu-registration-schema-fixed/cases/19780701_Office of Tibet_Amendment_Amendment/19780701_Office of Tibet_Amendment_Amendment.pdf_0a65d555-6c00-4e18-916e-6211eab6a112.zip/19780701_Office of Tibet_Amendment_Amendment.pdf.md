# UNITED STATES DEPARTMENT OF JUSTICE  
WASHINGTON, D.C. 20530

Form OBD-68

(Rev 10-14-76)

Formerly DJ-307 for

# AMENDMENT TO REGISTRATION STATEMENT

Pursuant to the Foreign Agents

Registration Act of 1938, as amended.

H

NO103S

1. N017HIs 13

$\left( {x - 1}\right) \left( {x + 3}\right)  = 0$

10

1

1. Name of Registrant

The Office of Tibet

2. Registration No.

1699

3. This amendment is filed to accomplish the following indicated purpose or purposes:

To correct a deficiency in

Initial Statement

Supplemental Statement for

To give notice of change in an exhibit previously filed.

To give a 10-day notice of a change in information as required by Section 2(b) of the Act.

□ Other purpose (specify)

4. If this amendment requires the filing of a document or documents, please list -

![](images/f1d1d904-3cfc-4144-924d-74d4a94b848e.jpg)

![](images/471978ac-4a20-4cd1-ab52-0a67515b2ab1.jpg)

5. Each item checked above must be explained below in full detail together with, where appropriate, specific reference to and identity of the item in the registration statement to which it pertains. If more space is needed, full size insert sheets may be used.

The undersigned swear(s) or affirm(s) that he has (they have) read the information set forth in this amendment and that he is (they are) familiar with the contents thereof and that such contents are in their entirety true and accurate to the best of his (their) knowledge and belief.

(Both copies of this amendment shall be signed and sworn to before a notary public or other person authorized to administer oaths by the agent, if the registrant is an individual, or by a majority of those partners, officers, directors or persons performing similar functions who are in the United States, if the registrant is an organization.)

![](images/834d56ea-f406-4acb-8a82-e805e4310d97.jpg)

Subscribed and sworn to before me at fcc 2 aee this 11 day of July , 1978

My commission expires

![](images/1112a248-b6d9-49c7-b119-5e6f4855fd69.jpg)

Salaries

Tenzin N. Tethong $\$ 4,500.00$

Tinley N. Akar 3,900.00

Total

$8,400.00

Travel

Tenzin N. Tethong 32.00

Tenzin N. Tethong 59.15

Tenzin N. Tethong 28.50

Tenzin N. Tethong 87.90

Total

208.05

Tenzin N. Tethong (travel expenses in India)

400.00

Travelmat

112.00

Pan American Air Lines

1,902.00

Tseten Tsarong

15.00

Total expenses on travel

2,637.05

# Entertainment

International League for Human Rights (reception fee)

25.00

Grand total

$11,062.05