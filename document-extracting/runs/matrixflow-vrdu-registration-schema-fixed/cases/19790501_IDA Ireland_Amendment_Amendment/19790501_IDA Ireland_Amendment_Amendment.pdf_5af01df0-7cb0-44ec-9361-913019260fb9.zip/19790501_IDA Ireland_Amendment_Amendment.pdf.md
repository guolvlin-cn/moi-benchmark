# AMENDMENT TO REGISTRATION STATEMENT

Pursuant to the Foreign Agents Registration Act of 1938, as amended.

<table><tr><td>1. Name of Registrant
Industrial Development Authority
Ireland</td><td>2. Registration No.
1770</td></tr></table>

3. This amendment is filed to accomplish the following indicated purpose or purposes:

To correct a deficiency in

Initial Statement

Supplemental Statement for Jan 1979.

To give notice of change in an exhibit previously filed.

To give a 10-day notice of a change in information as required by Section 2(b) of the Act.

□ Other purpose (specify)

4. If this amendment requires the filing of a document or documents, please list -

Appendix a)

5. Each item checked above must be explained below in full detail together with, where appropriate, specific reference to and identity of the item in the registration statement to which it pertains. If more space is needed, full size insert sheets may be used.

Item 15A Disbursements.

(iii) Travel and representation $137,808
Expenditure by project officers incurred when visiting industrial corporations.

(xii) Public Relations Expenditure $121,758
Expenditure incurred in organising events listed in item 13
in providing printed material referred to in items 16 - 24 and in
hiring the service of Robert Marston Associates 645 Madison Avenue
New York NY 10022 ($50,000)

(xiv) See separate appendix.

The undersigned swear(s) or affirm(s) that he has (they have) read the information set forth in this amendment and that he is (they are) familiar with the contents thereof and that such contents are in their entirety true and accurate to the best of his (their) knowledge and belief.

(Both copies of this amendment shall be signed and sworn to before a notary public or other person authorized to administer oaths by the agent, if the registrant is an individual, or by a majority of those partners, officers, directors or persons performing similar functions who are in the United States, if the registrant is an organization.)

![](images/1cc4bd3d-f001-4a01-bc86-45f44a014421.jpg)

STATE OF NEW YORK Subscribed and sworn to cONnMcT NEW YORK SWORN TO BEFORE ME this day of THIS

My commission expires

![](images/35829a05-64a5-4425-987e-740d02ff5ef5.jpg)

No. 41-7775665 Qualified in Queens County Certificate Filed in New York County Term Expires March 30, 19

Period - July - Jan 1979

0000

EATAPENT OF JUSTICE

May 17 945 AHI'79

(xiv) Consultancies & expenses

REGISTRATION UNIT

CRIMINAL DIVISION

July

Joe Cornyn $6,600.00

AICPA 13.92

Ass. Corp. Growth 70.00

Dun & Bradstreet 2.75

August

Don Worth 700.00

Dun & Bradstreet 95.00

Joe Cornyn 1,200.00

September

Assoc. Corp Growth 20.00

North Amer. Soc.

Corp Planning 60.00

AICPA 96

Joe Cornyn 600.00

Dun & Bradstreet 7.60

November

Joe Cornyn 9,000.00

Mr. Stevens 960.00 (Canada)

We have also paid $3,772 to Business International for information services.