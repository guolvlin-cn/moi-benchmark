# AMENDMENT TO REGISTRATION STATEMENT

Pursuant to the Foreign Agents Registration Act of 1938, as amended.

1. Name of Registrant Austrian State Tourist Dept. Rudolf F. Mattesich

2. Registration No.

495

3. This amendment is filed to accomplish the following indicated purpose or purposes:

To correct a deficiency in

Initial Statement   
X Supplemental Statement for June 30, 1967

To give a 10-day notice of a change in information as required by Section 2(b) of the Act.

Other purpose (specify)

To give notice of change in an exhibit previously filed.   
4. If this amendment requires the filing of a document or documents, please list -   
5. Each item checked above must be explained below in full detail together with, where appropriate, specific reference to and identity of the item in the registration statement to which it pertains. If more space is needed, full size insert sheets may be used.

Corrections to Items 8 and 10, - foreign principals are as follows: Oesterr. Fremdenverkehrswerbung Vienna I., (Austrian State Tourist Department) Hohenstaufengasse 3-5

Oesterr. Bundesbahnen Vienna I., (Austrian Federal Railways) Elisabethstrasse 9

Item 14(a) Monthly budget is transferred from Vienna each month amount $6,450.00

The undersigned swear(s) or affirm(s) that he has (they have) read the information set forth in this amendment and that he is (they are) familiar with the contents thereof and that such contents are in their entirety true and accurate to the best of his (their) knowledge and belief.

(Both copies of this amendment shall be signed and sworn to before a notary public or other person authorized to administer oaths by the agent, if the registrant is an individual, or by a majority of those partners, officers, directors or persons performing similar functions who are in the United States, if the registrant is an organization.)

A. Fmull

Rudolf F. Mattesich

Subscribed and sworn to before me at

this day of

ROSE RAPCH

HOSE 1898

No. 41-8502400

Qualified in Queens County Cert. filed with Co. Clk. & Re

Commission Expires March 30, 1968