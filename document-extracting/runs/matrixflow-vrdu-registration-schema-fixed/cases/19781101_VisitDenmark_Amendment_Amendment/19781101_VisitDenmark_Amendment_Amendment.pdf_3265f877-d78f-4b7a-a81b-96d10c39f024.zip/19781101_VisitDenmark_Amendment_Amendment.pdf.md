# UNITED STATES DEPARTMENT OF JUSTICE

WASHINGTON, D.C. 20530

#

DEPAHON. NOLTICE

Form OBD-68

(Rev 10-14-76)

Formerly DJ-307

for

Now 5

新闻

0

# AMENDMENT TO REGISTRATION STATEMENT

Pursuant to the Foreign Agents

Registration Act of 1938, as amended.

1. Name of Registrant

Steen Lovschal

2. Registration No.

634

3. This amendment is filed to accomplish the following indicated purpose or purposes:

To correct a deficiency in

Initial Statement   
Supplemental Statement for

To give a 10-day notice of a change in information as required by Section 2(b) of the Act.   
□ Other purpose (specify)

To give notice of change in an exhibit previously filed.

4. If this amendment requires the filing of a document or documents, please list-  
5. Each item checked above must be explained below in full detail together with, where appropriate, specific reference to and identity of the item in the registration statement to which it pertains. If more space is needed, full size insert sheets may be used.

An answer to Item 15 was erroneously omitted from our original registration statement.

Our answer to the Item 15 is - NO.

The undersigned swear(s) or affirm(s) that he has (they have) read the information set forth in this amendment and that he is (they are) familiar with the contents thereof and that such contents are in their entirety true and accurate to the best of his (their) knowledge and belief.