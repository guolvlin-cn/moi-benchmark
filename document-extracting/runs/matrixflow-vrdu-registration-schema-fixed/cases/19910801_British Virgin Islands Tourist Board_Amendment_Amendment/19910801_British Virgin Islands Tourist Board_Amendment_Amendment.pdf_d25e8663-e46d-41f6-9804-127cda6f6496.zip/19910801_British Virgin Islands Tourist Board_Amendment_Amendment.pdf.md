Privacy Act Statement. Every registration statement, short form registration statement, supplemental statement, exhibit, amendment, dissemination report, copy of political propaganda or other document or information filed with the Attorney General under this act is a public record open to public examination, inspection and copying during the posted business hours of the Registration Unit in Washington, D.C. One copy is automatically provided to the Secretary of State pursuant to Section 6(b) of the Act, and copies of such documents are routinely made available to other agencies, departments and Congress pursuant to Section 6(c) of the Act. Finally, the Attorney General transmits an annual report to the Congress on the Administration of the Act which lists the names of all agents and the nature, sources and content of the political propaganda disseminated or distributed by them. This report is available to the public.

Public Reporting Burden. Public reporting burden for this collection of information is estimated to average 1.5 hours per response, including the time for reviewing instructions, searching existing data sources, gathering and maintaining the data needed, and completing and reviewing the collection of information. Send comments regarding this burden estimate or any other aspect of this collection of information, including suggestions for reducing this burden to Chief, Registration Unit, Criminal Division, U.S. Department of Justice, Washington, D.C. 20530; and to the Office of Information and Regulatory Affairs, Office of Management and Budget, Washington, D.C. 20503.

1. Name of Registrant

British Virgin Islands Tourist Board

2. Registration No. 3354

3. This amendment is filed to accomplish the following indicated purpose or purposes:

To correct a deficiency in   
□ Initial Statement   
□ Supplemental Statement for   
To give notice of change in an exhibit previously filed.

To give a 10-day notice of a change in information as required by Section 2(b) of the Act.   
□ Other purpose (specify) Toshow date, to when, purpose and amount of disbursement for Advertising and Public Relations as stated in letter of May 6, 1991 Peroid Ending October 8, 1990

4. If this amendment requires the filing of a document or documents, please list-  
5. Each item checked above must be explained below in full detail together with, where appropriate, specific reference to and identity of the item in the registration statement to which it pertains. If more space is needed, full size insert sheets may be used.

The undersigned swear(s) or affirm(s) that he has (they have) read the information set forth in this amendment and that he is (they are) familiar with the contents thereof and that such contents are in their entirety true and accurate to the best of his (their) knowledge and belief.

![](images/5fb684e2-053a-4605-9b16-3327ccbf7ba8.jpg)

(All copies of this amendment shall be signed and sworn to before a notary public or other person authorized to administer oaths by the agent, if the registrant is an individual, or by a majority of those partners, officers, directors or persons performing similar functions who are in the United States, if the registrant is an organization.)

(Notary or other officer)

My commission expires JOAN ZITO Notary Public, State of New York No.41-9608950 -Queens County Certificate Filed In New York City Commission Expires July 31, 19 .92

# PERIOD ENDING OCTOBER 8, 1990:

<table><tr><td>TO WHOM</td><td>PURPOSE</td><td>DATES</td><td>AMOUNT</td></tr><tr><td>SCOTT - TEDESCHI</td><td>Preparation of</td><td>APR. 10, 1990</td><td>12,499.83</td></tr><tr><td>10 Overhill Ln.</td><td>Advertising Strategies</td><td>APR. 11, 1990</td><td>20,420.00</td></tr><tr><td>Roslyn, NY 11576</td><td>Print Advertising,</td><td>MAY 16, 1990</td><td>41,702.54</td></tr><tr><td></td><td>Public Relations:</td><td>JUN. 22, 1990</td><td>28,470.67</td></tr><tr><td></td><td>Press Trips,</td><td>JUL. 6, 1990</td><td>13,134.91</td></tr><tr><td></td><td>Press Releases,</td><td>JUL. 6, 1990</td><td>33,359.84</td></tr><tr><td></td><td>Press Kits,</td><td>JUL. 25, 1990</td><td>19,773.33</td></tr><tr><td></td><td>Photography,</td><td>AUG. 22, 1990</td><td>17,736.09</td></tr><tr><td></td><td>Retainer Fees.</td><td>SEP. 26, 1990</td><td>12,342.96</td></tr><tr><td></td><td></td><td></td><td>$199,440.17</td></tr><tr><td>INTERMARKETING</td><td>Preparation Of</td><td>MAY 1, 1990</td><td>$20,281.88</td></tr><tr><td>767 5th Ave.</td><td>Advertising Strategies,</td><td></td><td></td></tr><tr><td>New York, NY 10153</td><td>Retainer Fees.</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>$219,722.05</td></tr></table>

Note: During this period the Advertising was changed to the firm of Intermarketing. Scott - Tedeschi continued with the Public Relations.