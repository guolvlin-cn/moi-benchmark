# AMENDMENT TO REGISTRATION STATEMENT

Pursuant to the Foreign Agents Registration Act of 1938, as amended.

1. Name of Registrant

Moroccan National Tourist Office

2. Registration No.

1793

3. This amendment is filed to accomplish the following indicated purpose or purposes:

To correct a deficiency in

Initial Statement

Supplemental Statement for 123174

To give notice of change in an exhibit previously filed.

To give a 10-day notice of a change in information as required by Section 2(b) of the Act.

□ Other purpose (specify)

4. If this amendment requires the filing of a document or documents, please list -

# Printed matter questionnaire

5. Each item checked above must be explained below in full detail together with, where appropriate, specific reference to and identity of the item in the registration statement to which it pertains. If more space is needed, full size insert sheets may be used.

Item 11: Past tence was meant (read "has been instead of"will")

25 B : The answer is No

15 B: The answer is yes. This office disseminated over 5000 brochures, pamphlets, posters and booklets to travel agents and tour operators all over the East Cost.

The undersigned swear(s) or affirm(s) that he has (they have) read the information set forth in this amendment and that he is (they are) familiar with the contents thereof and that such contents are in their entirety true and accurate to the best of his (their) knowledge and belief.

(Both copies of this amendment shall be signed and sworn to before a notary public or other person authorized to administer oaths by the agent, if the registrant is an individual, or by a majority of those partners, officers, directors or persons performing similar functions who are in the United States, if the registrant is an organization.)

alldlaeau

Subscribed and sworn to before me at

this 11 day of Ays

My commission expires

![](images/5300d783-cfd3-4a5a-a9dc-c9175a550ec2.jpg)