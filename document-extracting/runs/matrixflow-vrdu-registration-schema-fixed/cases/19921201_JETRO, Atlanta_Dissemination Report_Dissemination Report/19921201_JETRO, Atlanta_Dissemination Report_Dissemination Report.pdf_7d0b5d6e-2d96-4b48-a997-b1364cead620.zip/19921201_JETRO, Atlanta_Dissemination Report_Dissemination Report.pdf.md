INSTRUCTIONS: Report must be submitted in duplicate to the Registration Unit, Internal Security Section, Criminal Division, Department of Justice, Washington, D.C. 20530. The original must be signed by or on behalf of the registrant. All items in this form must be answered, unless the answer is "none" or "not applicable," in which case such an entry shall be made in the appropriate space. If additional space is needed for any item, attach supplemental sheet identifying each item.

Privacy Act Statement. Every registration statement, short form registration statement, supplemental statement, exhibit, amendment, dissemination report, copy of political propaganda or other document or information filed with the Attorney General under this act is a public record open to public examination, inspection and copying during the posted business hours of the Registration Unit in Washington, D.C. One copy of every such document is automatically provided to the Secretary of State pursuant to Section 6(b) of the Act, and copies of such documents are routinely made available to other agencies, departments and Congress pursuant to Section 6(c) of the Act. Finally, the Attorney General transmits an annual report to the Congress on the Administration of the Act which lists the names of all agents registered under the Act, the foreign principals they represent, and the nature, sources and content of the political propaganda disseminated or distributed by them. This report is available to the public.

Public Reporting Burden. Public reporting burden for this collection of information is estimated to average .5 hours per response, including the time for reviewing instructions, searching existing data sources, gathering and maintaining the data needed, and completing and reviewing the collection of information. Send comments regarding this burden estimate or any other aspect of this collection of information, including suggestions for reducing this burden to Chief, Registration Unit, Criminal Division, U.S. Department of Justice, Washington, D.C. 20530; and to the Office of Information and Regulatory Affairs, Office of Management and Budget, Washington, D.C. 20503.

<table><tr><td colspan="3">1. Name of registrant
JETRO Atlanta</td><td>2. Registration No.
4069</td></tr><tr><td colspan="4">3. Nature of material (A concise account of the nature of the propaganda material filed)
newsletter on Japanese economic and trade issues (energy, American business in Japan)</td></tr><tr><td colspan="2">4. Title of material, if any
JETRO MONITOR
November 1992
Vol. 7, No. 8</td><td colspan="2">5. Name of foreign principal on whose behalf this material was transmitted.
Japan External Trade Organization</td></tr><tr><td>6. Means of transmission
U.S. mail</td><td colspan="2">7. Dates of transmission
12-08-92</td><td>8. Total copies transmitted
122</td></tr><tr><td colspan="2">9. List addresses from which material was transmitted:
245 Peachtree Center Avenue
Marquis One Tower, Suite 2208
Atlanta, GA 30303</td><td colspan="2">10. List states and territories of the United States to which material was transmitted:
Japan External Trade Organization</td></tr><tr><td colspan="2">11. Types of recipients (Give number of organizations in each group)</td><td colspan="2">12. List names and addresses of persons or organizations receiving 100 copies or more:</td></tr><tr><td>Libraries</td><td>14</td><td></td><td></td></tr><tr><td>Public officials</td><td>12</td><td></td><td></td></tr><tr><td>Newspapers</td><td>14</td><td></td><td></td></tr><tr><td>Press services of associations</td><td>6</td><td></td><td></td></tr><tr><td>Educational institutions</td><td>24</td><td></td><td></td></tr><tr><td>Civic groups</td><td>32</td><td></td><td></td></tr><tr><td>Other (specify)</td><td>20 individuals</td><td></td><td></td></tr></table>

13. If the material transmitted was a film or radio or television script, furnish the following information:

Name of station, organization, or theater using (including city and state)

Date or dates broadcast shown

Estimated attendance (for film(s))

14. Have two copies of this material been filed with the Department of Justice? Yes No   
15. Has this material been labeled as required by the act? Yes No

<table><tr><td>Date of report
12-08-92</td><td>Name and title
Yasumasa Iwasaki
Executive Director</td><td>Signature
###</td></tr></table>