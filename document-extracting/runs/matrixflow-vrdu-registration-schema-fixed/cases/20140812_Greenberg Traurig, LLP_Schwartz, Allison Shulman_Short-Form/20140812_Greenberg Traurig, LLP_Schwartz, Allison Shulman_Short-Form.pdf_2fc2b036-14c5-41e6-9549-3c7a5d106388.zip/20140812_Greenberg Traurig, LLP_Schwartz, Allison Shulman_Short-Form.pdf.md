INSTRUCTIONS. Each partner, officer, director, associate, employee, and agent of a registrant is required to file a short form registration statement unless he engages in no activities in furtherance of the interests of the registrant's foreign principal or unless the services he renders to the registrant are in a secretarial, clerical, or in a related or similar capacity. Compliance is accomplished by filing an electronic short form registration statement at http://www.fara.gov.

Privacy Act Statement. The filing of this document is required for the Foreign Agents Registration Act of 1938, as amended, 22 U.S.C. § 611 et seq., for the purposes of registration under the Act and public disclosure. Provision of the information requested is mandatory, and failure to provide the information is subject to the penalty and enforcement provisions established in Section 8 of the Act. Every registration statement, short form registration statement, supplemental statement, exhibit, amendment, copy of informational materials or other document or information filed with the Attorney General under this Act is a public record open to public examination, inspection and copying during the posted business hours of the Registration Unit in Washington, DC. Statements are also available online at the Registration Unit's webpage: http://www.fara.gov. One copy of every such document, other than informational materials, is automatically provided to the Secretary of State pursuant to Section 6(b) of the Act, and copies of any and all documents are routinely made available to other agencies, departments and Congress pursuant to Section 6(c) of the Act. The Attorney General also transmits a semi-annual report to Congress on the administration of the Act which lists the names of all agents registered under the Act and the foreign principals they represent. This report is available to the public and online at: http://www.fara.gov.

Public Reporting Burden. Public reporting burden for this collection of information is estimated to average .429 hours per response, including the time for reviewing instructions, searching existing data sources, gathering and maintaining the data needed, and completing and reviewing the collection of information. Send comments regarding this burden estimate or any other aspect of this collection of information, including suggestions for reducing this burden to Chief, Registration Unit, Counterspionage Section, National Security Division, U.S. Department of Justice, Washington, DC 20530; and to the Office of Information and Regulatory Affairs, Office of Management and Budget, Washington, DC 20503.

<table><tr><td>1. Name
Allison Shulman Schwartz</td><td>2. Registration No.
5712</td></tr><tr><td>3. Residence Address(es)
1410 Dade Lane
Alexandria, VA 22308</td><td>4. Business Address(es)
2101 L Street, NW
Suite 1000
Washington DC 20037</td></tr><tr><td>5. Year of Birth 1972
Nationality American
Present Citizenship U.S.</td><td>6. If present citizenship was not acquired by birth, indicate when, and how acquired.
N/A</td></tr></table>

# 7. Occupation Employee

<table><tr><td colspan="2">8. What is the name and address of the primary registrant? 
Name Greenberg Traurig, LLP</td><td>Address</td><td colspan="2">2101 L Street, NW 
Suite 1000 
Washington DC 20037</td></tr><tr><td colspan="2">9. Indicate your connection with the primary registrant:</td><td></td><td></td><td></td></tr><tr><td>□ partner</td><td>□ director</td><td>✕ employee</td><td>□ consultant</td><td></td></tr><tr><td>□ officer</td><td>□ associate</td><td>□ agent</td><td>□ subcontractor</td><td></td></tr><tr><td colspan="2">□ other (specify)</td><td></td><td></td><td></td></tr></table>

10. List every foreign principal to whom you will render services in support of the primary registrant.

Republic of Turkey (through the Gephardt Group)

11. Describe separately and in detail all services which you will render to the foreign principal(s) listed in Item 10 either directly, or through the primary registrant listed in Item 8, and the date(s) of such services. (If space is insufficient, a full insert page must be used.)

Provide counsel in connection with strengthening the Turkish-American relationship and educating government officials on issues of importance to Turkey

12. Do any of the above described services include political activity as defined in Section 1(o) of the Act and in the footnote below?

Yes No

If yes, describe separately and in detail such political activity.

Provide counsel in connection with the extension and strengthening of the Turkish-American relationships that are the subject of debate in Congress including trade, energy security, counter-terrorism efforts and efforts to build regional stability in the broader Middle East and Europe. Educating Members of Congress and the Administration on issues of importance to Turkey, notification of Turkey of any action in Congress or the Executive Branch on issues of importance to Turkey.

13. The services described in Items 11 and 12 are to be rendered on a

□ full time basis

part time basis

$\boxed{\mathrm{X}}$ special basis

14. What compensation or thing of value have you received to date or will you receive for the above services?

Salary: Amount $ per

□ Commission at % of

Salary: Not based solely on services rendered to the foreign principal(s).

Fee: Amount $

□ Other thing of value

15. During the period beginning 60 days prior to the date of your obligation to register to the time of filing this statement, did you make any contributions of money or other things of value from your own funds or possessions and on your own behalf in connection with any election to political office or in connection with any primary election, convention, or caucus held to select candidates for any political office? Yes No

If yes, furnish the following information:

Date

Amount or Thing of Value

Political Organization or Candidate

Location of Event

# EXECUTION

In accordance with 28 U.S.C. § 1746, the undersigned swears or affirms under penalty of perjury that he/she has read the information set forth in this registration statement and that he/she is familiar with the contents thereof and that such contents are in their entirety true and accurate to the best of his/her knowledge and belief.

August 12, 2014

(Date of signature)

/s/ Allison Shulman Schwartz

eSigned

(Signature)