INSTRUCTIONS: Report must be submitted in duplicate to the Registration Unit, Internal Security Section, Criminal Division, Department of Justice, Washington, D.C. 20530. The original must be signed by or on behalf of the registrant. All items in this form must be answered, unless the answer is "none" or "not applicable," in which case such an entry shall be made in the appropriate space. If additional space is needed for any item, attach supplemental sheet identifying each item.

Privacy Act Statement. Every registration statement, short form registration statement, supplemental statement, exhibit, amendment, dissemination report, copy of political propaganda or other document or information filed with the Attorney General under this act is a public record open to public examination, inspection and copying during the posted business hours of the Registration Unit in Washington, D.C. One copy of every such document is automatically provided to the Secretary of State pursuant to Section 6(b) of the Act, and copies of such documents are routinely made available to other agencies, departments and Congress pursuant to Section 6(c) of the Act. Finally, the Attorney General transmits an annual report to the Congress on the Administration of the Act which lists the names of all agents registered under the Act, the foreign principals they represent, and the nature, sources and content of the political propaganda disseminated or distributed by them. This report is available to the public.

Public Reporting Burden. Public reporting burden for this collection of information is estimated to average .5 hours per response, including the time for reviewing instructions, searching existing data sources, gathering and maintaining the data needed, and completing and reviewing the collection of information. Send comments regarding this burden estimate or any other aspect of this collection of information, including suggestions for reducing this burden to Chief, Registration Unit, Criminal Division, U.S. Department of Justice, Washington, D.C. 20530; and to the Office of Information and Regulatory Affairs, Office of Management and Budget, Washington, D.C. 20503.

<table><tr><td>1. Name of registrant
Québec Government House</td><td>2. Registration No.
1787</td></tr></table>

3. Nature of material (A concise account of the nature of the propaganda material filed) Political, economic, cultural and touristic news from Quebec

<table><tr><td colspan="2">4. Title of material, if any
QUEBEC UPDATE, VOL XVI, No. 11</td><td colspan="2">5. Name of foreign principal on whose behalf this material was transmitted.
Québec Government</td></tr><tr><td>6. Means of transmission
Mail</td><td colspan="2">7. Dates of transmission
September 6, 1993</td><td>8. Total copies transmitted
1200</td></tr><tr><td colspan="2">9. List addresses from which material was transmitted:
Québec Government House
630 Fifth Avenue, Suite 360
New York, NY 10111</td><td colspan="2">10. List states and territories of the United States to which
material was transmitted:
DC, Delaware, Kentucky
Maryland, New Jersey,
New York, Pennsylvania,
Virginia, West Virginia</td></tr><tr><td colspan="2">11. Types of recipients (Give number of organizations
in each group)
Libraries        20
Public officials      365
Newspapers       180
Press services of
associations     30
Educational
institutions    500
Civic groups      banks, business concerns
Other canadian consulates, general public</td><td colspan="2">12. List names and addresses of persons or organizations
receiving 100 copies or more:
NIL</td></tr></table>

13. If the material transmitted was a film or radio or television script, furnish the following information:

Name of station, organization, or theater using (including city and state)

Date or dates broadcast shown

Estimated attendance (for film(s))

N/A

14. Have two copies of this material been filed with the Department of Justice? Yes No

15. Has this material been labeled as required by the act? Yes No

<table><tr><td>Date of report</td><td>Name and title</td><td>Signature</td><td></td></tr><tr><td>10/1/93</td><td>Reed Scowen, Delegate General</td><td></td><td></td></tr></table>