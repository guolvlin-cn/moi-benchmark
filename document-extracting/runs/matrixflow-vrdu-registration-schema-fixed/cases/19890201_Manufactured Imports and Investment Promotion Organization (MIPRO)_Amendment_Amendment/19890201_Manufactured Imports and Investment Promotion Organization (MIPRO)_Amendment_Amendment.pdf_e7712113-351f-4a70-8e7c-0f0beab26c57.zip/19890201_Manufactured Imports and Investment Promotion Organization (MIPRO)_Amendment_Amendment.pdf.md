1. Name of Registrant

Manufactured Imports Promotion Organization

2. Registration No.

3196

3. This amendment is filed to accomplish the following indicated purpose or purposes:

To correct a deficiency in

To give a 10-day notice of a change in information as required by Section 2(b) of the Act.

□ Initial Statement

the reporting period

ending 2-5-88

Supplemental Statement for

□ Other purpose (specify)

To give notice of change in an exhibit previously filed.

4. If this amendment requires the filing of a document or documents, please list-

5. Each item checked above must be explained below in full detail together with, where appropriate, specific reference to and identity of the item in the registration statement to which it pertains. If more space is needed, full size insert sheets may be used.

The detail for the receipt of the specified amounts which you requested in your letter is as follows:

$5508.19, January 20, 1988

This amount is made up of several repayments to the office as follows:

(1) $11.50 refund from the Internal Revenue Service for overpayment of federal tax   
(2) $34.71 refund from Quill Office Supply Company for items not delivered   
(3) $725.00 refund from Federal Publications Inc. for cancellation of a seminar for which I had registered   
(4) $4736.98 refund from a Japanese visitor for his personal expenses which were temporarily paid from the office account

![](images/521c98a0-1cdf-401e-8bb2-f31af78f77e1.jpg)

The undersigned swear(s) or affirm(s) that he has (they have) read the information set forth in this amendment and that he is (they are) familiar with the contents thereof and that such contents are in their entirety true and accurate to the best of his (their) knowledge and belief.

knowledge and belief.

![](images/3b18ca4a-c8e0-41d2-ad88-20b75ef4206f.jpg)

(Both copies of this amendment shall be signed and sworn to before a notary public or other person authorized to administer oaths by the agent, if the registrant is an individual, or by a majority of those partners, officers, directors or persons performing similar functions who are in the United States, if the registrant is an organization.)

Subscribed and sworn to before me at 1989 (yauu-Jaues) this day of 1989 May F. Wilius (Notary or other officer) My commission expires 1991